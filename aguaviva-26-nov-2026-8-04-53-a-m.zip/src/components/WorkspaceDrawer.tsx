import React, { useState } from 'react';
import { X, Check, Send, ShieldCheck, Sparkles, ArrowRight } from 'lucide-react';
import type {
  ArmorStyleType,
  AvatarParams,
  BlockchainState,
  EyeStyleType,
  FaceShapeType,
  FacialExpressionType,
  GazeDirectionType,
  HairStyleType,
  HouseParams,
  MouthStyleType,
  RoofStyleType,
  TwinTelemetry,
  WallMaterialType,
  WeaponFinishType,
} from '../types/aguaviva';

export type DrawerSection =
  | 'none'
  | 'house'
  | 'avatar'
  | 'bank'
  | 'twin'
  | 'ai';

interface WorkspaceDrawerProps {
  section: DrawerSection;
  onClose: () => void;
  house: HouseParams;
  onChangeHouse: (next: HouseParams) => void;
  avatar: AvatarParams;
  onChangeAvatar: (next: AvatarParams) => void;
  blockchain: BlockchainState | null;
  telemetry: TwinTelemetry | null;
  onSubmitTx: (payload: {
    type: 'MINT_DEED' | 'TRANSFER' | 'ECO_REWARD' | 'AVATAR_FORGE';
    to?: string;
    amount?: number;
    summary?: string;
    houseParams?: HouseParams;
    avatarParams?: AvatarParams;
  }) => Promise<string | null>;
  onRunAIDesign: (prompt: string) => Promise<{ title: string; notes: string } | string>;
}

export const WorkspaceDrawer: React.FC<WorkspaceDrawerProps> = ({
  section,
  onClose,
  house,
  onChangeHouse,
  avatar,
  onChangeAvatar,
  blockchain,
  telemetry,
  onSubmitTx,
  onRunAIDesign,
}) => {
  const [txBusy, setTxBusy] = useState(false);
  const [txFeedback, setTxFeedback] = useState<string | null>(null);
  const [transferTo, setTransferTo] = useState('agv1q84f2c90b7d1a43e19c5502f8b19c0a');
  const [transferAmount, setTransferAmount] = useState('120');

  const [aiPrompt, setAiPrompt] = useState(
    'Residencia bioclimática de madera de cedro con techo de bóveda paramétrica, gran ventanal al río y bio-avatar eco-ranger en titanio azul'
  );
  const [aiBusy, setAiBusy] = useState(false);
  const [aiResult, setAiResult] = useState<{ title?: string; notes?: string; error?: string } | null>(
    null
  );

  if (section === 'none') return null;

  const handleTx = async (
    payload: Parameters<WorkspaceDrawerProps['onSubmitTx']>[0],
    successMsg: string
  ) => {
    setTxBusy(true);
    setTxFeedback(null);
    const err = await onSubmitTx(payload);
    setTxBusy(false);
    setTxFeedback(err ? `Error: ${err}` : successMsg);
  };

  const handleAI = async (e: React.FormEvent) => {
    e.preventDefault();
    setAiBusy(true);
    setAiResult(null);
    const res = await onRunAIDesign(aiPrompt);
    setAiBusy(false);
    if (typeof res === 'string') {
      setAiResult({ error: res });
    } else {
      setAiResult({ title: res.title, notes: res.notes });
    }
  };

  const titles: Record<Exclude<DrawerSection, 'none'>, string> = {
    house: 'Eco-Residencia Paramétrica',
    avatar: 'Bio-Avatar SSS y Arsenal',
    bank: 'Banca y Blockchain Dilithium-3',
    twin: 'Gemelo Digital Global',
    ai: 'Estudio Generativo con IA',
  };

  return (
    <aside
      aria-label={titles[section]}
      className="fixed top-[68px] right-4 bottom-24 z-30 w-[min(420px,92vw)] bg-slate-950/94 border border-white/12 rounded-xl shadow-2xl flex flex-col overflow-hidden"
    >
      <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10">
        <h2 className="font-display text-base font-semibold text-white tracking-tight">
          {titles[section]}
        </h2>
        <button
          type="button"
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="Cerrar panel"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-5 text-sm text-slate-200">
        {txFeedback && (
          <div
            className={`px-3.5 py-2.5 rounded-lg border text-xs ${
              txFeedback.startsWith('Error:')
                ? 'bg-red-950/60 border-red-500/40 text-red-200'
                : 'bg-cyan-950/60 border-cyan-500/40 text-cyan-100'
            }`}
          >
            {txFeedback}
          </div>
        )}

        {/* 1. PARAMETRIC HOUSE EDITOR */}
        {section === 'house' && (
          <>
            <p className="text-xs text-slate-400 leading-relaxed">
              Ajusta las dimensiones estructurales y materiales PBR escaneados de tu residencia. Al sellar en Dilithium-3 se registra el hash criptográfico de tu parcela.
            </p>

            <div className="space-y-3.5">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Ancho estructural</span>
                  <span className="font-mono tabular-nums text-cyan-300">{house.width.toFixed(1)} m</span>
                </div>
                <input
                  type="range"
                  min={8}
                  max={18}
                  step={0.5}
                  value={house.width}
                  onChange={(e) => onChangeHouse({ ...house, width: Number(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Profundidad</span>
                  <span className="font-mono tabular-nums text-cyan-300">{house.depth.toFixed(1)} m</span>
                </div>
                <input
                  type="range"
                  min={7}
                  max={15}
                  step={0.5}
                  value={house.depth}
                  onChange={(e) => onChangeHouse({ ...house, depth: Number(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Altura base</span>
                  <span className="font-mono tabular-nums text-cyan-300">{house.height.toFixed(1)} m</span>
                </div>
                <input
                  type="range"
                  min={3.5}
                  max={8.5}
                  step={0.25}
                  value={house.height}
                  onChange={(e) => onChangeHouse({ ...house, height: Number(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Acristalamiento óptico</span>
                  <span className="font-mono tabular-nums text-cyan-300">
                    {Math.round(house.glassRatio * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0.25}
                  max={0.85}
                  step={0.05}
                  value={house.glassRatio}
                  onChange={(e) => onChangeHouse({ ...house, glassRatio: Number(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Paneles solares fotovoltaicos</span>
                  <span className="font-mono tabular-nums text-cyan-300">{house.solarPanels} uds</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={12}
                  step={1}
                  value={house.solarPanels}
                  onChange={(e) => onChangeHouse({ ...house, solarPanels: Number(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Plantas habitables</span>
              <div className="grid grid-cols-2 gap-2">
                {[1, 2].map((fl) => (
                  <button
                    key={fl}
                    type="button"
                    onClick={() => onChangeHouse({ ...house, floors: fl })}
                    className={`py-2 px-3 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      house.floors === fl
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {fl === 1 ? '1 Planta' : '2 Plantas'}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Material PBR de fachada</span>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { id: 'concrete', label: 'Hormigón PBR' },
                    { id: 'brick', label: 'Ladrillo Arcilla' },
                    { id: 'cedar', label: 'Madera Cedro' },
                    { id: 'titanium', label: 'Titanio Cepillado' },
                  ] as { id: WallMaterialType; label: string }[]
                ).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onChangeHouse({ ...house, wallMaterial: m.id })}
                    className={`py-2 px-3 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      house.wallMaterial === m.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Geometría de cubierta</span>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    { id: 'flat_solar', label: 'Verde Plana' },
                    { id: 'gabled', label: 'Dos Aguas' },
                    { id: 'parametric_vault', label: 'Bóveda' },
                  ] as { id: RoofStyleType; label: string }[]
                ).map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => onChangeHouse({ ...house, roofStyle: r.id })}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
                      house.roofStyle === r.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={house.hydroTurbine}
                  onChange={(e) => onChangeHouse({ ...house, hydroTurbine: e.target.checked })}
                  className="accent-cyan-400 w-4 h-4"
                />
                <span>Micro-turbina eólica</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-slate-300">
                <span>Acabado metálico</span>
                <input
                  type="color"
                  value={house.accentColor}
                  onChange={(e) => onChangeHouse({ ...house, accentColor: e.target.value })}
                  className="w-7 h-7 rounded bg-transparent border border-white/15 cursor-pointer"
                />
              </label>
            </div>

            <button
              type="button"
              disabled={txBusy}
              onClick={() =>
                handleTx(
                  {
                    type: 'MINT_DEED',
                    houseParams: house,
                    summary: `Actualización de residencia (${house.wallMaterial}, ${house.roofStyle}, ${house.solarPanels} paneles)`,
                  },
                  'Escritura paramétrica sellada con firma CRYSTALS-Dilithium-3.'
                )
              }
              className="w-full py-2.5 px-4 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{txBusy ? 'Firmando en Dilithium-3...' : 'Sellar Escritura en Dilithium-3 (25 AGV)'}</span>
            </button>
          </>
        )}

        {/* 2. REALISTIC AVATAR & ARSENAL EDITOR */}
        {section === 'avatar' && (
          <>
            <p className="text-xs text-slate-400 leading-relaxed">
              Personaliza tu bio-avatar humanoide con anatomía esculpida, ojos multicapa con córnea refractora, Dispersión Subsuperficial (SSS) y trajes inspirados en Crysis, Mu, Free Fire y MLBB.
            </p>

            <label className="flex items-center justify-between bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-200 cursor-pointer">
              <span>Modelo externo GLB (Soldier + fallback PBR)</span>
              <input
                type="checkbox"
                checked={Boolean(avatar.useGlbAvatar)}
                onChange={(e) => onChangeAvatar({ ...avatar, useGlbAvatar: e.target.checked })}
                className="accent-cyan-400 w-4 h-4 cursor-pointer"
              />
            </label>

            {/* Colors: Skin, Hair, Eyes, Armor, Energy */}
            <div className="grid grid-cols-2 gap-2.5">
              <label className="flex items-center justify-between bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs">
                <span>Piel</span>
                <input
                  type="color"
                  value={avatar.skinTone}
                  onChange={(e) => onChangeAvatar({ ...avatar, skinTone: e.target.value })}
                  className="w-6 h-6 bg-transparent cursor-pointer"
                />
              </label>
              <label className="flex items-center justify-between bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs">
                <span>Cabello</span>
                <input
                  type="color"
                  value={avatar.hairColor}
                  onChange={(e) => onChangeAvatar({ ...avatar, hairColor: e.target.value })}
                  className="w-6 h-6 bg-transparent cursor-pointer"
                />
              </label>
              <label className="flex items-center justify-between bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs">
                <span>Color de Ojos</span>
                <input
                  type="color"
                  value={avatar.eyeColor}
                  onChange={(e) => onChangeAvatar({ ...avatar, eyeColor: e.target.value })}
                  className="w-6 h-6 bg-transparent cursor-pointer"
                />
              </label>
              <label className="flex items-center justify-between bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs">
                <span>Traje / Armadura</span>
                <input
                  type="color"
                  value={avatar.armorColor}
                  onChange={(e) => onChangeAvatar({ ...avatar, armorColor: e.target.value })}
                  className="w-6 h-6 bg-transparent cursor-pointer"
                />
              </label>
              <label className="col-span-2 flex items-center justify-between bg-slate-900 border border-white/10 rounded-lg px-3 py-2 text-xs">
                <span>Núcleo Bio-Energético</span>
                <input
                  type="color"
                  value={avatar.energyColor}
                  onChange={(e) => onChangeAvatar({ ...avatar, energyColor: e.target.value })}
                  className="w-6 h-6 bg-transparent cursor-pointer"
                />
              </label>
            </div>

            {/* Face Shape */}
            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Tipo de Rostro</span>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { id: 'heroic', label: 'Atlético Heroico' },
                    { id: 'elven_mu', label: 'Fino / Élfico (Mu)' },
                    { id: 'tactical_square', label: 'Táctico (Crysis)' },
                    { id: 'youthful_mlbb', label: 'Juvenil (MLBB)' },
                  ] as { id: FaceShapeType; label: string }[]
                ).map((fs) => (
                  <button
                    key={fs.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...avatar, faceShape: fs.id })}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      avatar.faceShape === fs.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {fs.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Eye Style & Gaze */}
            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Tipo de Ojos</span>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { id: 'almond', label: 'Almendrados' },
                    { id: 'mystic_mu', label: 'Místicos (Mu)' },
                    { id: 'intense_crysis', label: 'Intensidad Táctica' },
                    { id: 'expressive_mlbb', label: 'Expresivos (MLBB)' },
                  ] as { id: EyeStyleType; label: string }[]
                ).map((es) => (
                  <button
                    key={es.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...avatar, eyeStyle: es.id })}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      avatar.eyeStyle === es.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {es.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Dirección de la Mirada</span>
              <div className="grid grid-cols-5 gap-1.5">
                {(
                  [
                    { id: 'center', label: 'Centro' },
                    { id: 'left', label: 'Izq.' },
                    { id: 'right', label: 'Der.' },
                    { id: 'up', label: 'Arriba' },
                    { id: 'down', label: 'Abajo' },
                  ] as { id: GazeDirectionType; label: string }[]
                ).map((gz) => (
                  <button
                    key={gz.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...avatar, gazeDirection: gz.id })}
                    className={`py-1.5 px-1 text-[11px] font-medium rounded-lg border transition-colors cursor-pointer ${
                      avatar.gazeDirection === gz.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {gz.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Mouth Style & Expressions / Gestures */}
            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Tipo de Boca</span>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { id: 'balanced', label: 'Equilibrada' },
                    { id: 'full_defined', label: 'Labios Definidos' },
                    { id: 'sharp_tactical', label: 'Fina Táctica' },
                    { id: 'natural_smile', label: 'Sonrisa Natural' },
                  ] as { id: MouthStyleType; label: string }[]
                ).map((ms) => (
                  <button
                    key={ms.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...avatar, mouthStyle: ms.id })}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      avatar.mouthStyle === ms.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {ms.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Gestos y Expresión Facial</span>
              <div className="grid grid-cols-3 gap-1.5">
                {(
                  [
                    { id: 'serene', label: 'Serena' },
                    { id: 'smile', label: 'Sonriente' },
                    { id: 'determined', label: 'Combate' },
                    { id: 'surprised', label: 'Sorpresa' },
                    { id: 'wink', label: 'Guiño' },
                  ] as { id: FacialExpressionType; label: string }[]
                ).map((ex) => (
                  <button
                    key={ex.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...avatar, expression: ex.id })}
                    className={`py-1.5 px-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      avatar.expression === ex.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {ex.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Hairstyles */}
            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Peinado y Estilo</span>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { id: 'styled_spiky_mlbb', label: 'Puntas Heroicas (MLBB)' },
                    { id: 'heroic_long_mu', label: 'Melena Larga (Mu)' },
                    { id: 'tactical_short', label: 'Corto (Free Fire)' },
                    { id: 'urban_waves', label: 'Ondulado Urbano' },
                    { id: 'crysis_helmet', label: 'Casco Nanosuit (Crysis)' },
                  ] as { id: HairStyleType; label: string }[]
                ).map((hs) => (
                  <button
                    key={hs.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...avatar, hairStyle: hs.id })}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      avatar.hairStyle === hs.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {hs.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sliders: SSS & Height */}
            <div className="space-y-3 pt-1">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Dispersión Subsuperficial (SSS Piel)</span>
                  <span className="font-mono tabular-nums text-cyan-300">
                    {Math.round(avatar.sssIntensity * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0.1}
                  max={1.0}
                  step={0.05}
                  value={avatar.sssIntensity}
                  onChange={(e) => onChangeAvatar({ ...avatar, sssIntensity: Number(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Estatura del avatar</span>
                  <span className="font-mono tabular-nums text-cyan-300">
                    {(avatar.heightScale * 1.78).toFixed(2)} m
                  </span>
                </div>
                <input
                  type="range"
                  min={0.9}
                  max={1.15}
                  step={0.01}
                  value={avatar.heightScale}
                  onChange={(e) => onChangeAvatar({ ...avatar, heightScale: Number(e.target.value) })}
                  className="w-full accent-cyan-400"
                />
              </div>
            </div>

            {/* Outfit Archetypes (Crysis / Mu / Free Fire / MLBB) */}
            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Traje / Armadura de Combate</span>
              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    { id: 'crysis_nanosuit', label: 'Nanosuit (Crysis)' },
                    { id: 'mu_valkyrie', label: 'Alado Místico (Mu)' },
                    { id: 'freefire_tactical', label: 'Asalto (Free Fire)' },
                    { id: 'mlbb_hero', label: 'Manto Héroe (MLBB)' },
                  ] as { id: ArmorStyleType; label: string }[]
                ).map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...avatar, armorStyle: st.id })}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      avatar.armorStyle === st.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-xs text-slate-300">Acabado PBR de carabina</span>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    { id: 'brushed_titanium', label: 'Titanio' },
                    { id: 'anodized_carbon', label: 'Carbono' },
                    { id: 'cobalt_alloy', label: 'Cobalto' },
                  ] as { id: WeaponFinishType; label: string }[]
                ).map((wf) => (
                  <button
                    key={wf.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...avatar, weaponFinish: wf.id })}
                    className={`py-2 px-2 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      avatar.weaponFinish === wf.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                        : 'bg-slate-900 border-white/10 text-slate-300 hover:border-white/25'
                    }`}
                  >
                    {wf.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              disabled={txBusy}
              onClick={() =>
                handleTx(
                  {
                    type: 'AVATAR_FORGE',
                    avatarParams: avatar,
                    summary: `Registro de Bio-Avatar (${avatar.armorStyle}, rostro ${avatar.faceShape}, peinado ${avatar.hairStyle})`,
                  },
                  'Identidad biométrica del Bio-Avatar sellada en Dilithium-3.'
                )
              }
              className="w-full py-2.5 px-4 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{txBusy ? 'Registrando...' : 'Registrar Avatar en Dilithium-3 (25 AGV)'}</span>
            </button>
          </>
        )}

        {/* 3. POST-QUANTUM DILITHIUM-3 BANK & BLOCKCHAIN */}
        {section === 'bank' && (
          <>
            {!blockchain ? (
              <p className="text-xs text-slate-400">Sincronizando libro mayor postcuántico...</p>
            ) : (
              <>
                <div className="bg-slate-900 border border-white/10 rounded-xl p-4 space-y-2.5">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>{blockchain.networkName}</span>
                    <span className="font-mono tabular-nums text-cyan-300">
                      Bloque #{blockchain.blockHeight}
                    </span>
                  </div>
                  <div className="text-2xl font-display font-bold text-white tabular-nums">
                    {blockchain.balanceAGV.toLocaleString('es-ES', { minimumFractionDigits: 2 })} AGV
                  </div>
                  <div className="text-xs text-slate-400 font-mono tabular-nums">
                    Staking Hídrico: {blockchain.stakedHydroAGV.toLocaleString('es-ES')} AGV
                  </div>
                  <div className="pt-2 border-t border-white/8 text-[11px] font-mono text-slate-400 break-all">
                    Dirección: {blockchain.citizenAddress}
                  </div>
                  <div className="text-[11px] text-emerald-300/90">
                    {blockchain.quantumSecurityLevel}
                  </div>
                </div>

                <button
                  type="button"
                  disabled={txBusy}
                  onClick={() =>
                    handleTx(
                      {
                        type: 'ECO_REWARD',
                        amount: 150,
                        summary: 'Liquidación de excedente solar e hidroeléctrico de parcela #042',
                      },
                      '+150 AGV acreditados por generación renovable.'
                    )
                  }
                  className="w-full py-2 px-3 text-xs font-medium text-emerald-200 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/35 rounded-lg transition-colors cursor-pointer"
                >
                  Reclamar recompensa solar e hídrica (+150 AGV)
                </button>

                <div className="space-y-2 pt-2 border-t border-white/10">
                  <h3 className="text-xs font-semibold text-slate-200">
                    Transferencia P2P Postcuántica
                  </h3>
                  <input
                    type="text"
                    value={transferTo}
                    onChange={(e) => setTransferTo(e.target.value)}
                    placeholder="Dirección destino agv1q..."
                    className="w-full px-3 py-2 text-xs font-mono bg-slate-900 border border-white/12 rounded-lg text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min={1}
                      value={transferAmount}
                      onChange={(e) => setTransferAmount(e.target.value)}
                      className="flex-1 px-3 py-2 text-xs font-mono tabular-nums bg-slate-900 border border-white/12 rounded-lg text-slate-100 focus:outline-none focus:border-cyan-400"
                    />
                    <button
                      type="button"
                      disabled={txBusy}
                      onClick={() =>
                        handleTx(
                          {
                            type: 'TRANSFER',
                            to: transferTo,
                            amount: Number(transferAmount),
                            summary: `Transferencia P2P firmada con ML-DSA-65`,
                          },
                          `Transferencia de ${transferAmount} AGV confirmada en bloque.`
                        )
                      }
                      className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg flex items-center gap-1.5 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Enviar</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-white/10">
                  <h3 className="text-xs font-semibold text-slate-200">
                    Propiedades Digitales Interoperables
                  </h3>
                  <div className="space-y-2">
                    {blockchain.deeds.map((deed) => (
                      <div
                        key={deed.deedId}
                        className="p-3 bg-slate-900 border border-white/8 rounded-lg space-y-1"
                      >
                        <div className="flex justify-between text-xs font-medium text-white">
                          <span>{deed.title}</span>
                          <span className="font-mono text-cyan-300">{deed.deedId}</span>
                        </div>
                        <div className="text-[11px] font-mono text-slate-400 truncate">
                          Hash SHA3-256: {deed.blueprintHash}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 truncate">
                          Firma Dilithium-3: {deed.dilithiumProof}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-2 border-t border-white/10">
                  <h3 className="text-xs font-semibold text-slate-200">
                    Últimos Bloques Verificados
                  </h3>
                  <div className="space-y-2">
                    {blockchain.blocks.slice(0, 5).map((blk) => (
                      <div
                        key={blk.height}
                        className="p-2.5 bg-slate-900/80 border border-white/8 rounded-lg space-y-1 text-[11px]"
                      >
                        <div className="flex justify-between font-mono tabular-nums text-slate-300">
                          <span>Bloque #{blk.height}</span>
                          <span className="text-slate-400">{blk.validatorNode}</span>
                        </div>
                        <div className="text-slate-300">
                          {blk.transactions[0]?.summary}
                        </div>
                        <div className="font-mono text-slate-500 truncate">
                          Merkle: {blk.merkleRoot}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </>
        )}

        {/* 4. GLOBAL DIGITAL TWIN TELEMETRY */}
        {section === 'twin' && (
          <>
            <p className="text-xs text-slate-400 leading-relaxed">
              Telemetría ambiental y de infraestructura urbana conectada en tiempo real al motor 3D: el caudal hídrico y la irradiancia solar controlan la turbulencia del río y el flujo de red.
            </p>
            {!telemetry ? (
              <p className="text-xs text-slate-400">Conectando sensores del gemelo digital...</p>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-slate-900 border border-white/10 rounded-lg">
                    <div className="text-xs text-slate-400">Ciudadanos activos</div>
                    <div className="text-lg font-display font-semibold text-white tabular-nums mt-0.5">
                      {telemetry.globalCitizensOnline.toLocaleString('es-ES')}
                    </div>
                  </div>
                  <div className="p-3 bg-slate-900 border border-white/10 rounded-lg">
                    <div className="text-xs text-slate-400">Red renovable</div>
                    <div className="text-lg font-display font-semibold text-emerald-300 tabular-nums mt-0.5">
                      {telemetry.renewableGridPct}%
                    </div>
                  </div>
                  <div className="p-3 bg-slate-900 border border-white/10 rounded-lg">
                    <div className="text-xs text-slate-400">Agua purificada</div>
                    <div className="text-lg font-display font-semibold text-cyan-300 tabular-nums mt-0.5">
                      {(telemetry.totalCleanWaterM3 / 1_000_000).toFixed(2)}M m³
                    </div>
                  </div>
                  <div className="p-3 bg-slate-900 border border-white/10 rounded-lg">
                    <div className="text-xs text-slate-400">CO₂ compensado</div>
                    <div className="text-lg font-display font-semibold text-white tabular-nums mt-0.5">
                      {telemetry.carbonOffsetTons.toLocaleString('es-ES')} t
                    </div>
                  </div>
                </div>

                <div className="space-y-2.5 pt-2 border-t border-white/10">
                  <h3 className="text-xs font-semibold text-slate-200">
                    Distritos sincronizados
                  </h3>
                  {telemetry.districts.map((d) => (
                    <div
                      key={d.id}
                      className="p-3.5 bg-slate-900 border border-white/8 rounded-lg space-y-1.5"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-semibold text-white">{d.name}</span>
                        <span className="text-[11px] font-mono tabular-nums text-slate-400">
                          {d.activeNodes} nodos
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs font-mono tabular-nums text-slate-300">
                        <span>Pureza {d.waterPurityPct}%</span>
                        <span aria-hidden="true">·</span>
                        <span>Solar {d.solarOutputMW} MW</span>
                        <span aria-hidden="true">·</span>
                        <span>AQI {d.airQualityAQI}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono tabular-nums">
                        Caudal fluvial: {d.riverFlowM3s} m³/s
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </>
        )}

        {/* 5. GENERATIVE AI ARCHITECTURAL & AVATAR DESIGNER */}
        {section === 'ai' && (
          <>
            <p className="text-xs text-slate-400 leading-relaxed">
              Describe la estética sostenible de tu residencia y tu bio-avatar. El sintetizador generativo calculará los parámetros arquitectónicos, materiales PBR y equipamiento en tiempo real.
            </p>
            <form onSubmit={handleAI} className="space-y-3">
              <textarea
                rows={4}
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="Ej: Casa minimalista de hormigón blanco con 10 paneles solares, turbina eólica y armadura orbital dorada..."
                className="w-full p-3 text-xs bg-slate-900 border border-white/12 rounded-lg text-slate-100 leading-relaxed focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                disabled={aiBusy}
                className="w-full py-2.5 px-4 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>{aiBusy ? 'Sintetizando parámetros 3D...' : 'Generar Casa y Avatar con IA'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            {aiResult?.error && (
              <div className="p-3 bg-red-950/60 border border-red-500/40 rounded-lg text-xs text-red-200 leading-relaxed">
                {aiResult.error}
              </div>
            )}

            {aiResult?.title && (
              <div className="p-4 bg-slate-900 border border-cyan-500/30 rounded-xl space-y-2">
                <div className="text-xs font-semibold text-cyan-300">
                  {aiResult.title}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {aiResult.notes}
                </p>
              </div>
            )}
          </>
        )}
      </div>
    </aside>
  );
};
