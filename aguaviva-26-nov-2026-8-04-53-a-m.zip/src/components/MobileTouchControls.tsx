import React, { useRef, useState } from 'react';
import { Crosshair, ArrowUp, RotateCw, Smile } from 'lucide-react';

interface MobileTouchControlsProps {
  visible: boolean;
  onMove: (x: number, y: number) => void;
  onFire: () => void;
  onJump: () => void;
  onReload: () => void;
  onCycleExpression: () => void;
}

export const MobileTouchControls: React.FC<MobileTouchControlsProps> = ({
  visible,
  onMove,
  onFire,
  onJump,
  onReload,
  onCycleExpression,
}) => {
  const padRef = useRef<HTMLDivElement | null>(null);
  const activePointerId = useRef<number | null>(null);
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const maxRadius = 42;

  if (!visible) return null;

  const updateStick = (clientX: number, clientY: number) => {
    const el = padRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxRadius) {
      dx = (dx / dist) * maxRadius;
      dy = (dy / dist) * maxRadius;
    }
    setKnobOffset({ x: dx, y: dy });
    onMove(dx / maxRadius, dy / maxRadius);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    activePointerId.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    updateStick(e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (activePointerId.current !== e.pointerId) return;
    e.stopPropagation();
    updateStick(e.clientX, e.clientY);
  };

  const resetStick = (e: React.PointerEvent<HTMLDivElement>) => {
    if (activePointerId.current !== e.pointerId) return;
    e.stopPropagation();
    activePointerId.current = null;
    setKnobOffset({ x: 0, y: 0 });
    onMove(0, 0);
  };

  return (
    <div className="pointer-events-none fixed inset-x-4 bottom-28 md:bottom-24 z-20 flex items-end justify-between">
      {/* Left Virtual Analog Thumbstick */}
      <div
        ref={padRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={resetStick}
        onPointerCancel={resetStick}
        aria-label="Joystick táctil de movimiento"
        className="pointer-events-auto touch-none relative w-32 h-32 rounded-full bg-slate-950/75 border border-white/20 flex items-center justify-center shadow-xl"
      >
        <div className="w-20 h-20 rounded-full border border-white/10 pointer-events-none" />
        <div
          style={{
            transform: `translate(${knobOffset.x}px, ${knobOffset.y}px)`,
          }}
          className="absolute w-12 h-12 rounded-full bg-cyan-400/90 border-2 border-white shadow-lg pointer-events-none"
        />
      </div>

      {/* Right Thumb Tactical Action Buttons (>= 48px touch targets) */}
      <div
        className="pointer-events-auto touch-none grid grid-cols-2 gap-3"
        onPointerDown={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onPointerDown={(e) => {
            e.stopPropagation();
            onJump();
          }}
          className="w-14 h-14 rounded-full bg-slate-950/85 border border-white/20 text-white active:bg-slate-800 flex flex-col items-center justify-center gap-0.5 shadow-lg cursor-pointer"
          aria-label="Saltar"
        >
          <ArrowUp className="w-5 h-5" />
          <span className="text-[10px] font-medium">Saltar</span>
        </button>

        <button
          type="button"
          onPointerDown={(e) => {
            e.stopPropagation();
            onCycleExpression();
          }}
          className="w-14 h-14 rounded-full bg-slate-950/85 border border-white/20 text-cyan-300 active:bg-slate-800 flex flex-col items-center justify-center gap-0.5 shadow-lg cursor-pointer"
          aria-label="Cambiar gesto facial"
        >
          <Smile className="w-5 h-5" />
          <span className="text-[10px] font-medium">Gesto</span>
        </button>

        <button
          type="button"
          onPointerDown={(e) => {
            e.stopPropagation();
            onReload();
          }}
          className="w-14 h-14 rounded-full bg-slate-950/85 border border-white/20 text-slate-200 active:bg-slate-800 flex flex-col items-center justify-center gap-0.5 shadow-lg cursor-pointer"
          aria-label="Recargar arma"
        >
          <RotateCw className="w-5 h-5" />
          <span className="text-[10px] font-medium">Recarga</span>
        </button>

        <button
          type="button"
          onPointerDown={(e) => {
            e.stopPropagation();
            onFire();
          }}
          className="w-16 h-16 rounded-full bg-amber-400 active:bg-amber-300 text-slate-950 border-2 border-amber-200 flex flex-col items-center justify-center gap-0.5 shadow-xl cursor-pointer"
          aria-label="Disparar"
        >
          <Crosshair className="w-6 h-6" />
          <span className="text-[10px] font-bold">Fuego</span>
        </button>
      </div>
    </div>
  );
};
