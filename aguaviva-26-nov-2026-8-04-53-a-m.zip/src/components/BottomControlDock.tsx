import React from 'react';
import {
  ChevronDown,
  ChevronUp,
  Crosshair,
  RotateCw,
  ArrowUp,
  Volume2,
  VolumeX,
  Sun,
  Smartphone,
} from 'lucide-react';
import type {
  CameraPreset,
  PostProcessingConfig,
  QualityPreset,
  WeaponHUDState,
} from '../types/aguaviva';

interface BottomControlDockProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  cameraPreset: CameraPreset;
  onSelectPreset: (preset: CameraPreset) => void;
  postConfig: PostProcessingConfig;
  onChangePost: (next: PostProcessingConfig) => void;
  qualityMode: QualityPreset;
  onToggleQuality: () => void;
  hud: WeaponHUDState;
  muted: boolean;
  onToggleMute: () => void;
  touchEnabled: boolean;
  onToggleTouch: () => void;
  onFire: () => void;
  onReload: () => void;
  onJump: () => void;
}

const PRESETS: { id: CameraPreset; label: string }[] = [
  { id: 'third_person', label: 'Tercera Persona' },
  { id: 'residence', label: 'Residencia' },
  { id: 'avatar_inspect', label: 'Avatar SSS' },
  { id: 'global', label: 'Vista Global' },
];

export const BottomControlDock: React.FC<BottomControlDockProps> = ({
  collapsed,
  onToggleCollapse,
  cameraPreset,
  onSelectPreset,
  postConfig,
  onChangePost,
  qualityMode,
  onToggleQuality,
  hud,
  muted,
  onToggleMute,
  touchEnabled,
  onToggleTouch,
  onFire,
  onReload,
  onJump,
}) => {
  return (
    <div
      className={`fixed bottom-4 left-1/2 -translate-x-1/2 z-20 w-[min(960px,95vw)] transition-transform duration-300 ease-out ${
        collapsed ? 'translate-y-[calc(100%-24px)]' : 'translate-y-0'
      }`}
    >
      {/* Collapse / Expand Tab */}
      <div className="flex justify-center">
        <button
          type="button"
          onClick={onToggleCollapse}
          className="flex items-center gap-1.5 px-3.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-950/92 border border-b-0 border-white/12 rounded-t-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          aria-label={collapsed ? 'Mostrar controles' : 'Ocultar controles'}
        >
          {collapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          <span>{collapsed ? 'Mostrar controles (H)' : 'Ocultar controles (H)'}</span>
        </button>
      </div>

      {/* Main Dock Surface — solid alpha background, zero backdrop-filter over WebGL */}
      <div className="bg-slate-950/92 border border-white/12 rounded-xl px-4 py-3 shadow-2xl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Camera Presets */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-white/8 overflow-x-auto max-w-full">
            {PRESETS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => onSelectPreset(p.id)}
                className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  cameraPreset === p.id
                    ? 'bg-cyan-500 text-slate-950 font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Tactical Actions & Touch Mode */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onFire}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              title="Disparar Carabina (Clic o F)"
            >
              <Crosshair className="w-3.5 h-3.5" />
              <span>Disparar</span>
            </button>
            <button
              type="button"
              onClick={onReload}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              title="Recargar (R)"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Recargar</span>
            </button>
            <button
              type="button"
              onClick={onJump}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              title="Saltar (Espacio)"
            >
              <ArrowUp className="w-3.5 h-3.5" />
              <span>Saltar</span>
            </button>
            <button
              type="button"
              onClick={onToggleTouch}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                touchEnabled
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
              title="Activar controles táctiles para celular"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Táctil</span>
            </button>
            <button
              type="button"
              onClick={onToggleMute}
              className="p-1.5 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
              aria-label={muted ? 'Activar audio' : 'Silenciar audio'}
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          {/* Quality Preset (Alta / Móvil), Subtle Bloom & Solar Elevation */}
          <div className="flex items-center gap-2.5">
            <div className="flex items-center gap-1 p-1 bg-slate-900 rounded-lg border border-white/8">
              <button
                type="button"
                onClick={onToggleQuality}
                className={`px-2.5 py-1 text-xs rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  qualityMode === 'high'
                    ? 'bg-amber-400/20 text-amber-300 font-medium'
                    : 'bg-white/10 text-emerald-300 font-medium'
                }`}
                title="Alternar posprocesado, pasto instanciado y resolución para móviles"
              >
                {qualityMode === 'high' ? 'Calidad: Alta' : 'Calidad: Móvil'}
              </button>
              <button
                type="button"
                onClick={() => onChangePost({ ...postConfig, bloom: !postConfig.bloom })}
                className={`px-2 py-1 text-xs rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  postConfig.bloom ? 'bg-white/15 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Bloom
              </button>
            </div>

            <label className="flex items-center gap-1.5 text-xs text-slate-300 whitespace-nowrap shrink-0">
              <Sun className="w-3.5 h-3.5 text-amber-300" />
              <input
                type="range"
                min={2}
                max={82}
                value={postConfig.sunElevation}
                onChange={(e) =>
                  onChangePost({ ...postConfig, sunElevation: Number(e.target.value) })
                }
                className="w-20 accent-amber-400 cursor-pointer"
                aria-label="Elevación solar"
              />
            </label>
          </div>
        </div>

        {/* Clean Unboxed Status Line (Zero Pills, Zero Pulsing Dots) */}
        <div className="mt-2.5 pt-2 border-t border-white/8 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-2 font-mono tabular-nums">
            <span className="text-slate-200">
              Munición {hud.isReloading ? 'Recargando' : `${hud.ammo}/${hud.maxAmmo}`}
            </span>
            <span aria-hidden="true">·</span>
            <span>Animación {hud.animState}</span>
            <span aria-hidden="true">·</span>
            <span>Impactos {hud.decalsCount}</span>
          </div>
          <div className="flex items-center gap-2">
            <span>WASD Mover</span>
            <span aria-hidden="true">·</span>
            <span>Shift Correr</span>
            <span aria-hidden="true">·</span>
            <span>Espacio Saltar</span>
            <span aria-hidden="true">·</span>
            <span>Clic / F Disparar</span>
            <span aria-hidden="true">·</span>
            <span>R Recargar</span>
          </div>
        </div>
      </div>
    </div>
  );
};
