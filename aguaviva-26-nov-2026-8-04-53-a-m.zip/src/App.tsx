/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { AguaVivaEngine } from './engine/AguaVivaEngine';
import { BottomControlDock } from './components/BottomControlDock';
import { MobileTouchControls } from './components/MobileTouchControls';
import { WorkspaceDrawer, type DrawerSection } from './components/WorkspaceDrawer';
import type {
  AIDesignResponse,
  AvatarParams,
  BlockchainState,
  CameraPreset,
  FacialExpressionType,
  HouseParams,
  PostProcessingConfig,
  QualityPreset,
  TwinTelemetry,
  WeaponHUDState,
} from './types/aguaviva';

const INITIAL_HOUSE: HouseParams = {
  width: 12.5,
  depth: 10.0,
  height: 5.5,
  floors: 2,
  wallMaterial: 'concrete',
  roofStyle: 'flat_solar',
  accentColor: '#38bdf8',
  glassRatio: 0.65,
  solarPanels: 8,
  hydroTurbine: true,
};

const INITIAL_AVATAR: AvatarParams = {
  skinTone: '#e5b18c',
  hairColor: '#1f2937',
  eyeColor: '#2563eb',
  armorColor: '#1e293b',
  energyColor: '#22d3ee',
  armorStyle: 'freefire_tactical',
  weaponFinish: 'brushed_titanium',
  faceShape: 'heroic',
  eyeStyle: 'almond',
  mouthStyle: 'balanced',
  hairStyle: 'styled_spiky_mlbb',
  expression: 'determined',
  gazeDirection: 'center',
  heightScale: 1.0,
  sssIntensity: 0.78,
};

const INITIAL_POST: PostProcessingConfig = {
  bloom: true,
  bloomStrength: 0.34,
  ssao: false,
  motionBlur: false,
  sunElevation: 8,
  sunAzimuth: 232,
};

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<AguaVivaEngine | null>(null);

  const [activeDrawer, setActiveDrawer] = useState<DrawerSection>('none');
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('third_person');
  const [house, setHouse] = useState<HouseParams>(INITIAL_HOUSE);
  const [avatar, setAvatar] = useState<AvatarParams>(INITIAL_AVATAR);
  const [postConfig, setPostConfig] = useState<PostProcessingConfig>(INITIAL_POST);
  const [qualityMode, setQualityMode] = useState<QualityPreset>(() =>
    typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches
      ? 'mobile'
      : 'high'
  );
  const [muted, setMuted] = useState(false);
  const [touchEnabled, setTouchEnabled] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia('(pointer: coarse)').matches : false
  );
  const [contextLost, setContextLost] = useState(false);

  const [hud, setHud] = useState<WeaponHUDState>({
    ammo: 30,
    maxAmmo: 30,
    isReloading: false,
    decalsCount: 0,
    animState: 'Idle',
  });

  const [blockchain, setBlockchain] = useState<BlockchainState | null>(null);
  const [telemetry, setTelemetry] = useState<TwinTelemetry | null>(null);

  // Initialize Three.js Engine once in isolated mount container
  useEffect(() => {
    const mountEl = canvasMountRef.current;
    if (!mountEl) return;

    const initialQ: QualityPreset =
      typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches
        ? 'mobile'
        : 'high';

    const engine = new AguaVivaEngine(
      mountEl,
      INITIAL_HOUSE,
      INITIAL_AVATAR,
      INITIAL_POST,
      initialQ,
      {
        onHudUpdate: (nextHud) => setHud(nextHud),
        onContextLost: (lost) => setContextLost(lost),
      }
    );
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  // Keyboard shortcuts: H = Zen/Collapse HUD, Escape = Close drawer
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.code === 'KeyH') {
        setDockCollapsed((prev) => !prev);
      } else if (e.code === 'Escape') {
        setActiveDrawer('none');
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Load Dilithium-3 blockchain ledger & poll Digital Twin telemetry
  useEffect(() => {
    let alive = true;

    const fetchState = async () => {
      try {
        const res = await fetch('/api/blockchain/state');
        if (res.ok && alive) {
          const data: BlockchainState = await res.json();
          setBlockchain(data);
        }
      } catch {
        // Ignore transient network errors
      }
    };

    const fetchTelemetry = async () => {
      try {
        const res = await fetch('/api/twin/telemetry');
        if (res.ok && alive) {
          const data: TwinTelemetry = await res.json();
          setTelemetry(data);
          engineRef.current?.updateTelemetry(data.riverTurbulence, data.solarIrradiance);
        }
      } catch {
        // Ignore transient network errors
      }
    };

    fetchState();
    fetchTelemetry();
    const timer = window.setInterval(fetchTelemetry, 4000);
    return () => {
      alive = false;
      window.clearInterval(timer);
    };
  }, []);

  const handleHouseChange = (next: HouseParams) => {
    setHouse(next);
    engineRef.current?.updateHouse(next);
  };

  const handleAvatarChange = (next: AvatarParams) => {
    setAvatar(next);
    engineRef.current?.updateAvatar(next);
  };

  const handlePostChange = (next: PostProcessingConfig) => {
    setPostConfig(next);
    engineRef.current?.updatePostProcessing(next);
  };

  const handleToggleQuality = () => {
    setQualityMode((prev) => {
      const next: QualityPreset = prev === 'high' ? 'mobile' : 'high';
      engineRef.current?.setQualityMode(next);
      return next;
    });
  };

  const handleSelectPreset = (preset: CameraPreset) => {
    setCameraPreset(preset);
    engineRef.current?.setCameraPreset(preset);
  };

  const handleToggleMute = () => {
    setMuted((prev) => {
      const next = !prev;
      engineRef.current?.setAudioMuted(next);
      return next;
    });
  };

  const handleCycleExpression = () => {
    const order: FacialExpressionType[] = ['serene', 'smile', 'determined', 'surprised', 'wink'];
    const idx = order.indexOf(avatar.expression);
    const nextExpr = order[(idx + 1) % order.length];
    handleAvatarChange({ ...avatar, expression: nextExpr });
  };

  const handleSelectSection = (sec: DrawerSection) => {
    if (sec === 'none') {
      setActiveDrawer('none');
      return;
    }
    setActiveDrawer((curr) => (curr === sec ? 'none' : sec));
    if (sec === 'house') handleSelectPreset('residence');
    else if (sec === 'avatar') handleSelectPreset('avatar_inspect');
    else if (sec === 'twin') handleSelectPreset('global');
  };

  const handleSubmitTx = async (payload: {
    type: 'MINT_DEED' | 'TRANSFER' | 'ECO_REWARD' | 'AVATAR_FORGE';
    to?: string;
    amount?: number;
    summary?: string;
    houseParams?: HouseParams;
    avatarParams?: AvatarParams;
  }): Promise<string | null> => {
    try {
      const res = await fetch('/api/blockchain/tx', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        return data.error || 'No se pudo completar la transacción Dilithium-3.';
      }
      setBlockchain(data.state);
      return null;
    } catch {
      return 'Error de red al conectar con el nodo postcuántico.';
    }
  };

  const handleRunAIDesign = async (
    prompt: string
  ): Promise<{ title: string; notes: string } | string> => {
    try {
      const res = await fetch('/api/ai/design', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      if (!res.ok) {
        return data.error || 'Error ejecutando el diseñador generativo.';
      }
      const parsed = data as AIDesignResponse;
      if (parsed.house) handleHouseChange(parsed.house);
      if (parsed.avatar) handleAvatarChange(parsed.avatar);
      handleSelectPreset('residence');
      return { title: parsed.conceptTitle, notes: parsed.architecturalNotes };
    } catch {
      return 'Error de conexión con el servicio generativo de AguaViva.';
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none">
      {/* Dedicated WebGL Mount Container */}
      <div
        ref={canvasMountRef}
        className="w-full h-full cursor-crosshair"
        aria-label="Simulación 3D AguaViva"
      />

      {/* WebGL Context Loss Fallback Overlay */}
      {contextLost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/95 p-6 text-center">
          <div className="max-w-md space-y-2">
            <h2 className="font-display text-lg font-semibold text-white">
              Contexto gráfico WebGL suspendido
            </h2>
            <p className="text-sm text-slate-400">
              El navegador liberó temporalmente los recursos de GPU. Recarga o restaura la pestaña para continuar en el gemelo digital.
            </p>
          </div>
        </div>
      )}

      {/* Subtle Aim Reticle in Third-Person Mode */}
      {cameraPreset === 'third_person' && activeDrawer === 'none' && (
        <div
          aria-hidden="true"
          className="pointer-events-none fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 w-5 h-5 flex items-center justify-center opacity-65"
        >
          <span className="w-1 h-1 rounded-full bg-cyan-300" />
        </div>
      )}

      {/* Top Bar Contract: 1 Row, 3 Zones separated by gap-8 */}
      <header className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between gap-8 px-6 py-3 bg-slate-950/90 border-b border-white/10">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => {
            setActiveDrawer('none');
            handleSelectPreset('third_person');
          }}
          className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 cursor-pointer"
        >
          AguaViva
        </button>

        {/* Zone 2: 5 concise single-line text navigation links */}
        <nav className="flex items-center gap-4 md:gap-6 overflow-x-auto text-xs md:text-sm font-medium text-slate-300">
          <button
            type="button"
            onClick={() => {
              setActiveDrawer('none');
              handleSelectPreset('third_person');
            }}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeDrawer === 'none' ? 'text-white underline underline-offset-4' : ''
            }`}
          >
            Explorador 3D
          </button>
          <button
            type="button"
            onClick={() => handleSelectSection('house')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeDrawer === 'house' ? 'text-cyan-300 underline underline-offset-4' : ''
            }`}
          >
            Casa Paramétrica
          </button>
          <button
            type="button"
            onClick={() => handleSelectSection('avatar')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeDrawer === 'avatar' ? 'text-cyan-300 underline underline-offset-4' : ''
            }`}
          >
            Avatar y Arsenal
          </button>
          <button
            type="button"
            onClick={() => handleSelectSection('bank')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeDrawer === 'bank' ? 'text-cyan-300 underline underline-offset-4' : ''
            }`}
          >
            Banca Dilithium-3
          </button>
          <button
            type="button"
            onClick={() => handleSelectSection('twin')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeDrawer === 'twin' ? 'text-cyan-300 underline underline-offset-4' : ''
            }`}
          >
            Gemelo Urbano
          </button>
        </nav>

        {/* Zone 3: 1 primary CTA action */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={() => handleSelectSection('ai')}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Diseñar con IA
          </button>
        </div>
      </header>

      {/* Slide-Over Workspace Drawer (opens on demand, leaves 3D center clear) */}
      <WorkspaceDrawer
        section={activeDrawer}
        onClose={() => setActiveDrawer('none')}
        house={house}
        onChangeHouse={handleHouseChange}
        avatar={avatar}
        onChangeAvatar={handleAvatarChange}
        blockchain={blockchain}
        telemetry={telemetry}
        onSubmitTx={handleSubmitTx}
        onRunAIDesign={handleRunAIDesign}
      />

      {/* Mobile Touch Virtual Joystick & Tactical Buttons */}
      <MobileTouchControls
        visible={touchEnabled && activeDrawer === 'none'}
        onMove={(x, y) => engineRef.current?.setTouchMove(x, y)}
        onFire={() => engineRef.current?.triggerFire()}
        onJump={() => engineRef.current?.triggerJump()}
        onReload={() => engineRef.current?.triggerReload()}
        onCycleExpression={handleCycleExpression}
      />

      {/* Collapsible Unified Bottom Control Dock */}
      <BottomControlDock
        collapsed={dockCollapsed}
        onToggleCollapse={() => setDockCollapsed((prev) => !prev)}
        cameraPreset={cameraPreset}
        onSelectPreset={handleSelectPreset}
        postConfig={postConfig}
        onChangePost={handlePostChange}
        qualityMode={qualityMode}
        onToggleQuality={handleToggleQuality}
        hud={hud}
        muted={muted}
        onToggleMute={handleToggleMute}
        touchEnabled={touchEnabled}
        onToggleTouch={() => setTouchEnabled((prev) => !prev)}
        onFire={() => engineRef.current?.triggerFire()}
        onReload={() => engineRef.current?.triggerReload()}
        onJump={() => engineRef.current?.triggerJump()}
      />
    </div>
  );
}
