export type WallMaterialType = 'concrete' | 'brick' | 'cedar' | 'titanium';
export type RoofStyleType = 'flat_solar' | 'gabled' | 'parametric_vault';

export interface HouseParams {
  width: number;       // 8 - 18 m
  depth: number;       // 7 - 15 m
  height: number;      // 3.5 - 8.5 m
  floors: number;      // 1 - 2
  wallMaterial: WallMaterialType;
  roofStyle: RoofStyleType;
  accentColor: string;
  glassRatio: number;  // 0.2 - 0.85
  solarPanels: number; // 0 - 12
  hydroTurbine: boolean;
}

export type ArmorStyleType =
  | 'crysis_nanosuit'
  | 'mu_valkyrie'
  | 'freefire_tactical'
  | 'mlbb_hero';
export type WeaponFinishType = 'anodized_carbon' | 'brushed_titanium' | 'cobalt_alloy';
export type FaceShapeType = 'heroic' | 'elven_mu' | 'tactical_square' | 'youthful_mlbb';
export type EyeStyleType = 'almond' | 'mystic_mu' | 'intense_crysis' | 'expressive_mlbb';
export type MouthStyleType = 'balanced' | 'full_defined' | 'sharp_tactical' | 'natural_smile';
export type HairStyleType =
  | 'tactical_short'
  | 'heroic_long_mu'
  | 'styled_spiky_mlbb'
  | 'urban_waves'
  | 'crysis_helmet';
export type FacialExpressionType = 'serene' | 'smile' | 'determined' | 'surprised' | 'wink';
export type GazeDirectionType = 'center' | 'left' | 'right' | 'up' | 'down';

export type QualityPreset = 'high' | 'mobile';

export interface AvatarParams {
  skinTone: string;
  hairColor: string;
  eyeColor: string;
  armorColor: string;
  energyColor: string;
  armorStyle: ArmorStyleType;
  weaponFinish: WeaponFinishType;
  faceShape: FaceShapeType;
  eyeStyle: EyeStyleType;
  mouthStyle: MouthStyleType;
  hairStyle: HairStyleType;
  expression: FacialExpressionType;
  gazeDirection: GazeDirectionType;
  heightScale: number; // 0.9 - 1.15
  sssIntensity: number; // 0.2 - 1.0
  useGlbAvatar?: boolean;
}

export type AvatarAnimState = 'Idle' | 'Walk' | 'Run' | 'Jump' | 'Shoot' | 'Reload';

export type CameraPreset = 'global' | 'third_person' | 'avatar_inspect' | 'residence';

export interface PostProcessingConfig {
  bloom: boolean;
  bloomStrength: number;
  ssao: boolean;
  motionBlur: boolean;
  sunElevation: number; // 2 - 82 deg (Golden Hour supported)
  sunAzimuth: number;   // 0 - 360 deg
}

export interface WeaponHUDState {
  ammo: number;
  maxAmmo: number;
  isReloading: boolean;
  decalsCount: number;
  animState: AvatarAnimState;
}

export interface DilithiumTransaction {
  txId: string;
  type: 'MINT_DEED' | 'TRANSFER' | 'ECO_REWARD' | 'AVATAR_FORGE';
  from: string;
  to: string;
  amount: number;
  assetHash: string;
  dilithiumSignature: string; // Hex prefix + length metadata (3,293 bytes ML-DSA-65)
  publicKeyFingerprint: string; // 1,952 bytes ML-DSA-65 pubkey hash
  timestamp: string;
  summary: string;
}

export interface DilithiumBlock {
  height: number;
  blockHash: string;
  prevHash: string;
  merkleRoot: string;
  validatorNode: string;
  algorithm: 'CRYSTALS-Dilithium-3 (ML-DSA-65)';
  timestamp: string;
  transactions: DilithiumTransaction[];
}

export interface CitizenDeed {
  deedId: string;
  assetKind: 'RESIDENCE_TWIN' | 'AVATAR_BIO' | 'ARMORY_CARBINE';
  title: string;
  blueprintHash: string;
  dilithiumProof: string;
  updatedAt: string;
}

export interface BlockchainState {
  networkName: string;
  consensus: string;
  quantumSecurityLevel: string;
  blockHeight: number;
  citizenAddress: string;
  balanceAGV: number;
  stakedHydroAGV: number;
  publicKeyHex: string;
  deeds: CitizenDeed[];
  blocks: DilithiumBlock[];
}

export interface DistrictMetric {
  id: string;
  name: string;
  waterPurityPct: number;
  solarOutputMW: number;
  riverFlowM3s: number;
  airQualityAQI: number;
  activeNodes: number;
}

export interface TwinTelemetry {
  timestamp: string;
  globalCitizensOnline: number;
  totalCleanWaterM3: number;
  renewableGridPct: number;
  carbonOffsetTons: number;
  riverTurbulence: number;
  solarIrradiance: number;
  districts: DistrictMetric[];
}

export interface AIDesignResponse {
  conceptTitle: string;
  architecturalNotes: string;
  house: HouseParams;
  avatar: AvatarParams;
}
