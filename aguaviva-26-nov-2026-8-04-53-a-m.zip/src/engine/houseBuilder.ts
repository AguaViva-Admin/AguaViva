import * as THREE from 'three';
import type { HouseParams } from '../types/aguaviva';
import type { WorldTextures } from './pbrTextures';
import {
  createAnisotropicMetalMaterial,
  createArchitecturalGlassMaterial,
  createWallPBRMaterial,
} from './materials';
import { groundHeightAt } from './terrain';

export interface CityAndHouseSystem {
  group: THREE.Group;
  houseGroup: THREE.Group;
  collidableMeshes: THREE.Object3D[];
  rebuildHouse: (params: HouseParams) => void;
  update: (elapsed: number, solarIrradiance: number) => void;
  dispose: () => void;
}

function disposeGroupChildren(grp: THREE.Group) {
  grp.traverse((obj) => {
    if (obj instanceof THREE.Mesh) {
      obj.geometry.dispose();
      if (Array.isArray(obj.material)) {
        obj.material.forEach((m) => m.dispose());
      } else {
        obj.material.dispose();
      }
    }
  });
  grp.clear();
}

export function createCityAndHouseSystem(
  textures: WorldTextures,
  isSoftwareGl: boolean,
  initialHouse: HouseParams
): CityAndHouseSystem {
  const group = new THREE.Group();
  const houseGroup = new THREE.Group();
  const cityGroup = new THREE.Group();
  const collidableMeshes: THREE.Object3D[] = [];
  const cityCollidables: THREE.Object3D[] = [];
  let houseCollidables: THREE.Object3D[] = [];

  let turbineRotor: THREE.Group | null = null;
  const hydroBeaconRings: THREE.Mesh[] = [];

  group.add(houseGroup);
  group.add(cityGroup);

  const rebuildCollidables = () => {
    collidableMeshes.length = 0;
    collidableMeshes.push(...houseCollidables, ...cityCollidables);
  };

  // -------------------------------------------------------------------------
  // 1. Digital Twin Smart City Infrastructure (Asphalt Avenue, Eco-Towers, Bridge)
  // -------------------------------------------------------------------------
  const baseY = groundHeightAt(0, 0);

  // PBR Asphalt Urban Boulevard (Z-axis along x = 18)
  const roadGeo = new THREE.BoxGeometry(7.4, 0.16, 110);
  const roadMat = new THREE.MeshStandardMaterial({
    map: textures.asphalt.map,
    normalMap: textures.asphalt.normalMap,
    normalScale: new THREE.Vector2(1.3, 1.3),
    roughnessMap: textures.asphalt.roughnessMap,
    roughness: 0.9,
    metalness: 0.05,
  });
  const roadMesh = new THREE.Mesh(roadGeo, roadMat);
  roadMesh.position.set(18, baseY + 0.05, 0);
  roadMesh.receiveShadow = true;
  cityGroup.add(roadMesh);
  cityCollidables.push(roadMesh);

  // Sidewalk curbs
  const curbGeo = new THREE.BoxGeometry(0.45, 0.24, 110);
  const curbMat = createWallPBRMaterial('concrete', textures);
  [-3.85, 3.85].forEach((dx) => {
    const curb = new THREE.Mesh(curbGeo, curbMat);
    curb.position.set(18 + dx, baseY + 0.12, 0);
    curb.castShadow = true;
    curb.receiveShadow = true;
    cityGroup.add(curb);
    cityCollidables.push(curb);
  });

  // Smart Solar Streetlamps + Hydro-Grid Monitoring Pylons
  const poleMat = createAnisotropicMetalMaterial('#334155', textures, 0.28, 0.9);
  const beaconMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#06b6d4'),
    emissive: new THREE.Color('#22d3ee'),
    emissiveIntensity: 2.2,
    roughness: 0.2,
    metalness: 0.4,
  });
  const lampHeadMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#fef08a'),
    emissive: new THREE.Color('#fde047'),
    emissiveIntensity: 1.6,
    roughness: 0.3,
  });

  for (let z = -36; z <= 36; z += 18) {
    const lampGroup = new THREE.Group();
    const ly = groundHeightAt(13.6, z);
    lampGroup.position.set(13.6, ly, z);

    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 5.2, 10), poleMat);
    pole.position.y = 2.6;
    pole.castShadow = true;
    lampGroup.add(pole);

    const arm = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.1, 0.12), poleMat);
    arm.position.set(0.65, 5.1, 0);
    lampGroup.add(arm);

    const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.08, 0.25), lampHeadMat);
    lamp.position.set(1.15, 5.02, 0);
    lampGroup.add(lamp);

    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.03, 8, 20), beaconMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 1.6;
    lampGroup.add(ring);
    hydroBeaconRings.push(ring);

    cityGroup.add(lampGroup);
    cityCollidables.push(pole);
  }

  // Neighboring Multi-Part Digital Twin Eco-Towers (across the boulevard)
  const glassMat = createArchitecturalGlassMaterial(isSoftwareGl, '#93c5fd');
  const towerConfigs = [
    { x: 27, z: -22, w: 9, d: 9, h: 15, matType: 'concrete' as const },
    { x: 28, z: 6, w: 10, d: 11, h: 21, matType: 'titanium' as const },
    { x: 26, z: 28, w: 8.5, d: 8.5, h: 12.5, matType: 'brick' as const },
  ];

  towerConfigs.forEach((cfg) => {
    const tGroup = new THREE.Group();
    const ty = groundHeightAt(cfg.x, cfg.z);
    tGroup.position.set(cfg.x, ty - 0.1, cfg.z);

    const bodyMat = createWallPBRMaterial(cfg.matType, textures);
    const podium = new THREE.Mesh(
      new THREE.BoxGeometry(cfg.w + 1.4, 2.2, cfg.d + 1.4),
      createWallPBRMaterial('concrete', textures)
    );
    podium.position.y = 1.1;
    podium.castShadow = true;
    podium.receiveShadow = true;
    tGroup.add(podium);
    cityCollidables.push(podium);

    const core = new THREE.Mesh(new THREE.BoxGeometry(cfg.w, cfg.h, cfg.d), bodyMat);
    core.position.y = 2.2 + cfg.h / 2;
    core.castShadow = true;
    core.receiveShadow = true;
    tGroup.add(core);
    cityCollidables.push(core);

    // Glass facade curtain strips
    const curtain = new THREE.Mesh(
      new THREE.BoxGeometry(cfg.w + 0.16, cfg.h * 0.72, cfg.d * 0.65),
      glassMat
    );
    curtain.position.y = 2.2 + cfg.h * 0.52;
    tGroup.add(curtain);

    // Rooftop solar canopy + Dilithium relay spire
    const canopy = new THREE.Mesh(
      new THREE.BoxGeometry(cfg.w * 0.85, 0.22, cfg.d * 0.85),
      new THREE.MeshStandardMaterial({
        map: textures.solarCell.map,
        normalMap: textures.solarCell.normalMap,
        roughness: 0.18,
        metalness: 0.55,
      })
    );
    canopy.position.y = 2.2 + cfg.h + 0.5;
    canopy.castShadow = true;
    tGroup.add(canopy);

    const spire = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.14, 3.2, 8), poleMat);
    spire.position.y = 2.2 + cfg.h + 2.1;
    tGroup.add(spire);

    cityGroup.add(tGroup);
  });

  // Hydro-Dam / River Monitoring Bridge at x = -15, z = 0
  const bridgeGroup = new THREE.Group();
  const bridgeY = groundHeightAt(-14, 0) + 0.4;
  bridgeGroup.position.set(-22, bridgeY, 0);
  const deck = new THREE.Mesh(
    new THREE.BoxGeometry(20, 0.45, 4.2),
    createWallPBRMaterial('concrete', textures)
  );
  deck.castShadow = true;
  deck.receiveShadow = true;
  bridgeGroup.add(deck);
  cityCollidables.push(deck);

  [-1.9, 1.9].forEach((rz) => {
    const rail = new THREE.Mesh(new THREE.BoxGeometry(20, 0.85, 0.14), poleMat);
    rail.position.set(0, 0.62, rz);
    rail.castShadow = true;
    bridgeGroup.add(rail);
    cityCollidables.push(rail);
  });
  cityGroup.add(bridgeGroup);

  // -------------------------------------------------------------------------
  // 2. Parametric User-Customizable Eco-Residence ("Casa AguaViva")
  // -------------------------------------------------------------------------
  const rebuildHouse = (params: HouseParams) => {
    disposeGroupChildren(houseGroup);
    houseCollidables = [];
    turbineRotor = null;

    const hx = 0;
    const hz = 0;
    const hy = groundHeightAt(hx, hz);
    houseGroup.position.set(hx, hy, hz);

    const w = THREE.MathUtils.clamp(params.width, 8, 18);
    const d = THREE.MathUtils.clamp(params.depth, 7, 15);
    const floorH = THREE.MathUtils.clamp(params.height, 3.5, 8.5);
    const floors = Math.max(1, Math.min(2, Math.round(params.floors)));
    const totalH = floorH * (floors === 2 ? 1.55 : 1.0);

    const wallMat = createWallPBRMaterial(params.wallMaterial, textures);
    const plinthMat = createWallPBRMaterial('concrete', textures);
    const trimMat = createAnisotropicMetalMaterial(params.accentColor, textures, 0.25, 0.88);
    const houseGlassMat = createArchitecturalGlassMaterial(isSoftwareGl, '#bae6fd');

    // 1. Cantilevered Foundation Plinth & Eco-Terrace
    const plinth = new THREE.Mesh(new THREE.BoxGeometry(w + 2.6, 0.55, d + 3.0), plinthMat);
    plinth.position.set(0, 0.275, 0.4);
    plinth.castShadow = true;
    plinth.receiveShadow = true;
    houseGroup.add(plinth);
    houseCollidables.push(plinth);

    // Recessed Aqua-Cistern / Reflecting Pool on front terrace
    const poolFrame = new THREE.Mesh(
      new THREE.BoxGeometry(w * 0.45, 0.18, 2.2),
      trimMat
    );
    poolFrame.position.set(-w * 0.2, 0.58, d * 0.5 + 1.0);
    poolFrame.receiveShadow = true;
    houseGroup.add(poolFrame);

    const poolWater = new THREE.Mesh(
      new THREE.PlaneGeometry(w * 0.41, 1.9),
      new THREE.MeshPhysicalMaterial({
        color: new THREE.Color('#0284c7'),
        roughness: 0.05,
        metalness: 0.1,
        clearcoat: 1.0,
      })
    );
    poolWater.rotation.x = -Math.PI / 2;
    poolWater.position.set(-w * 0.2, 0.68, d * 0.5 + 1.0);
    houseGroup.add(poolWater);

    // 2. Structural Core Walls (leaving panoramic front glass bay)
    const wallThick = 0.36;
    const backWall = new THREE.Mesh(new THREE.BoxGeometry(w, totalH, wallThick), wallMat);
    backWall.position.set(0, 0.55 + totalH / 2, -d / 2 + wallThick / 2);
    backWall.castShadow = true;
    backWall.receiveShadow = true;
    houseGroup.add(backWall);
    houseCollidables.push(backWall);

    const leftWall = new THREE.Mesh(new THREE.BoxGeometry(wallThick, totalH, d), wallMat);
    leftWall.position.set(-w / 2 + wallThick / 2, 0.55 + totalH / 2, 0);
    leftWall.castShadow = true;
    leftWall.receiveShadow = true;
    houseGroup.add(leftWall);
    houseCollidables.push(leftWall);

    const rightWall = new THREE.Mesh(new THREE.BoxGeometry(wallThick, totalH, d), wallMat);
    rightWall.position.set(w / 2 - wallThick / 2, 0.55 + totalH / 2, 0);
    rightWall.castShadow = true;
    rightWall.receiveShadow = true;
    houseGroup.add(rightWall);
    houseCollidables.push(rightWall);

    // Front solid pier + panoramic glass wall based on glassRatio
    const solidWidth = w * (1 - THREE.MathUtils.clamp(params.glassRatio, 0.2, 0.85));
    if (solidWidth > 0.6) {
      const frontPier = new THREE.Mesh(new THREE.BoxGeometry(solidWidth, totalH, wallThick), wallMat);
      frontPier.position.set(-w / 2 + solidWidth / 2, 0.55 + totalH / 2, d / 2 - wallThick / 2);
      frontPier.castShadow = true;
      frontPier.receiveShadow = true;
      houseGroup.add(frontPier);
      houseCollidables.push(frontPier);
    }

    const glassWidth = Math.max(1.5, w - solidWidth - 0.5);
    const frontGlass = new THREE.Mesh(
      new THREE.BoxGeometry(glassWidth, totalH - 0.4, 0.08),
      houseGlassMat
    );
    frontGlass.position.set(w / 2 - glassWidth / 2 - 0.25, 0.55 + totalH / 2, d / 2 - 0.2);
    houseGroup.add(frontGlass);
    houseCollidables.push(frontGlass);

    // Architectural window mullions
    const mullionCount = Math.max(2, Math.floor(glassWidth / 2.2));
    for (let m = 0; m <= mullionCount; m++) {
      const mx = w / 2 - glassWidth - 0.25 + (m / mullionCount) * glassWidth;
      const mullion = new THREE.Mesh(new THREE.BoxGeometry(0.1, totalH, 0.18), trimMat);
      mullion.position.set(mx, 0.55 + totalH / 2, d / 2 - 0.2);
      mullion.castShadow = true;
      houseGroup.add(mullion);
    }

    // Second Floor Slab & Balcony Deck if floors === 2
    if (floors === 2) {
      const midY = 0.55 + totalH * 0.5;
      const slab = new THREE.Mesh(new THREE.BoxGeometry(w + 1.2, 0.28, d + 1.6), trimMat);
      slab.position.set(0, midY, 0.5);
      slab.castShadow = true;
      slab.receiveShadow = true;
      houseGroup.add(slab);
      houseCollidables.push(slab);

      const balconyRail = new THREE.Mesh(new THREE.BoxGeometry(w + 1.1, 0.85, 0.06), houseGlassMat);
      balconyRail.position.set(0, midY + 0.55, d / 2 + 1.22);
      houseGroup.add(balconyRail);
    }

    // Interior warm ambient glow light + interior floor
    const interiorFloor = new THREE.Mesh(
      new THREE.PlaneGeometry(w - 0.5, d - 0.5),
      createWallPBRMaterial('cedar', textures)
    );
    interiorFloor.rotation.x = -Math.PI / 2;
    interiorFloor.position.set(0, 0.57, 0);
    interiorFloor.receiveShadow = true;
    houseGroup.add(interiorFloor);

    const warmLight = new THREE.PointLight('#ffedd5', 2.4, 14, 1.6);
    warmLight.position.set(0, 0.55 + totalH * 0.65, 0);
    houseGroup.add(warmLight);

    // 3. Parametric Roof Architecture
    const roofBaseY = 0.55 + totalH;
    let solarStartY = roofBaseY + 0.4;

    if (params.roofStyle === 'gabled') {
      const ridgeH = 2.3;
      const shape = new THREE.Shape();
      shape.moveTo(-w / 2 - 0.7, 0);
      shape.lineTo(0, ridgeH);
      shape.lineTo(w / 2 + 0.7, 0);
      shape.lineTo(w / 2 + 0.7, -0.25);
      shape.lineTo(-w / 2 - 0.7, -0.25);
      shape.closePath();

      const gableGeo = new THREE.ExtrudeGeometry(shape, {
        depth: d + 1.4,
        bevelEnabled: true,
        bevelThickness: 0.08,
        bevelSize: 0.08,
        bevelSegments: 2,
      });
      gableGeo.translate(0, 0, -(d + 1.4) / 2);
      const gableMesh = new THREE.Mesh(gableGeo, trimMat);
      gableMesh.position.y = roofBaseY + 0.25;
      gableMesh.castShadow = true;
      gableMesh.receiveShadow = true;
      houseGroup.add(gableMesh);
      houseCollidables.push(gableMesh);
      solarStartY = roofBaseY + ridgeH * 0.55;
    } else if (params.roofStyle === 'parametric_vault') {
      const vaultGeo = new THREE.CylinderGeometry(
        w * 0.56,
        w * 0.56,
        d + 1.4,
        24,
        1,
        false,
        0,
        Math.PI
      );
      vaultGeo.rotateZ(Math.PI / 2);
      vaultGeo.rotateY(Math.PI / 2);
      vaultGeo.scale(1, 0.38, 1);
      const vaultMesh = new THREE.Mesh(vaultGeo, trimMat);
      vaultMesh.position.y = roofBaseY;
      vaultMesh.castShadow = true;
      vaultMesh.receiveShadow = true;
      houseGroup.add(vaultMesh);
      houseCollidables.push(vaultMesh);
      solarStartY = roofBaseY + w * 0.22;
    } else {
      // flat_solar with green living-roof planter perimeter
      const roofSlab = new THREE.Mesh(new THREE.BoxGeometry(w + 1.4, 0.34, d + 1.4), trimMat);
      roofSlab.position.set(0, roofBaseY + 0.17, 0);
      roofSlab.castShadow = true;
      roofSlab.receiveShadow = true;
      houseGroup.add(roofSlab);
      houseCollidables.push(roofSlab);

      const greenRoof = new THREE.Mesh(
        new THREE.BoxGeometry(w * 0.86, 0.14, d * 0.86),
        new THREE.MeshStandardMaterial({
          map: textures.grass.map,
          normalMap: textures.grass.normalMap,
          roughness: 0.92,
        })
      );
      greenRoof.position.set(0, roofBaseY + 0.36, 0);
      greenRoof.receiveShadow = true;
      houseGroup.add(greenRoof);
      solarStartY = roofBaseY + 0.55;
    }

    // 4. Photovoltaic Solar Array
    const panelCount = Math.max(0, Math.min(12, Math.round(params.solarPanels)));
    const solarMat = new THREE.MeshPhysicalMaterial({
      map: textures.solarCell.map,
      normalMap: textures.solarCell.normalMap,
      roughness: 0.14,
      metalness: 0.5,
      clearcoat: 0.9,
      clearcoatRoughness: 0.08,
    });
    const cols = 4;
    for (let i = 0; i < panelCount; i++) {
      const row = Math.floor(i / cols);
      const col = i % cols;
      const px = -w * 0.33 + col * (w * 0.22);
      const pz = -d * 0.25 + row * 2.1;

      const panel = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.07, 1.15), solarMat);
      panel.position.set(px, solarStartY + 0.2, pz);
      panel.rotation.x = 0.28;
      panel.castShadow = true;
      houseGroup.add(panel);
    }

    // 5. Hydro-Wind Energy Micro-Turbine Tower
    if (params.hydroTurbine) {
      const towerX = w / 2 + 1.1;
      const towerZ = -d / 2 + 0.8;
      const mast = new THREE.Mesh(
        new THREE.CylinderGeometry(0.11, 0.2, totalH + 3.2, 12),
        trimMat
      );
      mast.position.set(towerX, (totalH + 3.2) / 2, towerZ);
      mast.castShadow = true;
      houseGroup.add(mast);
      houseCollidables.push(mast);

      const nacelle = new THREE.Mesh(new THREE.CapsuleGeometry(0.22, 0.55, 6, 12), trimMat);
      nacelle.rotation.x = Math.PI / 2;
      nacelle.position.set(towerX, totalH + 3.2, towerZ);
      houseGroup.add(nacelle);

      turbineRotor = new THREE.Group();
      turbineRotor.position.set(towerX, totalH + 3.2, towerZ + 0.42);
      for (let b = 0; b < 3; b++) {
        const blade = new THREE.Mesh(
          new THREE.BoxGeometry(0.16, 1.55, 0.04),
          new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.25, metalness: 0.2 })
        );
        blade.rotation.z = (b * Math.PI * 2) / 3;
        blade.position.set(
          Math.sin(-blade.rotation.z) * 0.78,
          Math.cos(blade.rotation.z) * 0.78,
          0
        );
        blade.castShadow = true;
        turbineRotor.add(blade);
      }
      houseGroup.add(turbineRotor);
    }

    rebuildCollidables();
  };

  rebuildHouse(initialHouse);

  return {
    group,
    houseGroup,
    collidableMeshes,
    rebuildHouse,
    update: (elapsed: number, solarIrradiance: number) => {
      if (turbineRotor) {
        turbineRotor.rotation.z = elapsed * 2.8;
      }
      const glow = 1.4 + (solarIrradiance / 1000) * 1.6 + Math.sin(elapsed * 2.5) * 0.25;
      beaconMat.emissiveIntensity = glow;
      hydroBeaconRings.forEach((r, idx) => {
        r.position.y = 1.55 + Math.sin(elapsed * 2.0 + idx) * 0.08;
      });
    },
    dispose: () => {
      disposeGroupChildren(houseGroup);
      disposeGroupChildren(cityGroup);
      roadMat.dispose();
      curbMat.dispose();
      poleMat.dispose();
      beaconMat.dispose();
      lampHeadMat.dispose();
      glassMat.dispose();
    },
  };
}
