import * as THREE from 'three';
import type { WorldTextures } from './pbrTextures';
import { groundHeightAt } from './terrain';

interface TracerItem {
  mesh: THREE.Mesh;
  active: boolean;
  life: number;
  maxLife: number;
  velocity: THREE.Vector3;
}

interface SparkItem {
  mesh: THREE.Mesh;
  active: boolean;
  life: number;
  maxLife: number;
  velocity: THREE.Vector3;
}

interface SmokeItem {
  sprite: THREE.Sprite;
  active: boolean;
  life: number;
  maxLife: number;
  velocity: THREE.Vector3;
}

export interface CombatEffectsSystem {
  group: THREE.Group;
  fireWeapon: (
    muzzleWorldPos: THREE.Vector3,
    aimOrigin: THREE.Vector3,
    aimDir: THREE.Vector3,
    targets: THREE.Object3D[],
    energyColor: string
  ) => void;
  playReloadAudio: () => void;
  playJumpAudio: () => void;
  getDecalCount: () => number;
  setAudioMuted: (muted: boolean) => void;
  update: (delta: number) => void;
  dispose: () => void;
}

const _raycaster = new THREE.Raycaster();
const _hitNormal = new THREE.Vector3();
const _up = new THREE.Vector3(0, 0, 1);
const _lookMat = new THREE.Matrix4();
const _normalMat = new THREE.Matrix3();

export function createCombatEffectsSystem(textures: WorldTextures): CombatEffectsSystem {
  const group = new THREE.Group();
  group.name = 'CombatVFX';

  // -------------------------------------------------------------------------
  // 1. Muzzle Flash (2D Sprite + High-Intensity Bloom PointLight)
  // -------------------------------------------------------------------------
  const muzzleMat = new THREE.SpriteMaterial({
    map: textures.muzzleFlash,
    color: new THREE.Color('#fff7ed'),
    transparent: true,
    opacity: 0,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const muzzleSprite = new THREE.Sprite(muzzleMat);
  muzzleSprite.scale.set(0.72, 0.72, 1);
  muzzleSprite.visible = false;
  group.add(muzzleSprite);

  const muzzleLight = new THREE.PointLight('#fb923c', 0, 14, 1.8);
  group.add(muzzleLight);
  let muzzleFlashTimer = 0;

  // -------------------------------------------------------------------------
  // 2. Pooled Luminous Ballistic Tracers
  // -------------------------------------------------------------------------
  const tracerGeo = new THREE.CylinderGeometry(0.018, 0.018, 1.9, 6);
  tracerGeo.rotateX(Math.PI / 2);
  const tracerMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#7dd3fc'),
    transparent: true,
    opacity: 0.95,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const tracers: TracerItem[] = [];
  for (let i = 0; i < 16; i++) {
    const mesh = new THREE.Mesh(tracerGeo, tracerMat);
    mesh.visible = false;
    group.add(mesh);
    tracers.push({
      mesh,
      active: false,
      life: 0,
      maxLife: 0.25,
      velocity: new THREE.Vector3(),
    });
  }

  // -------------------------------------------------------------------------
  // 3. Pooled Sparks & Muzzle/Impact Smoke Particles
  // -------------------------------------------------------------------------
  const sparkGeo = new THREE.SphereGeometry(0.028, 6, 6);
  const sparkMat = new THREE.MeshBasicMaterial({
    color: new THREE.Color('#fdba74'),
    blending: THREE.AdditiveBlending,
    transparent: true,
    depthWrite: false,
  });
  const sparks: SparkItem[] = [];
  for (let i = 0; i < 42; i++) {
    const mesh = new THREE.Mesh(sparkGeo, sparkMat);
    mesh.visible = false;
    group.add(mesh);
    sparks.push({
      mesh,
      active: false,
      life: 0,
      maxLife: 0.45,
      velocity: new THREE.Vector3(),
    });
  }

  const smokes: SmokeItem[] = [];
  for (let i = 0; i < 24; i++) {
    const smMat = new THREE.SpriteMaterial({
      map: textures.smokePuff,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });
    const sprite = new THREE.Sprite(smMat);
    sprite.visible = false;
    group.add(sprite);
    smokes.push({
      sprite,
      active: false,
      life: 0,
      maxLife: 0.85,
      velocity: new THREE.Vector3(),
    });
  }

  // -------------------------------------------------------------------------
  // 4. Persistent Impact Decals Ring Buffer (polygonOffset prevents Z-fighting)
  // -------------------------------------------------------------------------
  const MAX_DECALS = 48;
  const decalGeo = new THREE.PlaneGeometry(0.32, 0.32);
  const decalMat = new THREE.MeshStandardMaterial({
    map: textures.bulletDecal,
    transparent: true,
    depthWrite: false,
    roughness: 0.95,
    metalness: 0.05,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const decals: THREE.Mesh[] = [];
  let decalCursor = 0;
  let totalDecalsSpawned = 0;

  // -------------------------------------------------------------------------
  // 5. Procedural Web Audio Synthesizer (Zero External Files)
  // -------------------------------------------------------------------------
  let audioCtx: AudioContext | null = null;
  let isMuted = false;

  const ensureAudio = () => {
    if (isMuted) return null;
    if (!audioCtx && typeof window !== 'undefined') {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (Ctx) audioCtx = new Ctx();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    return audioCtx;
  };

  const playGunshotAudio = () => {
    const ctx = ensureAudio();
    if (!ctx) return;
    const now = ctx.currentTime;

    // White noise crack
    const bufferSize = Math.floor(ctx.sampleRate * 0.14);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.22));
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1400, now);
    filter.frequency.exponentialRampToValueAtTime(280, now + 0.12);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    noise.start(now);

    // Sub punch
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(175, now);
    osc.frequency.exponentialRampToValueAtTime(42, now + 0.09);
    oscGain.gain.setValueAtTime(0.32, now);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(oscGain);
    oscGain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.11);
  };

  const playReloadAudio = () => {
    const ctx = ensureAudio();
    if (!ctx) return;
    const now = ctx.currentTime;
    [0, 0.45, 0.92].forEach((offset, idx) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(idx === 2 ? 620 : 380, now + offset);
      g.gain.setValueAtTime(0.09, now + offset);
      g.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.06);
      osc.connect(g);
      g.connect(ctx.destination);
      osc.start(now + offset);
      osc.stop(now + offset + 0.065);
    });
  };

  const playJumpAudio = () => {
    const ctx = ensureAudio();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(110, now);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.12);
    g.gain.setValueAtTime(0.12, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.15);
  };

  const spawnSpark = (origin: THREE.Vector3, dir: THREE.Vector3, speed: number) => {
    const slot = sparks.find((s) => !s.active);
    if (!slot) return;
    slot.active = true;
    slot.life = 0;
    slot.maxLife = 0.25 + Math.random() * 0.25;
    slot.mesh.position.copy(origin);
    slot.mesh.visible = true;
    slot.velocity
      .copy(dir)
      .addScaledVector(
        new THREE.Vector3(Math.random() - 0.5, Math.random() * 0.8, Math.random() - 0.5),
        1.1
      )
      .normalize()
      .multiplyScalar(speed * (0.6 + Math.random() * 0.7));
  };

  const spawnSmoke = (origin: THREE.Vector3, scaleStart: number) => {
    const slot = smokes.find((s) => !s.active);
    if (!slot) return;
    slot.active = true;
    slot.life = 0;
    slot.maxLife = 0.65 + Math.random() * 0.35;
    slot.sprite.position.copy(origin);
    slot.sprite.scale.setScalar(scaleStart);
    (slot.sprite.material as THREE.SpriteMaterial).opacity = 0.45;
    slot.sprite.visible = true;
    slot.velocity.set(
      (Math.random() - 0.5) * 0.6,
      0.8 + Math.random() * 0.9,
      (Math.random() - 0.5) * 0.6
    );
  };

  const spawnDecal = (point: THREE.Vector3, normal: THREE.Vector3) => {
    let mesh: THREE.Mesh;
    if (decals.length < MAX_DECALS) {
      mesh = new THREE.Mesh(decalGeo, decalMat);
      group.add(mesh);
      decals.push(mesh);
    } else {
      mesh = decals[decalCursor];
      decalCursor = (decalCursor + 1) % MAX_DECALS;
    }

    mesh.position.copy(point).addScaledVector(normal, 0.018);
    mesh.quaternion.setFromUnitVectors(_up, normal);
    mesh.rotateZ(Math.random() * Math.PI * 2);
    const s = 0.75 + Math.random() * 0.45;
    mesh.scale.setScalar(s);
    mesh.visible = true;
    totalDecalsSpawned++;
  };

  const fireWeapon = (
    muzzleWorldPos: THREE.Vector3,
    aimOrigin: THREE.Vector3,
    aimDir: THREE.Vector3,
    targets: THREE.Object3D[],
    energyColor: string
  ) => {
    playGunshotAudio();

    // 1. Muzzle Flash Sprite + Dynamic PointLight
    muzzleSprite.position.copy(muzzleWorldPos);
    muzzleSprite.material.rotation = Math.random() * Math.PI * 2;
    muzzleSprite.material.opacity = 1;
    muzzleSprite.scale.setScalar(0.65 + Math.random() * 0.35);
    muzzleSprite.visible = true;
    muzzleLight.position.copy(muzzleWorldPos);
    muzzleLight.intensity = 9.0;
    muzzleFlashTimer = 0.065;

    // Muzzle sparks + barrel smoke
    for (let i = 0; i < 4; i++) {
      spawnSpark(muzzleWorldPos, aimDir, 9);
    }
    spawnSmoke(muzzleWorldPos, 0.24);

    // 2. Raycast from aimOrigin along aimDir to find impact point
    _raycaster.set(aimOrigin, aimDir);
    _raycaster.far = 180;
    const hits = _raycaster.intersectObjects(targets, false);

    let impactPoint: THREE.Vector3;
    if (hits.length > 0) {
      const hit = hits[0];
      impactPoint = hit.point.clone();
      if (hit.face) {
        _normalMat.getNormalMatrix(hit.object.matrixWorld);
        _hitNormal.copy(hit.face.normal).applyMatrix3(_normalMat).normalize();
      } else {
        _hitNormal.set(0, 1, 0);
      }

      // Spawn surface-aligned impact decal + impact sparks + dust puff
      spawnDecal(impactPoint, _hitNormal);
      for (let i = 0; i < 7; i++) {
        spawnSpark(impactPoint, _hitNormal, 7.5);
      }
      spawnSmoke(impactPoint, 0.36);
    } else {
      impactPoint = aimOrigin.clone().addScaledVector(aimDir, 120);
    }

    // 3. Launch high-velocity tracer from muzzleWorldPos -> impactPoint
    const tracer = tracers.find((t) => !t.active);
    if (tracer) {
      tracer.active = true;
      tracer.life = 0;
      const travelDir = impactPoint.clone().sub(muzzleWorldPos);
      const dist = Math.max(1, travelDir.length());
      travelDir.normalize();
      const speed = 165;
      tracer.maxLife = Math.min(0.45, dist / speed);
      tracer.velocity.copy(travelDir).multiplyScalar(speed);
      tracerMat.color.set(energyColor || '#38bdf8');

      tracer.mesh.position.copy(muzzleWorldPos).addScaledVector(travelDir, 0.9);
      _lookMat.lookAt(
        tracer.mesh.position,
        tracer.mesh.position.clone().add(travelDir),
        new THREE.Vector3(0, 1, 0)
      );
      tracer.mesh.quaternion.setFromRotationMatrix(_lookMat);
      tracer.mesh.visible = true;
    }
  };

  const update = (delta: number) => {
    if (muzzleFlashTimer > 0) {
      muzzleFlashTimer -= delta;
      if (muzzleFlashTimer <= 0) {
        muzzleSprite.visible = false;
        muzzleLight.intensity = 0;
      } else {
        const k = muzzleFlashTimer / 0.065;
        muzzleSprite.material.opacity = k;
        muzzleLight.intensity = 9.0 * k;
      }
    }

    for (const t of tracers) {
      if (!t.active) continue;
      t.life += delta;
      if (t.life >= t.maxLife) {
        t.active = false;
        t.mesh.visible = false;
      } else {
        t.mesh.position.addScaledVector(t.velocity, delta);
      }
    }

    for (const s of sparks) {
      if (!s.active) continue;
      s.life += delta;
      if (s.life >= s.maxLife) {
        s.active = false;
        s.mesh.visible = false;
      } else {
        s.velocity.y -= 14 * delta;
        s.mesh.position.addScaledVector(s.velocity, delta);
        const gy = groundHeightAt(s.mesh.position.x, s.mesh.position.z);
        if (s.mesh.position.y < gy + 0.03) {
          s.mesh.position.y = gy + 0.03;
          s.velocity.y *= -0.4;
        }
      }
    }

    for (const sm of smokes) {
      if (!sm.active) continue;
      sm.life += delta;
      if (sm.life >= sm.maxLife) {
        sm.active = false;
        sm.sprite.visible = false;
      } else {
        const p = sm.life / sm.maxLife;
        sm.sprite.position.addScaledVector(sm.velocity, delta);
        sm.sprite.scale.setScalar(0.24 + p * 0.72);
        (sm.sprite.material as THREE.SpriteMaterial).opacity = 0.45 * (1 - p);
      }
    }
  };

  return {
    group,
    fireWeapon,
    playReloadAudio,
    playJumpAudio,
    getDecalCount: () => totalDecalsSpawned,
    setAudioMuted: (muted: boolean) => {
      isMuted = muted;
    },
    update,
    dispose: () => {
      tracerGeo.dispose();
      tracerMat.dispose();
      sparkGeo.dispose();
      sparkMat.dispose();
      decalGeo.dispose();
      decalMat.dispose();
      muzzleMat.dispose();
      smokes.forEach((s) => s.sprite.material.dispose());
      if (audioCtx) {
        audioCtx.close().catch(() => {});
      }
    },
  };
}
