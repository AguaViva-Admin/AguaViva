import * as THREE from 'three';
import type { AvatarAnimState, AvatarParams } from '../types/aguaviva';
import type { WorldTextures } from './pbrTextures';
import {
  createAnisotropicMetalMaterial,
  createArchitecturalGlassMaterial,
  createSubsurfaceSkinMaterial,
  getWeaponFinishColors,
} from './materials';
import { createHumanHeadSystem } from './humanHeadBuilder';
import { ASSET_URLS, loadGLBWithFallback } from './assetLoader';

export interface AvatarRigSystem {
  root: THREE.Group;
  hipsBone: THREE.Bone;
  handRightBone: THREE.Bone;
  weaponGroup: THREE.Group;
  muzzleAnchor: THREE.Object3D;
  magazineMesh: THREE.Mesh;
  mixer: THREE.AnimationMixer;
  setAnimState: (next: AvatarAnimState, forceRestart?: boolean) => void;
  getAnimState: () => AvatarAnimState;
  updateParams: (params: AvatarParams) => void;
  update: (delta: number, elapsed?: number) => void;
  dispose: () => void;
}

function qTrack(boneName: string, times: number[], eulers: [number, number, number][]) {
  const values: number[] = [];
  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  for (const [rx, ry, rz] of eulers) {
    e.set(rx, ry, rz, 'XYZ');
    q.setFromEuler(e);
    values.push(q.x, q.y, q.z, q.w);
  }
  return new THREE.QuaternionKeyframeTrack(`${boneName}.quaternion`, times, values);
}

function posTrack(boneName: string, times: number[], positions: [number, number, number][]) {
  const values: number[] = [];
  for (const [x, y, z] of positions) {
    values.push(x, y, z);
  }
  return new THREE.VectorKeyframeTrack(`${boneName}.position`, times, values);
}

function buildAnimationClips(): Record<AvatarAnimState, THREE.AnimationClip> {
  const idle = new THREE.AnimationClip('Idle', 2.4, [
    posTrack('Hips', [0, 1.2, 2.4], [
      [0, 0.94, 0],
      [0, 0.955, 0],
      [0, 0.94, 0],
    ]),
    qTrack('Spine', [0, 1.2, 2.4], [
      [0.03, -0.06, 0],
      [-0.015, -0.04, 0],
      [0.03, -0.06, 0],
    ]),
    qTrack('Head', [0, 1.2, 2.4], [
      [0, 0.05, 0],
      [0.03, 0.01, 0],
      [0, 0.05, 0],
    ]),
    qTrack('UpperArmR', [0, 1.2, 2.4], [
      [-0.52, -0.18, -0.18],
      [-0.48, -0.18, -0.16],
      [-0.52, -0.18, -0.18],
    ]),
    qTrack('ForearmR', [0, 1.2, 2.4], [
      [-0.78, 0.15, 0.25],
      [-0.74, 0.15, 0.25],
      [-0.78, 0.15, 0.25],
    ]),
    qTrack('UpperArmL', [0, 1.2, 2.4], [
      [-0.58, 0.35, 0.22],
      [-0.55, 0.35, 0.2],
      [-0.58, 0.35, 0.22],
    ]),
    qTrack('ForearmL', [0, 1.2, 2.4], [
      [-0.85, -0.2, -0.25],
      [-0.82, -0.2, -0.25],
      [-0.85, -0.2, -0.25],
    ]),
    qTrack('ThighL', [0, 2.4], [[0.04, 0, 0.04], [0.04, 0, 0.04]]),
    qTrack('ShinL', [0, 2.4], [[0.04, 0, 0], [0.04, 0, 0]]),
    qTrack('ThighR', [0, 2.4], [[-0.04, 0, -0.04], [-0.04, 0, -0.04]]),
    qTrack('ShinR', [0, 2.4], [[0.06, 0, 0], [0.06, 0, 0]]),
  ]);

  const walk = new THREE.AnimationClip('Walk', 1.0, [
    posTrack('Hips', [0, 0.25, 0.5, 0.75, 1.0], [
      [0, 0.93, 0],
      [0, 0.97, 0],
      [0, 0.93, 0],
      [0, 0.97, 0],
      [0, 0.93, 0],
    ]),
    qTrack('Spine', [0, 0.5, 1.0], [
      [0.06, 0.06, 0],
      [0.06, -0.08, 0],
      [0.06, 0.06, 0],
    ]),
    qTrack('ThighL', [0, 0.25, 0.5, 0.75, 1.0], [
      [-0.45, 0, 0.03],
      [0.0, 0, 0.03],
      [0.42, 0, 0.03],
      [0.12, 0, 0.03],
      [-0.45, 0, 0.03],
    ]),
    qTrack('ShinL', [0, 0.25, 0.5, 0.75, 1.0], [
      [0.18, 0, 0],
      [0.1, 0, 0],
      [0.25, 0, 0],
      [0.65, 0, 0],
      [0.18, 0, 0],
    ]),
    qTrack('ThighR', [0, 0.25, 0.5, 0.75, 1.0], [
      [0.42, 0, -0.03],
      [0.12, 0, -0.03],
      [-0.45, 0, -0.03],
      [0.0, 0, -0.03],
      [0.42, 0, -0.03],
    ]),
    qTrack('ShinR', [0, 0.25, 0.5, 0.75, 1.0], [
      [0.25, 0, 0],
      [0.65, 0, 0],
      [0.18, 0, 0],
      [0.1, 0, 0],
      [0.25, 0, 0],
    ]),
    qTrack('UpperArmR', [0, 0.5, 1.0], [
      [-0.5, -0.15, -0.18],
      [-0.42, -0.18, -0.18],
      [-0.5, -0.15, -0.18],
    ]),
    qTrack('ForearmR', [0, 1.0], [[-0.82, 0.15, 0.22], [-0.82, 0.15, 0.22]]),
    qTrack('UpperArmL', [0, 0.5, 1.0], [
      [-0.54, 0.34, 0.22],
      [-0.62, 0.34, 0.22],
      [-0.54, 0.34, 0.22],
    ]),
    qTrack('ForearmL', [0, 1.0], [[-0.88, -0.2, -0.25], [-0.88, -0.2, -0.25]]),
  ]);

  const run = new THREE.AnimationClip('Run', 0.64, [
    posTrack('Hips', [0, 0.16, 0.32, 0.48, 0.64], [
      [0, 0.9, 0],
      [0, 1.01, 0],
      [0, 0.9, 0],
      [0, 1.01, 0],
      [0, 0.9, 0],
    ]),
    qTrack('Spine', [0, 0.32, 0.64], [
      [0.22, 0.12, 0],
      [0.22, -0.12, 0],
      [0.22, 0.12, 0],
    ]),
    qTrack('ThighL', [0, 0.16, 0.32, 0.48, 0.64], [
      [-0.85, 0, 0.04],
      [-0.1, 0, 0.04],
      [0.75, 0, 0.04],
      [0.25, 0, 0.04],
      [-0.85, 0, 0.04],
    ]),
    qTrack('ShinL', [0, 0.16, 0.32, 0.48, 0.64], [
      [0.25, 0, 0],
      [0.18, 0, 0],
      [0.65, 0, 0],
      [1.15, 0, 0],
      [0.25, 0, 0],
    ]),
    qTrack('ThighR', [0, 0.16, 0.32, 0.48, 0.64], [
      [0.75, 0, -0.04],
      [0.25, 0, -0.04],
      [-0.85, 0, -0.04],
      [-0.1, 0, -0.04],
      [0.75, 0, -0.04],
    ]),
    qTrack('ShinR', [0, 0.16, 0.32, 0.48, 0.64], [
      [0.65, 0, 0],
      [1.15, 0, 0],
      [0.25, 0, 0],
      [0.18, 0, 0],
      [0.65, 0, 0],
    ]),
    qTrack('UpperArmR', [0, 0.32, 0.64], [
      [-0.65, -0.25, -0.22],
      [-0.48, -0.22, -0.22],
      [-0.65, -0.25, -0.22],
    ]),
    qTrack('ForearmR', [0, 0.64], [[-1.05, 0.2, 0.3], [-1.05, 0.2, 0.3]]),
    qTrack('UpperArmL', [0, 0.32, 0.64], [
      [-0.48, 0.42, 0.24],
      [-0.68, 0.38, 0.24],
      [-0.48, 0.42, 0.24],
    ]),
    qTrack('ForearmL', [0, 0.64], [[-1.1, -0.25, -0.3], [-1.1, -0.25, -0.3]]),
  ]);

  const jump = new THREE.AnimationClip('Jump', 0.7, [
    posTrack('Hips', [0, 0.35, 0.7], [
      [0, 0.96, 0],
      [0, 1.04, 0],
      [0, 0.94, 0],
    ]),
    qTrack('Spine', [0, 0.35, 0.7], [
      [0.15, 0, 0],
      [0.06, 0, 0],
      [0.12, 0, 0],
    ]),
    qTrack('ThighL', [0, 0.35, 0.7], [
      [-0.78, 0, 0.08],
      [-0.55, 0, 0.08],
      [-0.2, 0, 0.05],
    ]),
    qTrack('ShinL', [0, 0.35, 0.7], [[1.1, 0, 0], [0.8, 0, 0], [0.25, 0, 0]]),
    qTrack('ThighR', [0, 0.35, 0.7], [
      [-0.35, 0, -0.08],
      [-0.45, 0, -0.08],
      [-0.15, 0, -0.05],
    ]),
    qTrack('ShinR', [0, 0.35, 0.7], [[0.55, 0, 0], [0.65, 0, 0], [0.2, 0, 0]]),
    qTrack('UpperArmR', [0, 0.35, 0.7], [
      [-0.85, -0.1, -0.25],
      [-0.65, -0.15, -0.2],
      [-0.5, -0.18, -0.18],
    ]),
    qTrack('UpperArmL', [0, 0.35, 0.7], [
      [-0.9, 0.25, 0.3],
      [-0.65, 0.3, 0.22],
      [-0.55, 0.35, 0.22],
    ]),
  ]);

  const shoot = new THREE.AnimationClip('Shoot', 0.24, [
    qTrack('Spine', [0, 0.06, 0.24], [
      [0.03, -0.06, 0],
      [-0.08, -0.08, 0],
      [0.03, -0.06, 0],
    ]),
    qTrack('UpperArmR', [0, 0.05, 0.24], [
      [-0.54, -0.18, -0.18],
      [-0.76, -0.16, -0.14],
      [-0.54, -0.18, -0.18],
    ]),
    qTrack('ForearmR', [0, 0.05, 0.24], [
      [-0.78, 0.15, 0.25],
      [-0.92, 0.15, 0.25],
      [-0.78, 0.15, 0.25],
    ]),
    qTrack('HandR', [0, 0.05, 0.24], [
      [0, 0, 0],
      [-0.18, 0, 0],
      [0, 0, 0],
    ]),
  ]);

  const reload = new THREE.AnimationClip('Reload', 1.35, [
    qTrack('Spine', [0, 0.4, 0.95, 1.35], [
      [0.03, -0.06, 0],
      [0.12, 0.12, 0],
      [0.08, -0.04, 0],
      [0.03, -0.06, 0],
    ]),
    qTrack('UpperArmR', [0, 0.4, 0.95, 1.35], [
      [-0.52, -0.18, -0.18],
      [-0.35, -0.35, -0.25],
      [-0.45, -0.24, -0.2],
      [-0.52, -0.18, -0.18],
    ]),
    qTrack('ForearmR', [0, 0.4, 0.95, 1.35], [
      [-0.78, 0.15, 0.25],
      [-1.05, 0.25, 0.35],
      [-0.92, 0.2, 0.28],
      [-0.78, 0.15, 0.25],
    ]),
    qTrack('UpperArmL', [0, 0.35, 0.72, 1.08, 1.35], [
      [-0.58, 0.35, 0.22],
      [-0.12, 0.1, 0.35],
      [-0.68, 0.38, 0.15],
      [-0.82, 0.22, 0.12],
      [-0.58, 0.35, 0.22],
    ]),
    qTrack('ForearmL', [0, 0.35, 0.72, 1.08, 1.35], [
      [-0.85, -0.2, -0.25],
      [-0.35, -0.1, -0.1],
      [-1.15, -0.25, -0.2],
      [-1.05, -0.15, -0.15],
      [-0.85, -0.2, -0.25],
    ]),
  ]);

  return { Idle: idle, Walk: walk, Run: run, Jump: jump, Shoot: shoot, Reload: reload };
}

/**
 * Generates a Crysis-style hexagonal carbon-nanofiber weave texture for organic suits.
 */
function createHexNanofiberTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(148, 163, 184, 0.32)';
  ctx.lineWidth = 1.5;
  const r = 10;
  const dx = r * 1.5;
  const dy = r * Math.sqrt(3);
  for (let row = -1; row < size / dy + 2; row++) {
    for (let col = -1; col < size / dx + 2; col++) {
      const cx = col * dx;
      const cy = row * dy + (col % 2 === 0 ? 0 : dy / 2);
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = (i * Math.PI) / 3;
        const px = cx + Math.cos(a) * r * 0.92;
        const py = cy + Math.sin(a) * r * 0.92;
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(4, 4);
  return tex;
}

/**
 * Creates a sculpted anatomical limb LatheGeometry (oriented downward from origin).
 */
function createSculptedLimbGeo(
  radiiProfile: [number, number][],
  radialSegments = 24,
  scaleX = 1.0,
  scaleZ = 1.0
): THREE.LatheGeometry {
  const pts = radiiProfile.map(([r, y]) => new THREE.Vector2(r, y));
  const geo = new THREE.LatheGeometry(pts, radialSegments);
  geo.scale(scaleX, 1, scaleZ);
  geo.computeVertexNormals();
  return geo;
}

export function createAvatarAndWeaponSystem(
  textures: WorldTextures,
  isSoftwareGl: boolean,
  initialParams: AvatarParams
): AvatarRigSystem {
  const root = new THREE.Group();
  root.name = 'AguaVivaAvatar';

  // -------------------------------------------------------------------------
  // 1. Hierarchical Skeletal Rig (THREE.Bone)
  // -------------------------------------------------------------------------
  const hipsBone = new THREE.Bone();
  hipsBone.name = 'Hips';
  hipsBone.position.set(0, 0.94, 0);

  const spineBone = new THREE.Bone();
  spineBone.name = 'Spine';
  spineBone.position.set(0, 0.14, 0);
  hipsBone.add(spineBone);

  const chestBone = new THREE.Bone();
  chestBone.name = 'Chest';
  chestBone.position.set(0, 0.25, 0);
  spineBone.add(chestBone);

  const neckBone = new THREE.Bone();
  neckBone.name = 'Neck';
  neckBone.position.set(0, 0.22, 0);
  chestBone.add(neckBone);

  const headBone = new THREE.Bone();
  headBone.name = 'Head';
  headBone.position.set(0, 0.11, 0);
  neckBone.add(headBone);

  const upperArmLBone = new THREE.Bone();
  upperArmLBone.name = 'UpperArmL';
  upperArmLBone.position.set(-0.225, 0.17, 0);
  chestBone.add(upperArmLBone);

  const forearmLBone = new THREE.Bone();
  forearmLBone.name = 'ForearmL';
  forearmLBone.position.set(0, -0.28, 0);
  upperArmLBone.add(forearmLBone);

  const handLBone = new THREE.Bone();
  handLBone.name = 'HandL';
  handLBone.position.set(0, -0.26, 0);
  forearmLBone.add(handLBone);

  const upperArmRBone = new THREE.Bone();
  upperArmRBone.name = 'UpperArmR';
  upperArmRBone.position.set(0.225, 0.17, 0);
  chestBone.add(upperArmRBone);

  const forearmRBone = new THREE.Bone();
  forearmRBone.name = 'ForearmR';
  forearmRBone.position.set(0, -0.28, 0);
  upperArmRBone.add(forearmRBone);

  const handRBone = new THREE.Bone();
  handRBone.name = 'HandR';
  handRBone.position.set(0, -0.26, 0);
  forearmRBone.add(handRBone);

  const thighLBone = new THREE.Bone();
  thighLBone.name = 'ThighL';
  thighLBone.position.set(-0.105, -0.05, 0);
  hipsBone.add(thighLBone);

  const shinLBone = new THREE.Bone();
  shinLBone.name = 'ShinL';
  shinLBone.position.set(0, -0.43, 0);
  thighLBone.add(shinLBone);

  const footLBone = new THREE.Bone();
  footLBone.name = 'FootL';
  footLBone.position.set(0, -0.43, 0);
  shinLBone.add(footLBone);

  const thighRBone = new THREE.Bone();
  thighRBone.name = 'ThighR';
  thighRBone.position.set(0.105, -0.05, 0);
  hipsBone.add(thighRBone);

  const shinRBone = new THREE.Bone();
  shinRBone.name = 'ShinR';
  shinRBone.position.set(0, -0.43, 0);
  thighRBone.add(shinRBone);

  const footRBone = new THREE.Bone();
  footRBone.name = 'FootR';
  footRBone.position.set(0, -0.43, 0);
  shinRBone.add(footRBone);

  root.add(hipsBone);

  // -------------------------------------------------------------------------
  // 2. Organic & Tactical PBR Materials
  // -------------------------------------------------------------------------
  const hexTex = createHexNanofiberTexture();
  const skinMat = createSubsurfaceSkinMaterial(initialParams.skinTone, initialParams.sssIntensity);
  const armorMat = createAnisotropicMetalMaterial(initialParams.armorColor, textures, 0.28, 0.78);
  const nanoSuitMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(initialParams.armorColor),
    map: hexTex,
    roughness: 0.42,
    metalness: 0.48,
    clearcoat: 0.35,
    clearcoatRoughness: 0.35,
  });
  const fabricMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#1e293b'),
    roughness: 0.85,
    metalness: 0.04,
    sheen: 0.6,
    sheenRoughness: 0.75,
    sheenColor: new THREE.Color('#475569'),
  });
  const hairMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(initialParams.hairColor),
    roughness: 0.38,
    metalness: 0.12,
    sheen: 0.85,
    sheenRoughness: 0.32,
    sheenColor: new THREE.Color('#f8fafc'),
  });
  const energyMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(initialParams.energyColor),
    emissive: new THREE.Color(initialParams.energyColor),
    emissiveIntensity: 2.2,
    roughness: 0.18,
  });

  const geometriesToDispose: THREE.BufferGeometry[] = [];
  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geometriesToDispose.push(g);
    return g;
  };

  // -------------------------------------------------------------------------
  // 3. Sculpted Organic Torso, Neck, Pelvis & Archetype Outfit Layers
  // -------------------------------------------------------------------------
  // Pelvis / Sculpted Hip Contour
  const pelvisGeo = trackGeo(
    createSculptedLimbGeo(
      [
        [0.08, -0.09],
        [0.148, -0.03],
        [0.155, 0.04],
        [0.132, 0.11],
      ],
      28,
      1.12,
      0.78
    )
  );
  const pelvisMesh = new THREE.Mesh(pelvisGeo, nanoSuitMat);
  pelvisMesh.castShadow = true;
  pelvisMesh.receiveShadow = true;
  hipsBone.add(pelvisMesh);

  // Sculpted Athletic Torso (Lathe with realistic chest/ribcage/waist curve)
  const torsoGeo = trackGeo(
    createSculptedLimbGeo(
      [
        [0.01, 0],
        [0.128, 0.02],
        [0.122, 0.12],
        [0.158, 0.25],
        [0.188, 0.36],
        [0.172, 0.43],
        [0.075, 0.47],
      ],
      32,
      1.14,
      0.72
    )
  );
  const torsoMesh = new THREE.Mesh(torsoGeo, nanoSuitMat);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  spineBone.add(torsoMesh);

  // Sculpted Pectoral / Tactical Rig Overlay (curved chest plate + shoulder straps)
  const rigGroup = new THREE.Group();
  const chestPlateShape = new THREE.Shape();
  chestPlateShape.moveTo(-0.145, -0.12);
  chestPlateShape.quadraticCurveTo(0, -0.15, 0.145, -0.12);
  chestPlateShape.lineTo(0.18, 0.09);
  chestPlateShape.quadraticCurveTo(0, 0.17, -0.18, 0.09);
  chestPlateShape.closePath();

  const chestPlateGeo = trackGeo(
    new THREE.ExtrudeGeometry(chestPlateShape, {
      depth: 0.17,
      bevelEnabled: true,
      bevelSize: 0.025,
      bevelThickness: 0.025,
      bevelSegments: 4,
    })
  );
  chestPlateGeo.center();
  const chestPlateMesh = new THREE.Mesh(chestPlateGeo, armorMat);
  chestPlateMesh.position.set(0, 0.05, 0.015);
  chestPlateMesh.scale.set(0.96, 0.94, 0.94);
  chestPlateMesh.castShadow = true;
  rigGroup.add(chestPlateMesh);

  chestBone.add(rigGroup);

  // Glowing Cyan Energy Chest Emblem (emissiveIntensity > 1.5 for subtle Bloom, visible on all suits)
  const chestEmblem = new THREE.Mesh(
    trackGeo(new THREE.TorusGeometry(0.038, 0.009, 12, 24)),
    energyMat
  );
  chestEmblem.position.set(0, 0.075, 0.145);
  chestBone.add(chestEmblem);

  // Mu / MLBB Flowing Shoulder Mantle / Winged Pauldron Assembly
  const mantleGroup = new THREE.Group();
  const capeCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.16, 0.19, -0.05),
    new THREE.Vector3(-0.08, 0.12, -0.16),
    new THREE.Vector3(0.06, -0.16, -0.21),
    new THREE.Vector3(0.14, -0.45, -0.26),
  ]);
  const capeGeo = trackGeo(new THREE.TubeGeometry(capeCurve, 18, 0.055, 10, false));
  capeGeo.scale(2.1, 1.0, 0.32);
  const capeMesh = new THREE.Mesh(capeGeo, fabricMat);
  capeMesh.castShadow = true;
  mantleGroup.add(capeMesh);

  // Mu Fantasy Energy Wing Blades
  const wingShape = new THREE.Shape();
  wingShape.moveTo(0, 0);
  wingShape.quadraticCurveTo(0.28, 0.24, 0.42, 0.42);
  wingShape.quadraticCurveTo(0.22, 0.12, 0.14, -0.08);
  wingShape.closePath();
  const wingGeo = trackGeo(
    new THREE.ExtrudeGeometry(wingShape, {
      depth: 0.014,
      bevelEnabled: true,
      bevelSize: 0.006,
      bevelThickness: 0.006,
      bevelSegments: 2,
    })
  );
  [-1, 1].forEach((side) => {
    const wing = new THREE.Mesh(wingGeo, energyMat);
    wing.position.set(side * 0.06, 0.1, -0.13);
    wing.rotation.y = side * -0.45;
    wing.scale.x = side;
    mantleGroup.add(wing);
  });
  chestBone.add(mantleGroup);

  // Neck (SSS Skin)
  const neckGeo = trackGeo(
    createSculptedLimbGeo(
      [
        [0.062, 0],
        [0.052, 0.06],
        [0.054, 0.12],
      ],
      22
    )
  );
  const neckMesh = new THREE.Mesh(neckGeo, skinMat);
  neckMesh.castShadow = true;
  neckBone.add(neckMesh);

  // -------------------------------------------------------------------------
  // 4. Sculpted Human Head, Dual-Mesh Eyes, Gaze, Expressions & Hair
  // -------------------------------------------------------------------------
  const humanHead = createHumanHeadSystem(
    initialParams,
    skinMat,
    hairMat,
    armorMat,
    energyMat,
    isSoftwareGl
  );
  headBone.add(humanHead.headGroup);

  // -------------------------------------------------------------------------
  // 5. Sculpted Anatomical Arms, Hands (5-digit silhouette), Legs & Boots
  // -------------------------------------------------------------------------
  const upperArmGeo = trackGeo(
    createSculptedLimbGeo(
      [
        [0.036, -0.275],
        [0.044, -0.2],
        [0.054, -0.13], // Bicep curve
        [0.058, -0.04], // Deltoid curve
        [0.046, 0.01],
      ],
      22,
      0.95,
      1.02
    )
  );

  const forearmGeo = trackGeo(
    createSculptedLimbGeo(
      [
        [0.028, -0.255], // Wrist
        [0.036, -0.16],
        [0.044, -0.06],  // Forearm flexor
        [0.038, 0.01],
      ],
      20,
      0.94,
      1.0
    )
  );

  const shoulderCapGeo = trackGeo(
    new THREE.SphereGeometry(0.088, 22, 16, 0, Math.PI * 2, 0, Math.PI * 0.56)
  );

  const pauldronMeshes: THREE.Mesh[] = [];
  const forearmMeshes: THREE.Mesh[] = [];

  const buildArm = (
    upperBone: THREE.Bone,
    forearmBone: THREE.Bone,
    handBone: THREE.Bone,
    side: number
  ) => {
    const pauldron = new THREE.Mesh(shoulderCapGeo, armorMat);
    pauldron.rotation.z = side * -0.42;
    pauldron.position.set(side * 0.015, 0.015, 0);
    pauldron.castShadow = true;
    upperBone.add(pauldron);
    pauldronMeshes.push(pauldron);

    const upperArm = new THREE.Mesh(upperArmGeo, nanoSuitMat);
    upperArm.castShadow = true;
    upperBone.add(upperArm);

    const forearm = new THREE.Mesh(forearmGeo, nanoSuitMat);
    forearm.castShadow = true;
    forearmBone.add(forearm);
    forearmMeshes.push(forearm);

    // Anatomical Palm + Fingers + Thumb (SSS Skin)
    const handGroup = new THREE.Group();
    const palm = new THREE.Mesh(
      trackGeo(new THREE.SphereGeometry(0.034, 16, 14)),
      skinMat
    );
    palm.scale.set(0.82, 1.12, 0.52);
    palm.position.set(0, -0.028, 0);
    palm.castShadow = true;
    handGroup.add(palm);

    for (let f = -1.5; f <= 1.5; f += 1) {
      const finger = new THREE.Mesh(
        trackGeo(new THREE.CapsuleGeometry(0.007, 0.032, 4, 8)),
        skinMat
      );
      finger.position.set(f * 0.012, -0.068, 0.004);
      finger.rotation.x = 0.25;
      handGroup.add(finger);
    }
    const thumb = new THREE.Mesh(
      trackGeo(new THREE.CapsuleGeometry(0.008, 0.025, 4, 8)),
      skinMat
    );
    thumb.position.set(side * -0.026, -0.042, 0.014);
    thumb.rotation.z = side * 0.5;
    handGroup.add(thumb);

    handBone.add(handGroup);
  };

  buildArm(upperArmLBone, forearmLBone, handLBone, -1);
  buildArm(upperArmRBone, forearmRBone, handRBone, 1);

  // Sculpted Anatomical Thigh, Calf, Knee Guard & Sleek Athletic Boot
  const thighGeo = trackGeo(
    createSculptedLimbGeo(
      [
        [0.048, -0.425], // Knee
        [0.062, -0.3],
        [0.078, -0.14],  // Quadriceps sweep
        [0.082, -0.02],
        [0.068, 0.02],
      ],
      24,
      0.95,
      1.04
    )
  );

  const shinGeo = trackGeo(
    createSculptedLimbGeo(
      [
        [0.036, -0.42], // Ankle
        [0.043, -0.32],
        [0.058, -0.16], // Gastrocnemius calf curve
        [0.054, -0.05],
        [0.048, 0.01],
      ],
      22,
      0.94,
      1.04
    )
  );

  const bootCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, -0.03, -0.035),
    new THREE.Vector3(0, -0.048, 0.04),
    new THREE.Vector3(0, -0.052, 0.12),
  ]);
  const bootGeo = trackGeo(new THREE.TubeGeometry(bootCurve, 12, 0.046, 12, false));
  bootGeo.scale(1.0, 0.72, 1.0);

  const buildLeg = (thighBone: THREE.Bone, shinBone: THREE.Bone, footBone: THREE.Bone) => {
    const thigh = new THREE.Mesh(thighGeo, fabricMat);
    thigh.castShadow = true;
    thigh.receiveShadow = true;
    thighBone.add(thigh);

    const kneePad = new THREE.Mesh(
      trackGeo(new THREE.SphereGeometry(0.052, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.5)),
      armorMat
    );
    kneePad.rotation.x = Math.PI / 2;
    kneePad.position.set(0, -0.015, 0.032);
    kneePad.castShadow = true;
    shinBone.add(kneePad);

    const shin = new THREE.Mesh(shinGeo, nanoSuitMat);
    shin.castShadow = true;
    shinBone.add(shin);

    const boot = new THREE.Mesh(bootGeo, armorMat);
    boot.castShadow = true;
    boot.receiveShadow = true;
    footBone.add(boot);
  };

  buildLeg(thighLBone, shinLBone, footLBone);
  buildLeg(thighRBone, shinRBone, footRBone);

  // -------------------------------------------------------------------------
  // 6. Composite 8-Part PBR Rifle Parented to Right Hand Bone (`handRBone`)
  // -------------------------------------------------------------------------
  const weaponGroup = new THREE.Group();
  weaponGroup.name = 'HydroPulseCarbine';
  weaponGroup.position.set(0.0, -0.03, 0.06);
  weaponGroup.rotation.set(Math.PI * 0.44, 0.06, -0.06);

  const wColors = getWeaponFinishColors(initialParams.weaponFinish);
  const wPrimaryMat = createAnisotropicMetalMaterial(wColors.primary, textures, 0.22, 0.94);
  const wDarkMat = createAnisotropicMetalMaterial(wColors.secondary, textures, 0.42, 0.85);
  const wAccentMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(wColors.accent),
    emissive: new THREE.Color(wColors.accent),
    emissiveIntensity: 2.2,
    roughness: 0.2,
  });
  const opticGlassMat = createArchitecturalGlassMaterial(isSoftwareGl, '#38bdf8');

  const recShape = new THREE.Shape();
  recShape.moveTo(-0.22, -0.045);
  recShape.lineTo(0.2, -0.045);
  recShape.lineTo(0.24, 0.035);
  recShape.lineTo(-0.18, 0.05);
  recShape.closePath();
  const receiverGeo = trackGeo(
    new THREE.ExtrudeGeometry(recShape, {
      depth: 0.052,
      bevelEnabled: true,
      bevelSize: 0.008,
      bevelThickness: 0.008,
      bevelSegments: 2,
    })
  );
  receiverGeo.center();
  const receiver = new THREE.Mesh(receiverGeo, wPrimaryMat);
  receiver.rotation.y = Math.PI / 2;
  receiver.position.set(0, 0.02, 0.14);
  receiver.castShadow = true;
  weaponGroup.add(receiver);

  const barrel = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(0.016, 0.02, 0.54, 16)),
    wDarkMat
  );
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.032, 0.56);
  barrel.castShadow = true;
  weaponGroup.add(barrel);

  const shroud = new THREE.Mesh(
    trackGeo(new THREE.BoxGeometry(0.054, 0.068, 0.34)),
    wPrimaryMat
  );
  shroud.position.set(0, 0.028, 0.45);
  shroud.castShadow = true;
  weaponGroup.add(shroud);

  const muzzleBrake = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(0.024, 0.02, 0.075, 12)),
    wDarkMat
  );
  muzzleBrake.rotation.x = Math.PI / 2;
  muzzleBrake.position.set(0, 0.032, 0.84);
  weaponGroup.add(muzzleBrake);

  const opticHousing = new THREE.Mesh(
    trackGeo(new THREE.BoxGeometry(0.042, 0.048, 0.11)),
    wDarkMat
  );
  opticHousing.position.set(0, 0.09, 0.14);
  weaponGroup.add(opticHousing);

  const opticLens = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(0.016, 0.016, 0.01, 16)),
    opticGlassMat
  );
  opticLens.rotation.x = Math.PI / 2;
  opticLens.position.set(0, 0.095, 0.19);
  weaponGroup.add(opticLens);

  const grip = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.038, 0.13, 0.048)), wDarkMat);
  grip.rotation.x = 0.25;
  grip.position.set(0, -0.06, 0.04);
  weaponGroup.add(grip);

  const stock = new THREE.Mesh(trackGeo(new THREE.BoxGeometry(0.042, 0.095, 0.24)), wDarkMat);
  stock.position.set(0, 0.01, -0.14);
  weaponGroup.add(stock);

  const magazineMesh = new THREE.Mesh(
    trackGeo(new THREE.BoxGeometry(0.036, 0.15, 0.056)),
    wDarkMat
  );
  magazineMesh.rotation.x = -0.16;
  magazineMesh.position.set(0, -0.07, 0.22);
  weaponGroup.add(magazineMesh);

  const energyStrip = new THREE.Mesh(
    trackGeo(new THREE.BoxGeometry(0.058, 0.014, 0.24)),
    wAccentMat
  );
  energyStrip.position.set(0, 0.038, 0.45);
  weaponGroup.add(energyStrip);

  const muzzleAnchor = new THREE.Object3D();
  muzzleAnchor.position.set(0, 0.032, 0.89);
  weaponGroup.add(muzzleAnchor);

  handRBone.add(weaponGroup);

  // -------------------------------------------------------------------------
  // 7. AnimationMixer & Clip State Machine
  // -------------------------------------------------------------------------
  const mixer = new THREE.AnimationMixer(hipsBone);
  const clips = buildAnimationClips();
  const actions: Record<AvatarAnimState, THREE.AnimationAction> = {
    Idle: mixer.clipAction(clips.Idle),
    Walk: mixer.clipAction(clips.Walk),
    Run: mixer.clipAction(clips.Run),
    Jump: mixer.clipAction(clips.Jump),
    Shoot: mixer.clipAction(clips.Shoot),
    Reload: mixer.clipAction(clips.Reload),
  };

  actions.Shoot.setLoop(THREE.LoopOnce, 1);
  actions.Shoot.clampWhenFinished = false;
  actions.Reload.setLoop(THREE.LoopOnce, 1);
  actions.Reload.clampWhenFinished = false;
  actions.Jump.setLoop(THREE.LoopOnce, 1);
  actions.Jump.clampWhenFinished = true;

  let currentState: AvatarAnimState = 'Idle';
  actions.Idle.play();

  // Optional external GLB weapon swap if ASSET_URLS.weaponGlb is configured (safe fallback to PBR carbine)
  let disposed = false;
  if (ASSET_URLS.weaponGlb) {
    loadGLBWithFallback(ASSET_URLS.weaponGlb).then((gltf) => {
      if (!gltf || disposed) return;
      weaponGroup.children.forEach((child) => {
        if (child !== muzzleAnchor) child.visible = false;
      });
      const extWeapon = gltf.scene;
      extWeapon.scale.setScalar(0.85);
      weaponGroup.add(extWeapon);
    });
  }

  // Optional external GLB character (`Soldier.glb`) with AnimationMixer + procedural fallback
  let glbGroup: THREE.Group | null = null;
  let glbMixer: THREE.AnimationMixer | null = null;
  let glbActions: Partial<Record<'Idle' | 'Walk' | 'Run', THREE.AnimationAction>> = {};
  let glbLoadAttempted = false;
  let useGlbMode = Boolean(initialParams.useGlbAvatar);

  const syncGlbAnim = (state: AvatarAnimState) => {
    if (!glbMixer) return;
    const key: 'Idle' | 'Walk' | 'Run' =
      state === 'Run' ? 'Run' : state === 'Walk' ? 'Walk' : 'Idle';
    const nextAct = glbActions[key] || glbActions.Idle;
    if (!nextAct) return;
    Object.values(glbActions).forEach((act) => {
      if (act && act !== nextAct) act.fadeOut(0.18);
    });
    nextAct.reset().fadeIn(0.18).play();
  };

  const ensureGlbAvatarLoaded = () => {
    if (glbLoadAttempted || !ASSET_URLS.avatarGlb) return;
    glbLoadAttempted = true;
    loadGLBWithFallback(ASSET_URLS.avatarGlb).then((gltf) => {
      if (!gltf || disposed) return;
      glbGroup = gltf.scene;
      glbGroup.rotation.y = Math.PI; // Soldier.glb faces -Z by default; orient toward +Z
      // Add glowing chest emblem on GLB avatar as well for consistent Bloom highlight
      const glbEmblem = new THREE.Mesh(
        trackGeo(new THREE.TorusGeometry(0.055, 0.011, 12, 24)),
        energyMat
      );
      glbEmblem.position.set(0, 1.32, -0.16);
      glbGroup.add(glbEmblem);

      glbGroup.visible = useGlbMode;
      hipsBone.visible = !useGlbMode;
      root.add(glbGroup);

      if (gltf.animations.length > 0) {
        glbMixer = new THREE.AnimationMixer(glbGroup);
        const findClip = (re: RegExp) => gltf.animations.find((c) => re.test(c.name));
        const idleClip = findClip(/idle/i) || gltf.animations[0];
        const walkClip = findClip(/walk/i) || idleClip;
        const runClip = findClip(/run/i) || walkClip;
        glbActions = {
          Idle: glbMixer.clipAction(idleClip),
          Walk: glbMixer.clipAction(walkClip),
          Run: glbMixer.clipAction(runClip),
        };
        syncGlbAnim(currentState);
      }
    });
  };

  const setAnimState = (next: AvatarAnimState, forceRestart = false) => {
    if (next === currentState && !forceRestart) return;
    const prevAction = actions[currentState];
    const nextAction = actions[next];
    nextAction.reset();
    nextAction.setEffectiveTimeScale(1);
    nextAction.setEffectiveWeight(1);
    nextAction.play();
    if (prevAction && prevAction !== nextAction) {
      prevAction.crossFadeTo(nextAction, next === 'Shoot' ? 0.05 : 0.18, true);
    }
    currentState = next;
    syncGlbAnim(next);
  };

  const updateParams = (params: AvatarParams) => {
    useGlbMode = Boolean(params.useGlbAvatar);
    if (useGlbMode) {
      ensureGlbAvatarLoaded();
    }
    if (glbGroup) {
      glbGroup.visible = useGlbMode;
      hipsBone.visible = !useGlbMode;
    } else {
      hipsBone.visible = true;
    }

    skinMat.color.set(params.skinTone);
    if (skinMat.userData.sssIntensity) {
      skinMat.userData.sssIntensity.value = params.sssIntensity;
    }
    hairMat.color.set(params.hairColor);
    armorMat.color.set(params.armorColor);
    nanoSuitMat.color.set(params.armorColor);
    energyMat.color.set(params.energyColor);
    energyMat.emissive.set(params.energyColor);

    const wCol = getWeaponFinishColors(params.weaponFinish);
    wPrimaryMat.color.set(wCol.primary);
    wDarkMat.color.set(wCol.secondary);
    wAccentMat.color.set(wCol.accent);
    wAccentMat.emissive.set(wCol.accent);

    // Archetype outfit switching (Crysis / Mu / Free Fire / MLBB)
    const isMu = params.armorStyle === 'mu_valkyrie';
    const isMlbb = params.armorStyle === 'mlbb_hero';
    const isFreeFire = params.armorStyle === 'freefire_tactical';
    const isCrysis = params.armorStyle === 'crysis_nanosuit';

    mantleGroup.visible = isMu || isMlbb;
    wingGeo && mantleGroup.children.forEach((c, idx) => {
      if (idx > 0) c.visible = isMu; // Fantasy wings only on Mu Valkyrie
    });
    rigGroup.visible = !isCrysis;
    pauldronMeshes.forEach((p) => {
      p.visible = isMu || isMlbb;
      p.scale.setScalar(isMu ? 1.25 : 1.0);
    });
    // Free Fire tactical rolled sleeves reveal SSS skin forearms!
    forearmMeshes.forEach((f) => {
      f.material = isFreeFire ? skinMat : nanoSuitMat;
    });

    humanHead.updateParams(params, skinMat, energyMat);
    root.scale.setScalar(THREE.MathUtils.clamp(params.heightScale, 0.9, 1.15));
  };

  updateParams(initialParams);

  return {
    root,
    hipsBone,
    handRightBone: handRBone,
    weaponGroup,
    muzzleAnchor,
    magazineMesh,
    mixer,
    setAnimState,
    getAnimState: () => currentState,
    updateParams,
    update: (delta: number, elapsed = 0) => {
      mixer.update(delta);
      glbMixer?.update(delta);
      humanHead.update(delta, elapsed);
    },
    dispose: () => {
      disposed = true;
      mixer.stopAllAction();
      glbMixer?.stopAllAction();
      humanHead.dispose();
      geometriesToDispose.forEach((g) => g.dispose());
      hexTex.dispose();
      skinMat.dispose();
      armorMat.dispose();
      nanoSuitMat.dispose();
      fabricMat.dispose();
      hairMat.dispose();
      energyMat.dispose();
      wPrimaryMat.dispose();
      wDarkMat.dispose();
      wAccentMat.dispose();
      opticGlassMat.dispose();
    },
  };
}
