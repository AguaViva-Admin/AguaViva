import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type {
  AvatarParams,
  EyeStyleType,
  FaceShapeType,
  FacialExpressionType,
  GazeDirectionType,
  HairStyleType,
  MouthStyleType,
} from '../types/aguaviva';
import { createArchitecturalGlassMaterial } from './materials';

export interface HumanHeadSystem {
  headGroup: THREE.Group;
  updateParams: (params: AvatarParams, skinMat: THREE.MeshPhysicalMaterial, energyMat: THREE.MeshStandardMaterial) => void;
  update: (delta: number, elapsed: number) => void;
  dispose: () => void;
}

function gauss2(x: number, y: number, cx: number, cy: number, sx: number, sy: number): number {
  const dx = (x - cx) / sx;
  const dy = (y - cy) / sy;
  return Math.exp(-(dx * dx + dy * dy));
}

function createIrisTexture(eyeColorHex: string): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  // Sclera base with subtle warm corner shading
  const scleraGrad = ctx.createRadialGradient(
    size / 2,
    size / 2,
    size * 0.14,
    size / 2,
    size / 2,
    size * 0.5
  );
  scleraGrad.addColorStop(0, '#fcfcfc');
  scleraGrad.addColorStop(0.7, '#f1f5f9');
  scleraGrad.addColorStop(1, '#cbd5e1');
  ctx.fillStyle = scleraGrad;
  ctx.fillRect(0, 0, size, size);

  const cx = size / 2;
  const cy = size / 2;
  const irisR = size * 0.19;

  // Limbal dark ring
  ctx.beginPath();
  ctx.arc(cx, cy, irisR + 3, 0, Math.PI * 2);
  ctx.fillStyle = '#0f172a';
  ctx.fill();

  // Base iris gradient
  const baseCol = new THREE.Color(eyeColorHex);
  const brightCol = baseCol.clone().offsetHSL(0, 0.08, 0.18).getStyle();
  const darkCol = baseCol.clone().offsetHSL(0, 0, -0.2).getStyle();

  const irisGrad = ctx.createRadialGradient(cx, cy, irisR * 0.25, cx, cy, irisR);
  irisGrad.addColorStop(0, brightCol);
  irisGrad.addColorStop(0.65, baseCol.getStyle());
  irisGrad.addColorStop(1, darkCol);
  ctx.beginPath();
  ctx.arc(cx, cy, irisR, 0, Math.PI * 2);
  ctx.fillStyle = irisGrad;
  ctx.fill();

  // Radial iris stroma fibers
  ctx.save();
  ctx.translate(cx, cy);
  for (let i = 0; i < 64; i++) {
    const a = (i / 64) * Math.PI * 2;
    ctx.rotate((Math.PI * 2) / 64);
    ctx.strokeStyle = i % 2 === 0 ? 'rgba(255,255,255,0.22)' : 'rgba(15,23,42,0.25)';
    ctx.lineWidth = 1.1;
    ctx.beginPath();
    ctx.moveTo(irisR * 0.34, 0);
    ctx.lineTo(irisR * 0.94, (i % 3 - 1) * 1.5);
    ctx.stroke();
    void a;
  }
  ctx.restore();

  // Crisp pupil
  ctx.beginPath();
  ctx.arc(cx, cy, irisR * 0.38, 0, Math.PI * 2);
  ctx.fillStyle = '#020617';
  ctx.fill();

  // Catchlight glint
  ctx.beginPath();
  ctx.arc(cx - irisR * 0.28, cy - irisR * 0.28, irisR * 0.14, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,255,255,0.92)';
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Sculpts a high-poly anatomical human head BufferGeometry with orbital eye sockets,
 * cheekbones, brow arch, nasal bridge/nostrils, philtrum, lips, and jawline.
 */
function buildSculptedHeadGeometry(
  faceShape: FaceShapeType,
  mouthStyle: MouthStyleType
): THREE.BufferGeometry {
  const geo = new THREE.SphereGeometry(0.115, 60, 48);
  const pos = geo.attributes.position;
  const v = new THREE.Vector3();

  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    // Normalized coordinates on unit sphere
    const len = v.length() || 1;
    const nx = v.x / len;
    const ny = v.y / len;
    const nz = v.z / len;

    // Base human skull elongation
    let x = v.x * 0.88;
    let y = v.y * 1.16;
    let z = v.z * 0.96;

    // Back of skull (occiput) fullness & neck base taper
    if (nz < -0.1) {
      z -= Math.abs(nz) * 0.014;
    }
    if (ny < -0.45) {
      const jawT = (-ny - 0.45) / 0.55;
      // Taper lower jaw & chin cleanly
      let jawWidth = 0.82;
      let chinLen = 0.012;
      if (faceShape === 'elven_mu') {
        jawWidth = 0.72;
        chinLen = 0.018;
      } else if (faceShape === 'tactical_square') {
        jawWidth = 0.96;
        chinLen = 0.014;
      } else if (faceShape === 'youthful_mlbb') {
        jawWidth = 0.78;
        chinLen = 0.008;
      }
      x *= THREE.MathUtils.lerp(1.0, jawWidth * 0.62, jawT);
      if (nz > 0.15) {
        z += jawT * chinLen;
        y -= jawT * 0.014;
      }
    }

    // Facial anatomy sculpting on anterior hemisphere (nz > 0.1)
    if (nz > 0.05) {
      const frontMask = THREE.MathUtils.smoothstep(nz, 0.05, 0.55);

      // 1. Orbital Eye Sockets (recessed inward so dual-mesh eyeballs sit naturally)
      const leftSocket = gauss2(nx, ny, -0.32, 0.11, 0.17, 0.12);
      const rightSocket = gauss2(nx, ny, 0.32, 0.11, 0.17, 0.12);
      z -= (leftSocket + rightSocket) * 0.019 * frontMask;

      // 2. Supraorbital Brow Ridge
      const leftBrow = gauss2(nx, ny, -0.28, 0.25, 0.22, 0.07);
      const rightBrow = gauss2(nx, ny, 0.28, 0.25, 0.22, 0.07);
      z += (leftBrow + rightBrow) * 0.011 * frontMask;

      // 3. Cheekbones (Zygomatic Arch)
      const cheekScale = faceShape === 'elven_mu' ? 1.25 : faceShape === 'tactical_square' ? 1.1 : 1.0;
      const leftCheek = gauss2(nx, ny, -0.44, -0.1, 0.2, 0.15);
      const rightCheek = gauss2(nx, ny, 0.44, -0.1, 0.2, 0.15);
      z += (leftCheek + rightCheek) * 0.012 * cheekScale * frontMask;
      x += Math.sign(nx) * (leftCheek + rightCheek) * 0.008 * cheekScale;

      // 4. Sculpted Nose Bridge, Tip & Nostrils
      const noseBridge = gauss2(nx, ny, 0, 0.02, 0.085, 0.22);
      const noseTip = gauss2(nx, ny, 0, -0.15, 0.095, 0.085);
      const nostrilL = gauss2(nx, ny, -0.11, -0.19, 0.06, 0.05);
      const nostrilR = gauss2(nx, ny, 0.11, -0.19, 0.06, 0.05);
      z += (noseBridge * 0.018 + noseTip * 0.024 + (nostrilL + nostrilR) * 0.007) * frontMask;

      // 5. Mouth / Lips Cushion & Philtrum
      const lipFullness =
        mouthStyle === 'full_defined' ? 1.45 : mouthStyle === 'sharp_tactical' ? 0.72 : 1.0;
      const upperLip = gauss2(nx, ny, 0, -0.35, 0.21, 0.052);
      const lowerLip = gauss2(nx, ny, 0, -0.44, 0.18, 0.058);
      const mouthCrease = gauss2(nx, ny, 0, -0.395, 0.19, 0.02);
      z += (upperLip * 0.011 + lowerLip * 0.012 - mouthCrease * 0.007) * lipFullness * frontMask;

      // 6. Chin projection
      const chin = gauss2(nx, ny, 0, -0.68, 0.2, 0.14);
      z += chin * 0.015 * frontMask;
    }

    pos.setXYZ(i, x, y, z);
  }

  geo.computeVertexNormals();
  return geo;
}

function buildHairStyleGroup(
  style: HairStyleType,
  hairMat: THREE.MeshPhysicalMaterial,
  armorMat: THREE.MeshPhysicalMaterial,
  energyMat: THREE.MeshStandardMaterial
): { group: THREE.Group; disposables: THREE.BufferGeometry[] } {
  const group = new THREE.Group();
  const disposables: THREE.BufferGeometry[] = [];
  const strandGeos: THREE.BufferGeometry[] = [];

  if (style === 'crysis_helmet') {
    // Sleek Crysis Nanosuit Tactical Helmet + Hexagonal Bio-Visor
    const shellGeo = new THREE.SphereGeometry(0.123, 36, 28);
    shellGeo.scale(0.95, 1.15, 1.04);
    disposables.push(shellGeo);
    const shell = new THREE.Mesh(shellGeo, armorMat);
    shell.position.set(0, 0.006, -0.004);
    shell.castShadow = true;
    group.add(shell);

    // Sculpted jaw-guard cheek plates
    const cheekGeo = new THREE.BoxGeometry(0.185, 0.075, 0.13);
    disposables.push(cheekGeo);
    const cheekGuard = new THREE.Mesh(cheekGeo, armorMat);
    cheekGuard.position.set(0, -0.065, 0.025);
    group.add(cheekGuard);

    // Glowing Crysis Tactical Visor Band
    const visorGeo = new THREE.CylinderGeometry(0.118, 0.116, 0.036, 28, 1, true, -0.95, 1.9);
    disposables.push(visorGeo);
    const visor = new THREE.Mesh(visorGeo, energyMat);
    visor.position.set(0, 0.016, 0.018);
    group.add(visor);

    // Neural Crest Fin
    const crestGeo = new THREE.BoxGeometry(0.022, 0.04, 0.21);
    disposables.push(crestGeo);
    const crest = new THREE.Mesh(crestGeo, armorMat);
    crest.position.set(0, 0.132, -0.02);
    group.add(crest);

    return { group, disposables };
  }

  // Scalp base cap so no bare spots appear between strands
  const capGeo = new THREE.SphereGeometry(0.106, 28, 22, 0, Math.PI * 2, 0, Math.PI * 0.56);
  capGeo.scale(0.9, 1.14, 0.99);
  const capMesh = new THREE.Mesh(capGeo, hairMat);
  capMesh.position.set(0, 0.012, -0.004);
  capMesh.rotation.x = -0.18;
  capMesh.castShadow = true;
  disposables.push(capGeo);
  group.add(capMesh);

  const addLock = (pts: [number, number, number][], radius: number, segments = 10) => {
    const curve = new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(p[0], p[1], p[2])));
    const tube = new THREE.TubeGeometry(curve, segments, radius, 7, false);
    strandGeos.push(tube);
  };

  if (style === 'tactical_short') {
    // Free Fire style sculpted short undercut + angled side bangs
    for (let i = -4; i <= 4; i++) {
      const x = i * 0.021;
      addLock(
        [
          [x * 0.7, 0.115, -0.02],
          [x * 0.95, 0.125, 0.06],
          [x * 1.05 + 0.015, 0.065, 0.105],
        ],
        0.018,
        8
      );
    }
    for (let i = -3; i <= 3; i++) {
      const x = i * 0.026;
      addLock(
        [
          [x * 0.8, 0.1, -0.05],
          [x, 0.03, -0.11],
          [x * 0.85, -0.06, -0.105],
        ],
        0.021,
        8
      );
    }
  } else if (style === 'heroic_long_mu') {
    // Mu Online style sweeping heroic mane framing cheekbones & back
    for (let i = -5; i <= 5; i++) {
      const angle = (i / 5) * 1.35;
      const rx = Math.sin(angle) * 0.095;
      const rz = -Math.cos(angle) * 0.095;
      addLock(
        [
          [rx * 0.4, 0.12, rz * 0.4],
          [rx * 1.15, 0.04, rz * 1.12],
          [rx * 1.32, -0.12, rz * 1.25 - 0.03],
          [rx * 1.45, -0.28, rz * 1.15 - 0.05],
        ],
        0.022,
        12
      );
    }
    // Swept side bangs
    [-1, 1].forEach((s) => {
      addLock(
        [
          [s * 0.02, 0.12, 0.04],
          [s * 0.085, 0.06, 0.095],
          [s * 0.108, -0.06, 0.075],
        ],
        0.018,
        10
      );
    });
  } else if (style === 'styled_spiky_mlbb') {
    // Mobile Legends Bang Bang dynamic hero spikes & asymmetric bangs
    const spikeAngles = [-1.1, -0.7, -0.3, 0.1, 0.5, 0.95, 1.3];
    spikeAngles.forEach((a, idx) => {
      const dirX = Math.sin(a);
      const lift = idx % 2 === 0 ? 0.175 : 0.155;
      addLock(
        [
          [dirX * 0.04, 0.1, 0.01],
          [dirX * 0.095, lift, 0.04],
          [dirX * 0.135, lift - 0.045, 0.095],
        ],
        0.019,
        8
      );
    });
    // Back layered spikes
    for (let i = -3; i <= 3; i++) {
      const x = i * 0.028;
      addLock(
        [
          [x * 0.6, 0.1, -0.05],
          [x * 1.1, 0.03, -0.125],
          [x * 1.25, -0.09, -0.14],
        ],
        0.021,
        8
      );
    }
  } else {
    // urban_waves
    for (let i = -4; i <= 4; i++) {
      const angle = (i / 4) * 1.1;
      const rx = Math.sin(angle) * 0.095;
      const rz = -Math.cos(angle) * 0.095;
      addLock(
        [
          [rx * 0.5, 0.115, rz * 0.4],
          [rx * 1.15, 0.03, rz * 1.1],
          [rx * 1.02, -0.08, rz * 1.08],
          [rx * 1.18, -0.15, rz * 0.98],
        ],
        0.022,
        10
      );
    }
    // Wavy front sweep
    for (let i = -2; i <= 2; i++) {
      addLock(
        [
          [i * 0.024, 0.12, 0.03],
          [i * 0.032 + 0.02, 0.08, 0.098],
          [i * 0.035 + 0.03, 0.04, 0.092],
        ],
        0.017,
        8
      );
    }
  }

  if (strandGeos.length > 0) {
    const merged = mergeGeometries(strandGeos, false);
    strandGeos.forEach((g) => g.dispose());
    if (merged) {
      disposables.push(merged);
      const strandsMesh = new THREE.Mesh(merged, hairMat);
      strandsMesh.castShadow = true;
      strandsMesh.receiveShadow = true;
      group.add(strandsMesh);
    }
  }

  return { group, disposables };
}

export function createHumanHeadSystem(
  initialParams: AvatarParams,
  skinMat: THREE.MeshPhysicalMaterial,
  hairMat: THREE.MeshPhysicalMaterial,
  armorMat: THREE.MeshPhysicalMaterial,
  energyMat: THREE.MeshStandardMaterial,
  isSoftwareGl: boolean
): HumanHeadSystem {
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.125, 0.005);

  let currentFaceShape: FaceShapeType = initialParams.faceShape;
  let currentMouthStyle: MouthStyleType = initialParams.mouthStyle;
  let currentHairStyle: HairStyleType = initialParams.hairStyle;
  let currentEyeColor: string = initialParams.eyeColor;

  let headGeo = buildSculptedHeadGeometry(currentFaceShape, currentMouthStyle);
  const headMesh = new THREE.Mesh(headGeo, skinMat);
  headMesh.castShadow = true;
  headMesh.receiveShadow = true;
  headGroup.add(headMesh);

  // Sculpted Ears
  const earGeo = new THREE.SphereGeometry(0.022, 14, 12);
  earGeo.scale(0.45, 1.15, 0.7);
  [-1, 1].forEach((side) => {
    const ear = new THREE.Mesh(earGeo, skinMat);
    ear.position.set(side * 0.097, 0.002, -0.008);
    ear.rotation.z = side * -0.15;
    ear.rotation.y = side * 0.2;
    ear.castShadow = true;
    headGroup.add(ear);
  });

  // Dual-Mesh Realistic Eyes (Inner Iris/Sclera Sphere + Outer Cornea Dome IOR 1.336)
  let irisTex = createIrisTexture(currentEyeColor);
  const eyeballMat = new THREE.MeshStandardMaterial({
    map: irisTex,
    roughness: 0.25,
    metalness: 0.0,
  });
  const corneaMat = createArchitecturalGlassMaterial(isSoftwareGl, '#ffffff');
  corneaMat.ior = 1.336;
  corneaMat.opacity = isSoftwareGl ? 0.25 : 0.16;

  const eyeBallGeo = new THREE.SphereGeometry(0.017, 24, 18);
  const corneaGeo = new THREE.SphereGeometry(0.0182, 20, 16);
  const eyelidGeo = new THREE.SphereGeometry(0.0195, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.52);

  const eyePivotL = new THREE.Group();
  eyePivotL.position.set(-0.034, 0.018, 0.088);
  const eyePivotR = new THREE.Group();
  eyePivotR.position.set(0.034, 0.018, 0.088);

  const buildEyeAssembly = (pivot: THREE.Group) => {
    const ball = new THREE.Mesh(eyeBallGeo, eyeballMat);
    // Sphere UV has front at -PI/2 on Y so iris centers on +Z
    ball.rotation.y = -Math.PI / 2;
    pivot.add(ball);

    const cornea = new THREE.Mesh(corneaGeo, corneaMat);
    pivot.add(cornea);
  };
  buildEyeAssembly(eyePivotL);
  buildEyeAssembly(eyePivotR);
  headGroup.add(eyePivotL, eyePivotR);

  // Upper Eyelids (for blinking, squinting, winking & eyeShape slant)
  const eyelidL = new THREE.Mesh(eyelidGeo, skinMat);
  eyelidL.position.set(-0.034, 0.02, 0.088);
  const eyelidR = new THREE.Mesh(eyelidGeo, skinMat);
  eyelidR.position.set(0.034, 0.02, 0.088);
  headGroup.add(eyelidL, eyelidR);

  // Sculpted Eyebrows (expression & eyeStyle reactive)
  const browGeo = new THREE.CapsuleGeometry(0.0042, 0.028, 4, 10);
  browGeo.rotateZ(Math.PI / 2);
  const browL = new THREE.Mesh(browGeo, hairMat);
  browL.position.set(-0.035, 0.044, 0.098);
  const browR = new THREE.Mesh(browGeo, hairMat);
  browR.position.set(0.035, 0.044, 0.098);
  headGroup.add(browL, browR);

  // Sculpted Lips Mesh (expression & mouthStyle reactive)
  const lipColorMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color('#b8685c'),
    roughness: 0.36,
    clearcoat: 0.25,
    clearcoatRoughness: 0.35,
  });
  const lipCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.022, 0.001, -0.005),
    new THREE.Vector3(-0.008, 0.003, 0.003),
    new THREE.Vector3(0, 0.0015, 0.0045),
    new THREE.Vector3(0.008, 0.003, 0.003),
    new THREE.Vector3(0.022, 0.001, -0.005),
  ]);
  const upperLipGeo = new THREE.TubeGeometry(lipCurve, 16, 0.0044, 8, false);
  const lowerLipCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.019, -0.002, -0.004),
    new THREE.Vector3(0, -0.0055, 0.004),
    new THREE.Vector3(0.019, -0.002, -0.004),
  ]);
  const lowerLipGeo = new THREE.TubeGeometry(lowerLipCurve, 14, 0.0048, 8, false);

  const mouthGroup = new THREE.Group();
  mouthGroup.position.set(0, -0.046, 0.097);
  const upperLipMesh = new THREE.Mesh(upperLipGeo, lipColorMat);
  const lowerLipMesh = new THREE.Mesh(lowerLipGeo, lipColorMat);
  mouthGroup.add(upperLipMesh, lowerLipMesh);
  headGroup.add(mouthGroup);

  // Hair System
  let hairContainer = buildHairStyleGroup(currentHairStyle, hairMat, armorMat, energyMat);
  headGroup.add(hairContainer.group);

  // Expression & Gaze targets
  let targetGazeX = 0;
  let targetGazeY = 0;
  let exprState: FacialExpressionType = initialParams.expression;
  let eyeStyleState: EyeStyleType = initialParams.eyeStyle;
  let blinkTimer = 2.4;
  let blinkAmount = 0;

  const applyExpressionTargets = (
    expression: FacialExpressionType,
    eyeStyle: EyeStyleType,
    mouthStyle: MouthStyleType,
    gaze: GazeDirectionType,
    skinHex: string
  ) => {
    exprState = expression;
    eyeStyleState = eyeStyle;

    // Tint lip color naturally relative to skin tone
    const lipBase = new THREE.Color(skinHex).lerp(new THREE.Color('#9f4345'), 0.42);
    lipColorMat.color.copy(lipBase);

    // Gaze targets (yaw/pitch on eyeballs)
    targetGazeX = gaze === 'left' ? 0.28 : gaze === 'right' ? -0.28 : 0;
    targetGazeY = gaze === 'up' ? -0.22 : gaze === 'down' ? 0.22 : 0;

    // Eye slant by eyeStyle
    const slant =
      eyeStyle === 'mystic_mu'
        ? 0.2
        : eyeStyle === 'intense_crysis'
        ? 0.12
        : eyeStyle === 'expressive_mlbb'
        ? -0.06
        : 0.06;
    const eyeScaleY = eyeStyle === 'expressive_mlbb' ? 1.14 : eyeStyle === 'intense_crysis' ? 0.88 : 1.0;
    eyePivotL.scale.set(1, eyeScaleY, 1);
    eyePivotR.scale.set(1, eyeScaleY, 1);

    // Eyebrow & Mouth expression geometry poses
    if (expression === 'smile') {
      browL.position.y = 0.047;
      browR.position.y = 0.047;
      browL.rotation.z = 0.08 + slant * 0.4;
      browR.rotation.z = -0.08 - slant * 0.4;
      lowerLipMesh.position.y = -0.002;
      mouthGroup.scale.set(1.12, 1.0, 1.0);
      upperLipMesh.rotation.x = -0.18;
    } else if (expression === 'determined') {
      browL.position.y = 0.04;
      browR.position.y = 0.04;
      browL.rotation.z = -0.24;
      browR.rotation.z = 0.24;
      lowerLipMesh.position.y = 0;
      mouthGroup.scale.set(0.95, 0.9, 1.0);
      upperLipMesh.rotation.x = 0.1;
    } else if (expression === 'surprised') {
      browL.position.y = 0.053;
      browR.position.y = 0.053;
      browL.rotation.z = 0.14;
      browR.rotation.z = -0.14;
      lowerLipMesh.position.y = -0.008;
      mouthGroup.scale.set(0.85, 1.45, 1.0);
      upperLipMesh.rotation.x = -0.1;
    } else if (expression === 'wink') {
      browL.position.y = 0.041;
      browR.position.y = 0.048;
      browL.rotation.z = -0.08;
      browR.rotation.z = -0.12;
      lowerLipMesh.position.y = -0.002;
      mouthGroup.scale.set(1.08, 1.0, 1.0);
    } else {
      browL.position.y = 0.044;
      browR.position.y = 0.044;
      browL.rotation.z = slant * 0.5;
      browR.rotation.z = -slant * 0.5;
      lowerLipMesh.position.y = mouthStyle === 'natural_smile' ? -0.002 : 0;
      mouthGroup.scale.set(
        mouthStyle === 'full_defined' ? 1.08 : mouthStyle === 'sharp_tactical' ? 0.92 : 1.0,
        mouthStyle === 'full_defined' ? 1.2 : 1.0,
        1.0
      );
      upperLipMesh.rotation.x = 0;
    }
  };

  applyExpressionTargets(
    initialParams.expression,
    initialParams.eyeStyle,
    initialParams.mouthStyle,
    initialParams.gazeDirection,
    initialParams.skinTone
  );

  const updateParams = (
    params: AvatarParams,
    _skinMat: THREE.MeshPhysicalMaterial,
    _energyMat: THREE.MeshStandardMaterial
  ) => {
    if (params.faceShape !== currentFaceShape || params.mouthStyle !== currentMouthStyle) {
      currentFaceShape = params.faceShape;
      currentMouthStyle = params.mouthStyle;
      const nextGeo = buildSculptedHeadGeometry(currentFaceShape, currentMouthStyle);
      headMesh.geometry = nextGeo;
      headGeo.dispose();
      headGeo = nextGeo;
    }

    if (params.eyeColor !== currentEyeColor) {
      currentEyeColor = params.eyeColor;
      const nextTex = createIrisTexture(currentEyeColor);
      eyeballMat.map = nextTex;
      eyeballMat.needsUpdate = true;
      irisTex.dispose();
      irisTex = nextTex;
    }

    if (params.hairStyle !== currentHairStyle) {
      currentHairStyle = params.hairStyle;
      headGroup.remove(hairContainer.group);
      hairContainer.disposables.forEach((g) => g.dispose());
      hairContainer = buildHairStyleGroup(currentHairStyle, hairMat, armorMat, energyMat);
      headGroup.add(hairContainer.group);
    }

    applyExpressionTargets(
      params.expression,
      params.eyeStyle,
      params.mouthStyle,
      params.gazeDirection,
      params.skinTone
    );
  };

  const update = (delta: number, _elapsed: number) => {
    // Smooth eye gaze interpolation
    eyePivotL.rotation.y = THREE.MathUtils.damp(eyePivotL.rotation.y, targetGazeX, 12, delta);
    eyePivotR.rotation.y = THREE.MathUtils.damp(eyePivotR.rotation.y, targetGazeX, 12, delta);
    eyePivotL.rotation.x = THREE.MathUtils.damp(eyePivotL.rotation.x, targetGazeY, 12, delta);
    eyePivotR.rotation.x = THREE.MathUtils.damp(eyePivotR.rotation.x, targetGazeY, 12, delta);

    // Automatic natural blinking
    blinkTimer -= delta;
    if (blinkTimer <= 0) {
      blinkTimer = 2.6 + Math.random() * 2.2;
      blinkAmount = 1.0;
    }
    blinkAmount = Math.max(0, blinkAmount - delta * 6.5);
    const blinkCurve = Math.sin(blinkAmount * Math.PI);

    // Eyelid rotation (-0.95 open -> +0.25 closed)
    const baseOpen =
      exprState === 'determined'
        ? -0.62
        : exprState === 'surprised'
        ? -1.12
        : eyeStyleState === 'intense_crysis'
        ? -0.68
        : -0.9;

    const leftTarget = exprState === 'wink' ? 0.26 : THREE.MathUtils.lerp(baseOpen, 0.26, blinkCurve);
    const rightTarget = THREE.MathUtils.lerp(baseOpen, 0.26, blinkCurve);

    eyelidL.rotation.x = THREE.MathUtils.damp(eyelidL.rotation.x, leftTarget, 20, delta);
    eyelidR.rotation.x = THREE.MathUtils.damp(eyelidR.rotation.x, rightTarget, 20, delta);
  };

  return {
    headGroup,
    updateParams,
    update,
    dispose: () => {
      headGeo.dispose();
      earGeo.dispose();
      eyeBallGeo.dispose();
      corneaGeo.dispose();
      eyelidGeo.dispose();
      browGeo.dispose();
      upperLipGeo.dispose();
      lowerLipGeo.dispose();
      irisTex.dispose();
      eyeballMat.dispose();
      corneaMat.dispose();
      lipColorMat.dispose();
      hairContainer.disposables.forEach((g) => g.dispose());
    },
  };
}
