import * as THREE from 'three';
import { GLTFLoader, type GLTF } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { RGBELoader } from 'three/addons/loaders/RGBELoader.js';

/**
 * URLs configurables para activos GLB, HDRI y texturas externas (con fallback automático seguro).
 * Si alguna URL está vacía ('') o falla por red/CORS, el motor activa automáticamente
 * la geometría PBR procedural de alta calidad para evitar pantallas en blanco.
 */
export const ASSET_URLS = {
  avatarGlb: 'https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/models/gltf/Soldier.glb',
  weaponGlb: '',
  treeGlb: '',
  rockGlb: '',
  foxGlb: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/Fox/glTF-Binary/Fox.glb',
  sunsetHdr: 'https://dl.polyhaven.org/file/ph-assets/HDRIs/hdr/1k/sunset_jhbcentral_1k.hdr',
  waterNormals: 'https://threejs.org/examples/textures/waternormals.jpg',
};

let sharedDracoLoader: DRACOLoader | null = null;
let sharedGltfLoader: GLTFLoader | null = null;

function getGltfLoader(): GLTFLoader {
  if (!sharedGltfLoader) {
    sharedDracoLoader = new DRACOLoader();
    sharedDracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.7/');
    sharedGltfLoader = new GLTFLoader();
    sharedGltfLoader.setDRACOLoader(sharedDracoLoader);
    sharedGltfLoader.setCrossOrigin('anonymous');
  }
  return sharedGltfLoader;
}

/**
 * Carga un modelo GLB/GLTF usando GLTFLoader + DRACOLoader.
 * Devuelve null silenciosamente si la URL está vacía o falla la carga,
 * permitiendo activar el fallback procedural sin errores fatales.
 */
export async function loadGLBWithFallback(url: string): Promise<GLTF | null> {
  if (!url || !url.trim()) return null;
  try {
    const loader = getGltfLoader();
    const gltf = await loader.loadAsync(url);
    gltf.scene.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        const mesh = obj as THREE.Mesh;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
      }
    });
    return gltf;
  } catch {
    return null;
  }
}

/**
 * Carga un entorno HDR equirectangular con RGBELoader. Devuelve null si falla.
 */
export async function loadHDRWithFallback(url: string): Promise<THREE.DataTexture | null> {
  if (!url || !url.trim()) return null;
  try {
    const loader = new RGBELoader();
    loader.setCrossOrigin('anonymous');
    const hdr = await loader.loadAsync(url);
    hdr.mapping = THREE.EquirectangularReflectionMapping;
    return hdr;
  } catch {
    return null;
  }
}

/**
 * Carga una textura externa (ej. waternormals.jpg) con RepeatWrapping y fallback seguro.
 */
export async function loadRepeatTextureWithFallback(url: string): Promise<THREE.Texture | null> {
  if (!url || !url.trim()) return null;
  try {
    const loader = new THREE.TextureLoader();
    loader.setCrossOrigin('anonymous');
    const tex = await loader.loadAsync(url);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    return tex;
  } catch {
    return null;
  }
}

export function disposeAssetLoaders() {
  if (sharedDracoLoader) {
    sharedDracoLoader.dispose();
    sharedDracoLoader = null;
  }
  sharedGltfLoader = null;
}
