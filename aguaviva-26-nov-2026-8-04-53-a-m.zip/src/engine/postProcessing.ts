import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import type { PostProcessingConfig } from '../types/aguaviva';

export interface PostProcessingPipeline {
  composer: EffectComposer;
  applyConfig: (cfg: PostProcessingConfig) => void;
  setSize: (w: number, h: number) => void;
  render: () => void;
  dispose: () => void;
}

export function createPostProcessingPipeline(
  renderer: THREE.WebGLRenderer,
  scene: THREE.Scene,
  camera: THREE.PerspectiveCamera,
  width: number,
  height: number,
  initialConfig: PostProcessingConfig
): PostProcessingPipeline {
  const composer = new EffectComposer(renderer);

  const renderPass = new RenderPass(scene, camera);
  composer.addPass(renderPass);

  // Subtle UnrealBloomPass: high threshold so cyan chest emblem & sunset water speculars glow cleanly
  const bloomPass = new UnrealBloomPass(
    new THREE.Vector2(Math.max(1, Math.floor(width / 2)), Math.max(1, Math.floor(height / 2))),
    initialConfig.bloomStrength,
    0.42,
    0.86
  );
  composer.addPass(bloomPass);

  // ACESFilmic Tone Mapping + SRGB Output Pass
  const outputPass = new OutputPass();
  composer.addPass(outputPass);

  const applyConfig = (cfg: PostProcessingConfig) => {
    bloomPass.enabled = cfg.bloom;
    bloomPass.strength = cfg.bloomStrength;
  };
  applyConfig(initialConfig);

  return {
    composer,
    applyConfig,
    setSize: (w: number, h: number) => {
      composer.setSize(w, h);
      bloomPass.resolution.set(Math.max(1, Math.floor(w / 2)), Math.max(1, Math.floor(h / 2)));
    },
    render: () => {
      composer.render();
    },
    dispose: () => {
      bloomPass.dispose();
      composer.dispose();
    },
  };
}
