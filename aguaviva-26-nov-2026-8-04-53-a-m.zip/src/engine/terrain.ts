import * as THREE from 'three';
import { Water } from 'three/addons/objects/Water.js';
import type { WorldTextures } from './pbrTextures';
import {
  ASSET_URLS,
  loadGLBWithFallback,
  loadRepeatTextureWithFallback,
} from './assetLoader';

export const WATER_LEVEL = -1.65;

/**
 * Deterministic multi-octave heightfield for the AguaViva valley.
 * Keeps a smoothly graded residential & plaza plateau around (0, 0) to (18, 0),
 * carves a sinuous river canyon around x = -28, and rises into coastal hills & mountain ridges.
 */
export function groundHeightAt(x: number, z: number): number {
  const riverCenterX = -28 + Math.sin(z * 0.042) * 8.5 + Math.cos(z * 0.018) * 4.0;
  const distToRiver = Math.abs(x - riverCenterX);

  const riverCarve = -3.8 * Math.exp(-(distToRiver * distToRiver) / 145);

  const ridge1 = Math.sin(x * 0.032 + 0.4) * Math.cos(z * 0.029 - 0.3) * 3.8;
  const ridge2 = Math.sin(x * 0.075 - z * 0.06) * 1.45;
  const ridge3 = Math.cos(x * 0.14 + z * 0.12) * 0.45;

  const radial = Math.hypot(x, z);
  const rimFactor = THREE.MathUtils.smoothstep(radial, 68, 138);
  const mountains =
    rimFactor * (14.0 + Math.abs(Math.sin(x * 0.045) * Math.cos(z * 0.045)) * 18.0);

  let raw = ridge1 + ridge2 + ridge3 + riverCarve + mountains;

  const plazaDist = Math.hypot((x - 10) * 0.8, z * 0.85);
  const plazaBlend = 1.0 - THREE.MathUtils.smoothstep(plazaDist, 14, 30);
  raw = THREE.MathUtils.lerp(raw, 0.35, plazaBlend);

  return raw;
}

export interface TerrainSystem {
  group: THREE.Group;
  terrainMesh: THREE.Mesh;
  waterMesh: Water;
  setGrassVisible: (visible: boolean) => void;
  updateSun: (sunDirection: THREE.Vector3, sunColor: THREE.Color) => void;
  update: (delta: number, elapsed: number, turbulence: number) => void;
  dispose: () => void;
}

function buildCurvedGrassBladeGeometry(): THREE.BufferGeometry {
  // Tapered curved grass cluster (2 crossed blades per instance for rich coverage)
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const addBlade = (angleY: number, tiltZ: number, height: number, width: number) => {
    const baseVert = positions.length / 3;
    const segs = 3;
    const cosA = Math.cos(angleY);
    const sinA = Math.sin(angleY);

    for (let i = 0; i <= segs; i++) {
      const t = i / segs;
      const w = width * (1 - t * 0.88);
      const y = t * height;
      const bend = t * t * tiltZ;

      const lx = -w * cosA - bend * sinA;
      const lz = -w * sinA + bend * cosA;
      const rx = w * cosA - bend * sinA;
      const rz = w * sinA + bend * cosA;

      positions.push(lx, y, lz, rx, y, rz);
      normals.push(-sinA * 0.3, 0.85, cosA * 0.3, -sinA * 0.3, 0.85, cosA * 0.3);
      uvs.push(0, t, 1, t);
    }

    for (let i = 0; i < segs; i++) {
      const r0 = baseVert + i * 2;
      const r1 = r0 + 2;
      indices.push(r0, r0 + 1, r1, r0 + 1, r1 + 1, r1);
    }
  };

  addBlade(0.0, 0.14, 0.48, 0.048);
  addBlade(Math.PI * 0.36, 0.12, 0.4, 0.042);

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

export function createTerrainSystem(
  textures: WorldTextures,
  isSoftwareGl: boolean
): TerrainSystem {
  const group = new THREE.Group();
  let disposed = false;

  const size = 280;
  const segments = 144;

  const geo = new THREE.PlaneGeometry(size, size, segments, segments);
  geo.rotateX(-Math.PI / 2);

  const posAttr = geo.attributes.position;
  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i);
    const z = posAttr.getZ(i);
    posAttr.setY(i, groundHeightAt(x, z));
  }
  geo.computeVertexNormals();

  // Splatmapping PBR Terrain Material (blends grass, dirt, rock, wet riverbank with normal & roughness maps)
  const terrainMat = new THREE.MeshStandardMaterial({
    map: textures.grass.map,
    normalMap: textures.grass.normalMap,
    normalScale: new THREE.Vector2(1.25, 1.25),
    roughnessMap: textures.grass.roughnessMap,
    roughness: 0.92,
    metalness: 0.02,
  });

  terrainMat.onBeforeCompile = (shader) => {
    shader.uniforms.uDirtMap = { value: textures.dirt.map };
    shader.uniforms.uRockMap = { value: textures.rock.map };
    shader.uniforms.uWetMap = { value: textures.wetBank.map };
    shader.uniforms.uWaterLevel = { value: WATER_LEVEL };

    shader.vertexShader =
      `
      varying vec3 vWorldPos;
      varying vec3 vWorldNorm;
      ` +
      shader.vertexShader.replace(
        '#include <worldpos_vertex>',
        `
        #include <worldpos_vertex>
        vec4 wp = modelMatrix * vec4(transformed, 1.0);
        vWorldPos = wp.xyz;
        vWorldNorm = normalize(mat3(modelMatrix) * objectNormal);
        `
      );

    shader.fragmentShader =
      `
      uniform sampler2D uDirtMap;
      uniform sampler2D uRockMap;
      uniform sampler2D uWetMap;
      uniform float uWaterLevel;
      varying vec3 vWorldPos;
      varying vec3 vWorldNorm;
      ` +
      shader.fragmentShader.replace(
        '#include <map_fragment>',
        `
        #include <map_fragment>
        vec2 splatUv = vWorldPos.xz * 0.055;
        vec3 grassCol = diffuseColor.rgb;
        vec3 dirtCol = texture2D(uDirtMap, splatUv * 1.15).rgb;
        vec3 rockCol = texture2D(uRockMap, splatUv * 0.85).rgb;
        vec3 wetCol = texture2D(uWetMap, splatUv * 1.4).rgb;

        float slope = 1.0 - clamp(vWorldNorm.y, 0.0, 1.0);
        float rockWeight = smoothstep(0.16, 0.42, slope) + smoothstep(8.5, 16.0, vWorldPos.y) * 0.7;
        rockWeight = clamp(rockWeight, 0.0, 1.0);

        float dirtBand = smoothstep(-0.8, 1.6, vWorldPos.y) * (1.0 - smoothstep(1.8, 4.5, vWorldPos.y)) * 0.52;
        float wetWeight = 1.0 - smoothstep(uWaterLevel - 0.5, uWaterLevel + 0.9, vWorldPos.y);

        vec3 blended = mix(grassCol, dirtCol, clamp(dirtBand, 0.0, 1.0));
        blended = mix(blended, rockCol, rockWeight);
        blended = mix(blended, wetCol, clamp(wetWeight, 0.0, 1.0));
        diffuseColor.rgb = blended;
        `
      ).replace(
        '#include <roughnessmap_fragment>',
        `
        #include <roughnessmap_fragment>
        float wetRough = 1.0 - smoothstep(uWaterLevel - 0.5, uWaterLevel + 0.85, vWorldPos.y);
        roughnessFactor = mix(roughnessFactor, 0.22, wetRough * 0.88);
        `
      );
  };
  terrainMat.customProgramCacheKey = () => 'aguaviva-splat-terrain-v2';

  const terrainMesh = new THREE.Mesh(geo, terrainMat);
  terrainMesh.receiveShadow = true;
  terrainMesh.name = 'AguaVivaTerrain';
  group.add(terrainMesh);

  // -------------------------------------------------------------------------
  // Realistic Water Shader (`Water` from three/addons/objects/Water.js)
  // -------------------------------------------------------------------------
  const waterGeo = new THREE.PlaneGeometry(260, 260);
  const waterRes = isSoftwareGl ? 256 : 512;
  const waterMesh = new Water(waterGeo, {
    textureWidth: waterRes,
    textureHeight: waterRes,
    waterNormals: textures.waterNormals,
    sunDirection: new THREE.Vector3(-0.6, 0.14, -0.75).normalize(),
    sunColor: 0xffae66,
    waterColor: 0x0b3948,
    distortionScale: 2.6,
    fog: true,
  });
  waterMesh.rotation.x = -Math.PI / 2;
  waterMesh.position.y = WATER_LEVEL;
  waterMesh.name = 'AguaVivaWater';
  group.add(waterMesh);

  let loadedWaterNormals: THREE.Texture | null = null;
  if (!isSoftwareGl && ASSET_URLS.waterNormals) {
    loadRepeatTextureWithFallback(ASSET_URLS.waterNormals).then((tex) => {
      if (!tex) return;
      if (disposed) {
        tex.dispose();
        return;
      }
      loadedWaterNormals = tex;
      if (waterMesh.material.uniforms['normalSampler']) {
        waterMesh.material.uniforms['normalSampler'].value = tex;
      }
    });
  }

  // -------------------------------------------------------------------------
  // Instanced Grass Blades (2,200 tapered blades with wind sway & Golden tint)
  // -------------------------------------------------------------------------
  const grassCount = 2200;
  const grassGeo = buildCurvedGrassBladeGeometry();
  const grassUniforms = { uTime: { value: 0 } };
  const grassMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#ffffff'),
    roughness: 0.78,
    metalness: 0.0,
    side: THREE.DoubleSide,
  });
  grassMat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = grassUniforms.uTime;
    shader.vertexShader =
      `
      uniform float uTime;
      ` +
      shader.vertexShader.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        float swayAmt = clamp(uv.y, 0.0, 1.0);
        float phase = float(gl_InstanceID) * 0.37;
        transformed.x += sin(uTime * 2.1 + phase) * 0.09 * swayAmt * swayAmt;
        transformed.z += cos(uTime * 1.7 + phase * 1.3) * 0.06 * swayAmt * swayAmt;
        `
      );
  };
  grassMat.customProgramCacheKey = () => 'aguaviva-grass-sway-v1';

  const grassInst = new THREE.InstancedMesh(grassGeo, grassMat, grassCount);
  grassInst.receiveShadow = true;

  const dummy = new THREE.Object3D();
  const tint = new THREE.Color();

  let gPlaced = 0;
  for (let i = 0; i < 6500 && gPlaced < grassCount; i++) {
    const angle = (i * 2.39996) % (Math.PI * 2);
    const radius = 8.5 + ((i * 11.7) % 52);
    const x = Math.cos(angle) * radius - 4;
    const z = Math.sin(angle) * radius;

    // Avoid residence pad, avenue asphalt, and submerged riverbed
    if (Math.abs(x) < 9.5 && Math.abs(z) < 8.5) continue;
    if (Math.abs(x - 18) < 5.2) continue;
    const y = groundHeightAt(x, z);
    if (y < WATER_LEVEL + 0.55 || y > 7.8) continue;

    // Skip steep rocky slopes
    const slopeProbe =
      Math.abs(groundHeightAt(x + 0.8, z) - y) + Math.abs(groundHeightAt(x, z + 0.8) - y);
    if (slopeProbe > 0.55) continue;

    const s = 0.72 + ((i * 19) % 55) * 0.01;
    dummy.position.set(x, y - 0.02, z);
    dummy.rotation.set(0, (i * 1.73) % (Math.PI * 2), 0);
    dummy.scale.set(s, s * (0.85 + (i % 5) * 0.1), s);
    dummy.updateMatrix();
    grassInst.setMatrixAt(gPlaced, dummy.matrix);

    tint.setHSL(0.26 + ((i % 7) - 3) * 0.012, 0.44, 0.25 + (i % 5) * 0.025);
    grassInst.setColorAt(gPlaced, tint);
    gPlaced++;
  }
  grassInst.count = gPlaced;
  grassInst.instanceMatrix.needsUpdate = true;
  if (grassInst.instanceColor) grassInst.instanceColor.needsUpdate = true;
  grassInst.computeBoundingSphere();
  group.add(grassInst);

  // -------------------------------------------------------------------------
  // Instanced Pines with Procedural Bark PBR & Textured Multi-Tier Canopy
  // (plus optional GLB tree/rock override via ASSET_URLS with safe fallback)
  // -------------------------------------------------------------------------
  const treeCount = 135;
  const trunkGeo = new THREE.CylinderGeometry(0.14, 0.28, 2.5, 9);
  trunkGeo.translate(0, 1.25, 0);
  const trunkMat = new THREE.MeshStandardMaterial({
    map: textures.bark.map,
    normalMap: textures.bark.normalMap,
    normalScale: new THREE.Vector2(1.4, 1.4),
    roughnessMap: textures.bark.roughnessMap,
    roughness: 0.94,
    metalness: 0.02,
  });

  // 2-tier organic pine foliage with grass normal/roughness texture so leaves aren't flat
  const canopyGeo = new THREE.ConeGeometry(1.72, 4.9, 10, 3);
  canopyGeo.translate(0, 4.3, 0);
  const canopyMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#2f5e3e'),
    normalMap: textures.grass.normalMap,
    normalScale: new THREE.Vector2(0.85, 0.85),
    roughnessMap: textures.grass.roughnessMap,
    roughness: 0.86,
    metalness: 0.0,
  });

  const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
  const canopyInst = new THREE.InstancedMesh(canopyGeo, canopyMat, treeCount);
  trunkInst.castShadow = true;
  trunkInst.receiveShadow = true;
  canopyInst.castShadow = true;
  canopyInst.receiveShadow = true;

  const treeTransforms: { x: number; y: number; z: number; rotY: number; scale: number }[] = [];
  let placed = 0;
  let attempts = 0;
  while (placed < treeCount && attempts < 1400) {
    attempts++;
    const angle = (attempts * 2.39996) % (Math.PI * 2);
    const radius = 28 + ((attempts * 17.3) % 76);
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;

    if (Math.abs(x - 10) < 18 && Math.abs(z) < 22) continue;
    if (Math.abs(x - 18) < 6.5) continue;
    const y = groundHeightAt(x, z);
    if (y < WATER_LEVEL + 0.7 || y > 13.5) continue;

    const s = 0.85 + ((attempts * 13) % 30) * 0.01;
    dummy.position.set(x, y - 0.05, z);
    dummy.rotation.set(0, angle, 0);
    dummy.scale.set(s, s * (0.92 + (placed % 5) * 0.05), s);
    dummy.updateMatrix();

    trunkInst.setMatrixAt(placed, dummy.matrix);
    canopyInst.setMatrixAt(placed, dummy.matrix);
    treeTransforms.push({ x, y: y - 0.05, z, rotY: angle, scale: s });

    tint.setHSL(0.32 + ((placed % 7) - 3) * 0.014, 0.38, 0.24 + (placed % 4) * 0.03);
    canopyInst.setColorAt(placed, tint);
    placed++;
  }
  trunkInst.count = placed;
  canopyInst.count = placed;
  trunkInst.instanceMatrix.needsUpdate = true;
  canopyInst.instanceMatrix.needsUpdate = true;
  if (canopyInst.instanceColor) canopyInst.instanceColor.needsUpdate = true;
  trunkInst.computeBoundingSphere();
  canopyInst.computeBoundingSphere();
  group.add(trunkInst, canopyInst);

  // Instanced Basalt Boulders along riverbanks & ridges (procedural PBR fallback)
  const rockCount = 72;
  const rockGeo = new THREE.DodecahedronGeometry(1.1, 1);
  const rockMat = new THREE.MeshStandardMaterial({
    map: textures.rock.map,
    normalMap: textures.rock.normalMap,
    normalScale: new THREE.Vector2(1.3, 1.3),
    roughnessMap: textures.rock.roughnessMap,
    roughness: 0.88,
    metalness: 0.06,
  });
  const rockInst = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
  rockInst.castShadow = true;
  rockInst.receiveShadow = true;

  const rockTransforms: {
    x: number;
    y: number;
    z: number;
    rx: number;
    ry: number;
    rz: number;
    sx: number;
    sy: number;
    sz: number;
  }[] = [];

  let rPlaced = 0;
  for (let i = 0; i < 400 && rPlaced < rockCount; i++) {
    const x = -48 + ((i * 37.7) % 108);
    const z = -60 + ((i * 53.1) % 120);
    if (Math.abs(x - 10) < 16 && Math.abs(z) < 20) continue;
    const y = groundHeightAt(x, z);
    if (y < WATER_LEVEL - 0.3) continue;

    const sx = 0.65 + (i % 6) * 0.22;
    const sy = 0.45 + (i % 4) * 0.16;
    const sz = 0.6 + (i % 5) * 0.2;
    const rx = (i % 3) * 0.4;
    const ry = i * 0.9;
    const rz = (i % 2) * 0.3;
    dummy.position.set(x, y + sy * 0.3, z);
    dummy.rotation.set(rx, ry, rz);
    dummy.scale.set(sx, sy, sz);
    dummy.updateMatrix();
    rockInst.setMatrixAt(rPlaced, dummy.matrix);
    rockTransforms.push({ x, y: y + sy * 0.3, z, rx, ry, rz, sx, sy, sz });

    const shade = 0.65 + (i % 5) * 0.08;
    tint.setRGB(shade, shade * 1.02, shade * 1.05);
    rockInst.setColorAt(rPlaced, tint);
    rPlaced++;
  }
  rockInst.count = rPlaced;
  rockInst.instanceMatrix.needsUpdate = true;
  if (rockInst.instanceColor) rockInst.instanceColor.needsUpdate = true;
  rockInst.computeBoundingSphere();
  group.add(rockInst);

  // Optional external GLB Tree & Rock replacement if user configures ASSET_URLS.treeGlb / rockGlb
  const externalEnvGroup = new THREE.Group();
  group.add(externalEnvGroup);

  if (ASSET_URLS.treeGlb) {
    loadGLBWithFallback(ASSET_URLS.treeGlb).then((gltf) => {
      if (!gltf || disposed) return;
      trunkInst.visible = false;
      canopyInst.visible = false;
      for (let i = 0; i < Math.min(45, treeTransforms.length); i++) {
        const t = treeTransforms[i];
        const clone = gltf.scene.clone(true);
        clone.position.set(t.x, t.y, t.z);
        clone.rotation.y = t.rotY;
        clone.scale.setScalar(t.scale);
        externalEnvGroup.add(clone);
      }
    });
  }

  if (ASSET_URLS.rockGlb) {
    loadGLBWithFallback(ASSET_URLS.rockGlb).then((gltf) => {
      if (!gltf || disposed) return;
      rockInst.visible = false;
      for (let i = 0; i < Math.min(35, rockTransforms.length); i++) {
        const r = rockTransforms[i];
        const clone = gltf.scene.clone(true);
        clone.position.set(r.x, r.y, r.z);
        clone.rotation.set(r.rx, r.ry, r.rz);
        clone.scale.set(r.sx, r.sy, r.sz);
        externalEnvGroup.add(clone);
      }
    });
  }

  // Animated GLB Wildlife (`Fox.glb`) strolling gently near the golden-hour riverbank
  let foxRoot: THREE.Group | null = null;
  let foxMixer: THREE.AnimationMixer | null = null;
  if (!isSoftwareGl && ASSET_URLS.foxGlb) {
    loadGLBWithFallback(ASSET_URLS.foxGlb).then((gltf) => {
      if (!gltf || disposed) return;
      foxRoot = gltf.scene;
      foxRoot.scale.setScalar(0.018);
      foxRoot.position.set(-14, groundHeightAt(-14, 6), 6);
      group.add(foxRoot);

      if (gltf.animations.length > 0) {
        foxMixer = new THREE.AnimationMixer(foxRoot);
        const walkClip =
          gltf.animations.find((a) => /walk|run/i.test(a.name)) || gltf.animations[0];
        foxMixer.clipAction(walkClip).play();
      }
    });
  }

  return {
    group,
    terrainMesh,
    waterMesh,
    setGrassVisible: (visible: boolean) => {
      grassInst.visible = visible;
    },
    updateSun: (sunDirection: THREE.Vector3, sunColor: THREE.Color) => {
      const u = waterMesh.material.uniforms;
      if (u['sunDirection']) {
        (u['sunDirection'].value as THREE.Vector3).copy(sunDirection).normalize();
      }
      if (u['sunColor']) {
        (u['sunColor'].value as THREE.Color).copy(sunColor);
      }
    },
    update: (delta: number, elapsed: number, turbulence: number) => {
      const u = waterMesh.material.uniforms;
      if (u['time']) {
        u['time'].value += delta * (0.42 + turbulence * 0.45);
      }
      grassUniforms.uTime.value = elapsed;

      if (foxRoot && foxMixer) {
        foxMixer.update(delta);
        const t = elapsed * 0.22;
        const fx = -15 + Math.cos(t) * 4.5;
        const fz = 11 + Math.sin(t) * 6.5;
        const nextX = -15 + Math.cos(t + 0.05) * 4.5;
        const nextZ = 11 + Math.sin(t + 0.05) * 6.5;
        foxRoot.position.set(fx, groundHeightAt(fx, fz), fz);
        foxRoot.rotation.y = Math.atan2(nextX - fx, nextZ - fz);
      }
    },
    dispose: () => {
      disposed = true;
      foxMixer?.stopAllAction();
      loadedWaterNormals?.dispose();
      geo.dispose();
      terrainMat.dispose();
      waterGeo.dispose();
      waterMesh.material.dispose();
      grassGeo.dispose();
      grassMat.dispose();
      trunkGeo.dispose();
      trunkMat.dispose();
      canopyGeo.dispose();
      canopyMat.dispose();
      rockGeo.dispose();
      rockMat.dispose();
    },
  };
}
