import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { Sky } from 'three/addons/objects/Sky.js';
import type {
  AvatarParams,
  CameraPreset,
  HouseParams,
  PostProcessingConfig,
  QualityPreset,
  WeaponHUDState,
} from '../types/aguaviva';
import { ASSET_URLS, disposeAssetLoaders, loadHDRWithFallback } from './assetLoader';
import { createWorldTextures } from './pbrTextures';
import { createTerrainSystem, groundHeightAt } from './terrain';
import { createCityAndHouseSystem } from './houseBuilder';
import { createAvatarAndWeaponSystem } from './avatarAndWeapon';
import { createCombatEffectsSystem } from './combatEffects';
import { createPostProcessingPipeline } from './postProcessing';

export interface EngineCallbacks {
  onHudUpdate: (hud: WeaponHUDState) => void;
  onContextLost: (lost: boolean) => void;
}

// Pre-allocated math helpers outside animation loop (zero GC)
const _camForward = new THREE.Vector3();
const _camRight = new THREE.Vector3();
const _moveVec = new THREE.Vector3();
const _muzzlePos = new THREE.Vector3();
const _aimOrigin = new THREE.Vector3();
const _aimDir = new THREE.Vector3();
const _desiredTarget = new THREE.Vector3();
const _desiredCamPos = new THREE.Vector3();
const _sunColorDay = new THREE.Color('#fff1d6');
const _sunColorGolden = new THREE.Color('#ffae66');
const _fogDay = new THREE.Color('#8ec5e6');
const _fogGolden = new THREE.Color('#cf7e59');

function detectSoftwareWebGL(): boolean {
  try {
    const probe = document.createElement('canvas');
    const gl = probe.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) ?? '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export class AguaVivaEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private isSoftwareGl: boolean;
  private pmremGenerator: THREE.PMREMGenerator;
  private envRT: THREE.WebGLRenderTarget | null = null;
  private hdrTexture: THREE.DataTexture | null = null;
  private hasExternalHdr = false;

  private sky: Sky;
  private skyEnvScene: THREE.Scene;
  private skyEnvMesh: Sky;
  private sunDir = new THREE.Vector3(-0.6, 0.14, -0.75).normalize();

  private textures: ReturnType<typeof createWorldTextures>;
  private terrain: ReturnType<typeof createTerrainSystem>;
  private cityAndHouse: ReturnType<typeof createCityAndHouseSystem>;
  private avatarRig: ReturnType<typeof createAvatarAndWeaponSystem>;
  private combat: ReturnType<typeof createCombatEffectsSystem>;
  private postProc: ReturnType<typeof createPostProcessingPipeline> | null = null;

  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private fillLight: THREE.DirectionalLight;

  private clock = new THREE.Clock();
  private frameId = 0;
  private disposed = false;
  private qualityMode: QualityPreset;

  // Player & Avatar Kinematics
  private avatarPos = new THREE.Vector3(6.5, groundHeightAt(6.5, 9.5), 9.5);
  private avatarVelY = 0;
  private avatarYaw = Math.PI;
  private isGrounded = true;
  private keys: Record<string, boolean> = {};
  private touchMove = { x: 0, y: 0 };

  // Combat & Ammo State
  private ammo = 30;
  private maxAmmo = 30;
  private isReloading = false;
  private reloadTimer = 0;
  private shootAnimTimer = 0;
  private fireCooldown = 0;
  private currentEnergyColor: string;

  // Camera Transition Damping State
  private activePreset: CameraPreset = 'third_person';
  private presetTransitioning = false;

  // Telemetry values synced from React
  private riverTurbulence = 0.5;
  private solarIrradiance = 850;
  private postConfig: PostProcessingConfig;
  private callbacks: EngineCallbacks;
  private hudThrottle = 0;

  // Pointer click-to-shoot tracking
  private pointerDownPos = { x: 0, y: 0 };

  constructor(
    container: HTMLElement,
    initialHouse: HouseParams,
    initialAvatar: AvatarParams,
    initialPost: PostProcessingConfig,
    initialQuality: QualityPreset,
    callbacks: EngineCallbacks
  ) {
    this.container = container;
    this.postConfig = { ...initialPost };
    this.qualityMode = initialQuality;
    this.currentEnergyColor = initialAvatar.energyColor;
    this.callbacks = callbacks;

    const width = Math.max(320, container.clientWidth);
    const height = Math.max(240, container.clientHeight);

    // 1. Photographic Renderer (ACESFilmic, Exposure 1.05, SRGB, PCFSoftShadowMap, Mobile PixelRatio Cap)
    this.isSoftwareGl = detectSoftwareWebGL();
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.applyPixelRatio();
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 2. Scene, Golden Hour Sky & Warm Atmospheric FogExp2
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2('#cf7e59', 0.0056);

    this.sky = new Sky();
    this.sky.scale.setScalar(10000);
    const skyUniforms = this.sky.material.uniforms;
    skyUniforms['turbidity'].value = 8.5;
    skyUniforms['rayleigh'].value = 2.6;
    skyUniforms['mieCoefficient'].value = 0.005;
    skyUniforms['mieDirectionalG'].value = 0.82;
    this.scene.add(this.sky);

    // Dedicated Sky scene for PMREMGenerator environment reflection baking
    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.pmremGenerator.compileEquirectangularShader();
    this.skyEnvScene = new THREE.Scene();
    this.skyEnvMesh = new Sky();
    this.skyEnvMesh.scale.setScalar(1000);
    const envUni = this.skyEnvMesh.material.uniforms;
    envUni['turbidity'].value = 8.5;
    envUni['rayleigh'].value = 2.6;
    envUni['mieCoefficient'].value = 0.005;
    envUni['mieDirectionalG'].value = 0.82;
    this.skyEnvScene.add(this.skyEnvMesh);

    // 3. Camera & OrbitControls
    this.camera = new THREE.PerspectiveCamera(52, width / height, 0.15, 500);
    this.camera.position.set(11.5, 4.4, 17.5);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.07;
    this.controls.maxPolarAngle = Math.PI * 0.485;
    this.controls.minDistance = 2.2;
    this.controls.maxDistance = 95;
    this.controls.target.set(this.avatarPos.x, this.avatarPos.y + 1.35, this.avatarPos.z);
    this.controls.addEventListener('start', () => {
      this.presetTransitioning = false;
    });

    // 4. Golden Hour Lighting: Warm/Green Hemisphere + Sun DirectionalLight + Rim Fill
    this.hemiLight = new THREE.HemisphereLight('#ffb87a', '#1e3824', 0.68);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight('#ffae66', 2.7);
    this.sunLight.castShadow = !this.isSoftwareGl;
    this.sunLight.shadow.mapSize.width = 2048;
    this.sunLight.shadow.mapSize.height = 2048;
    this.sunLight.shadow.camera.near = 2;
    this.sunLight.shadow.camera.far = 140;
    const d = 30;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.0004;
    this.sunLight.shadow.normalBias = 0.025;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    this.fillLight = new THREE.DirectionalLight('#60a5fa', 0.42);
    this.fillLight.position.set(28, 14, 24);
    this.scene.add(this.fillLight);

    // 5. Procedural PBR Textures, Terrain + Water + Instanced Grass, House, Avatar & Combat VFX
    this.textures = createWorldTextures(this.renderer);
    this.terrain = createTerrainSystem(this.textures, this.isSoftwareGl);
    this.terrain.setGrassVisible(this.qualityMode === 'high');
    this.scene.add(this.terrain.group);

    this.cityAndHouse = createCityAndHouseSystem(this.textures, this.isSoftwareGl, initialHouse);
    this.scene.add(this.cityAndHouse.group);

    this.avatarRig = createAvatarAndWeaponSystem(this.textures, this.isSoftwareGl, initialAvatar);
    this.avatarRig.root.position.copy(this.avatarPos);
    this.avatarRig.root.rotation.y = this.avatarYaw;
    this.scene.add(this.avatarRig.root);

    this.combat = createCombatEffectsSystem(this.textures);
    this.scene.add(this.combat.group);

    // Sync Sky, PMREM Environment, Sun Light & Water Sun Direction
    this.updateSunPosition(initialPost.sunElevation, initialPost.sunAzimuth, true);

    // Optional async Sunset HDRI IBL enhancement (falls back seamlessly to Sky PMREM)
    if (!this.isSoftwareGl && ASSET_URLS.sunsetHdr) {
      loadHDRWithFallback(ASSET_URLS.sunsetHdr).then((hdr) => {
        if (!hdr) return;
        if (this.disposed) {
          hdr.dispose();
          return;
        }
        this.hdrTexture = hdr;
        this.hasExternalHdr = true;
        const newEnv = this.pmremGenerator.fromEquirectangular(hdr);
        this.envRT?.dispose();
        this.envRT = newEnv;
        this.scene.environment = newEnv.texture;
        this.scene.environmentIntensity = 0.95;
      });
    }

    // 6. Lightweight Post-Processing Pipeline (RenderPass -> UnrealBloomPass -> OutputPass)
    if (!this.isSoftwareGl) {
      this.postProc = createPostProcessingPipeline(
        this.renderer,
        this.scene,
        this.camera,
        width,
        height,
        this.postConfig
      );
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.emitHud();
    this.tick();
  }

  private applyPixelRatio() {
    if (this.isSoftwareGl || this.qualityMode === 'mobile') {
      this.renderer.setPixelRatio(1);
    } else {
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    }
  }

  private bindEvents() {
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);

    const dom = this.renderer.domElement;
    dom.addEventListener('pointerdown', this.handlePointerDown);
    dom.addEventListener('pointerup', this.handlePointerUp);
    dom.addEventListener('webglcontextlost', this.handleContextLost);
    dom.addEventListener('webglcontextrestored', this.handleContextRestored);
  }

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    this.callbacks.onContextLost(true);
  };

  private handleContextRestored = () => {
    this.callbacks.onContextLost(false);
  };

  private handleResize = () => {
    if (this.disposed) return;
    const width = Math.max(320, this.container.clientWidth);
    const height = Math.max(240, this.container.clientHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.postProc?.setSize(width, height);
  };

  private handleKeyDown = (e: KeyboardEvent) => {
    const target = e.target as HTMLElement | null;
    if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
      return;
    }
    this.keys[e.code] = true;

    if (e.code === 'Space' && this.isGrounded) {
      e.preventDefault();
      this.triggerJump();
    } else if (e.code === 'KeyR') {
      this.triggerReload();
    } else if (e.code === 'KeyF') {
      this.triggerFire();
    }
  };

  private handleKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  private handlePointerDown = (e: PointerEvent) => {
    this.pointerDownPos.x = e.clientX;
    this.pointerDownPos.y = e.clientY;
  };

  private handlePointerUp = (e: PointerEvent) => {
    if (e.button !== 0) return;
    const dist = Math.hypot(e.clientX - this.pointerDownPos.x, e.clientY - this.pointerDownPos.y);
    if (dist < 5 && this.activePreset === 'third_person') {
      this.triggerFire(e);
    }
  };

  public triggerJump() {
    if (!this.isGrounded) return;
    this.avatarVelY = 7.4;
    this.isGrounded = false;
    this.avatarRig.setAnimState('Jump', true);
    this.combat.playJumpAudio();
  }

  public triggerReload() {
    if (this.isReloading || this.ammo === this.maxAmmo) return;
    this.isReloading = true;
    this.reloadTimer = 1.35;
    this.avatarRig.setAnimState('Reload', true);
    this.combat.playReloadAudio();
    this.emitHud();
  }

  public triggerFire(pointerEvent?: PointerEvent) {
    if (this.isReloading || this.fireCooldown > 0) return;
    if (this.ammo <= 0) {
      this.triggerReload();
      return;
    }

    this.ammo--;
    this.fireCooldown = 0.16;
    this.shootAnimTimer = 0.24;
    this.avatarRig.setAnimState('Shoot', true);

    this.avatarRig.root.updateMatrixWorld(true);
    this.avatarRig.muzzleAnchor.getWorldPosition(_muzzlePos);

    if (pointerEvent) {
      const rect = this.renderer.domElement.getBoundingClientRect();
      const ndcX = ((pointerEvent.clientX - rect.left) / rect.width) * 2 - 1;
      const ndcY = -((pointerEvent.clientY - rect.top) / rect.height) * 2 + 1;
      const ray = new THREE.Raycaster();
      ray.setFromCamera(new THREE.Vector2(ndcX, ndcY), this.camera);
      _aimOrigin.copy(ray.ray.origin);
      _aimDir.copy(ray.ray.direction);
    } else {
      _aimOrigin.copy(this.camera.position);
      this.camera.getWorldDirection(_aimDir);
    }

    const flatYaw = Math.atan2(_aimDir.x, _aimDir.z);
    this.avatarYaw = flatYaw;
    this.avatarRig.root.rotation.y = this.avatarYaw;

    const allTargets = [this.terrain.terrainMesh, ...this.cityAndHouse.collidableMeshes];
    this.combat.fireWeapon(_muzzlePos, _aimOrigin, _aimDir, allTargets, this.currentEnergyColor);

    if (this.ammo === 0) {
      window.setTimeout(() => {
        if (!this.disposed) this.triggerReload();
      }, 220);
    }
    this.emitHud();
  }

  public updateHouse(params: HouseParams) {
    this.cityAndHouse.rebuildHouse(params);
  }

  public updateAvatar(params: AvatarParams) {
    this.currentEnergyColor = params.energyColor;
    this.avatarRig.updateParams(params);
  }

  public updateTelemetry(turbulence: number, solarIrradiance: number) {
    this.riverTurbulence = turbulence;
    this.solarIrradiance = solarIrradiance;
  }

  public updatePostProcessing(cfg: PostProcessingConfig) {
    const sunChanged =
      cfg.sunElevation !== this.postConfig.sunElevation ||
      cfg.sunAzimuth !== this.postConfig.sunAzimuth;
    this.postConfig = { ...cfg };
    this.postProc?.applyConfig(cfg);
    if (sunChanged) {
      this.updateSunPosition(cfg.sunElevation, cfg.sunAzimuth, !this.hasExternalHdr);
    }
  }

  public setQualityMode(mode: QualityPreset) {
    this.qualityMode = mode;
    this.applyPixelRatio();
    const width = Math.max(320, this.container.clientWidth);
    const height = Math.max(240, this.container.clientHeight);
    this.renderer.setSize(width, height);
    this.postProc?.setSize(width, height);
    this.terrain.setGrassVisible(mode === 'high');
  }

  public setAudioMuted(muted: boolean) {
    this.combat.setAudioMuted(muted);
  }

  public setTouchMove(x: number, y: number) {
    this.touchMove.x = THREE.MathUtils.clamp(x, -1, 1);
    this.touchMove.y = THREE.MathUtils.clamp(y, -1, 1);
  }

  private updateSunPosition(elevationDeg: number, azimuthDeg: number, rebuildEnv: boolean) {
    const phi = THREE.MathUtils.degToRad(90 - elevationDeg);
    const theta = THREE.MathUtils.degToRad(azimuthDeg);

    this.sunDir.setFromSphericalCoords(1, phi, theta).normalize();

    // Update Sky shader & sky reflection scene
    (this.sky.material.uniforms['sunPosition'].value as THREE.Vector3).copy(this.sunDir);
    (this.skyEnvMesh.material.uniforms['sunPosition'].value as THREE.Vector3).copy(this.sunDir);

    // Golden Hour atmospheric shift (warm orange/pink low sun -> crisp daylight higher)
    const dayBlend = THREE.MathUtils.clamp((elevationDeg - 6) / 38, 0, 1);
    this.sunLight.color.copy(_sunColorGolden).lerp(_sunColorDay, dayBlend);
    this.sunLight.intensity = 2.55 + dayBlend * 0.45;
    this.renderer.toneMappingExposure = 1.02 + (1 - dayBlend) * 0.06;

    if (this.scene.fog instanceof THREE.FogExp2) {
      this.scene.fog.color.copy(_fogGolden).lerp(_fogDay, dayBlend);
      this.scene.fog.density = 0.0056 - dayBlend * 0.0008;
    }

    // Center shadow map frustum on avatar + sync Water sun speculars
    this.sunLight.target.position.copy(this.avatarPos);
    this.sunLight.position.copy(this.avatarPos).addScaledVector(this.sunDir, 54);
    this.terrain.updateSun(this.sunDir, this.sunLight.color);

    if (rebuildEnv) {
      const nextEnv = this.pmremGenerator.fromScene(this.skyEnvScene, 0.04);
      this.envRT?.dispose();
      this.envRT = nextEnv;
      this.scene.environment = nextEnv.texture;
      this.scene.environmentIntensity = 0.9;
    }
  }

  public setCameraPreset(preset: CameraPreset) {
    this.activePreset = preset;
    this.presetTransitioning = true;

    if (preset === 'global') {
      _desiredTarget.set(6, 2.5, 0);
      _desiredCamPos.set(-34, 24, 42);
    } else if (preset === 'residence') {
      _desiredTarget.set(0, groundHeightAt(0, 0) + 3.2, 0);
      _desiredCamPos.set(14, groundHeightAt(0, 0) + 8.5, 19);
    } else if (preset === 'avatar_inspect') {
      _desiredTarget.set(this.avatarPos.x, this.avatarPos.y + 1.54, this.avatarPos.z);
      _desiredCamPos.set(
        this.avatarPos.x + Math.sin(this.avatarYaw + 0.16) * 1.65,
        this.avatarPos.y + 1.64,
        this.avatarPos.z + Math.cos(this.avatarYaw + 0.16) * 1.65
      );
    } else {
      _desiredTarget.set(this.avatarPos.x, this.avatarPos.y + 1.35, this.avatarPos.z);
      _desiredCamPos.set(this.avatarPos.x + 3.2, this.avatarPos.y + 3.0, this.avatarPos.z + 6.4);
    }
  }

  private emitHud() {
    this.callbacks.onHudUpdate({
      ammo: this.ammo,
      maxAmmo: this.maxAmmo,
      isReloading: this.isReloading,
      decalsCount: this.combat.getDecalCount(),
      animState: this.avatarRig.getAnimState(),
    });
  }

  private updatePlayerMovement(delta: number) {
    const keyForward =
      (this.keys['KeyW'] || this.keys['ArrowUp'] ? 1 : 0) -
      (this.keys['KeyS'] || this.keys['ArrowDown'] ? 1 : 0);
    const keyStrafe =
      (this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0) -
      (this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0);

    const forward = keyForward !== 0 ? keyForward : -this.touchMove.y;
    const strafe = keyStrafe !== 0 ? keyStrafe : this.touchMove.x;
    const joyMag = Math.hypot(this.touchMove.x, this.touchMove.y);

    const isMoving = Math.abs(forward) > 0.08 || Math.abs(strafe) > 0.08;
    const isSprinting = Boolean(this.keys['ShiftLeft'] || this.keys['ShiftRight']) || joyMag > 0.72;

    if (isMoving) {
      this.camera.getWorldDirection(_camForward);
      _camForward.y = 0;
      _camForward.normalize();
      _camRight.crossVectors(_camForward, THREE.Object3D.DEFAULT_UP).normalize();

      _moveVec.set(0, 0, 0);
      _moveVec.addScaledVector(_camForward, forward);
      _moveVec.addScaledVector(_camRight, strafe);
      if (_moveVec.lengthSq() > 0) _moveVec.normalize();

      const speed = isSprinting ? 9.4 : 4.8;
      const dx = _moveVec.x * speed * delta;
      const dz = _moveVec.z * speed * delta;

      this.avatarPos.x = THREE.MathUtils.clamp(this.avatarPos.x + dx, -65, 65);
      this.avatarPos.z = THREE.MathUtils.clamp(this.avatarPos.z + dz, -65, 65);

      const targetYaw = Math.atan2(_moveVec.x, _moveVec.z);
      let diff = targetYaw - this.avatarYaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.avatarYaw += diff * (1 - Math.exp(-12 * delta));
      this.avatarRig.root.rotation.y = this.avatarYaw;

      if (this.activePreset === 'third_person' && !this.presetTransitioning) {
        this.camera.position.x += dx;
        this.camera.position.z += dz;
        this.controls.target.x += dx;
        this.controls.target.z += dz;
      }
    }

    const groundY = groundHeightAt(this.avatarPos.x, this.avatarPos.z);
    if (!this.isGrounded) {
      this.avatarVelY -= 19.5 * delta;
      this.avatarPos.y += this.avatarVelY * delta;
      if (this.avatarPos.y <= groundY) {
        this.avatarPos.y = groundY;
        this.avatarVelY = 0;
        this.isGrounded = true;
      }
    } else {
      this.avatarPos.y = THREE.MathUtils.damp(this.avatarPos.y, groundY, 18, delta);
    }

    this.avatarRig.root.position.copy(this.avatarPos);

    // Keep DirectionalLight shadow frustum centered crisply around the avatar
    this.sunLight.target.position.copy(this.avatarPos);
    this.sunLight.position.copy(this.avatarPos).addScaledVector(this.sunDir, 54);

    if (this.activePreset === 'third_person' && !this.presetTransitioning) {
      const targetY = this.avatarPos.y + 1.35;
      const dy = targetY - this.controls.target.y;
      this.controls.target.y += dy * (1 - Math.exp(-12 * delta));
    }

    if (this.fireCooldown > 0) this.fireCooldown -= delta;
    if (this.shootAnimTimer > 0) this.shootAnimTimer -= delta;

    if (this.isReloading) {
      this.reloadTimer -= delta;
      if (this.reloadTimer <= 0) {
        this.isReloading = false;
        this.ammo = this.maxAmmo;
        this.emitHud();
      }
    } else if (this.shootAnimTimer <= 0) {
      if (!this.isGrounded) {
        this.avatarRig.setAnimState('Jump');
      } else if (isMoving) {
        this.avatarRig.setAnimState(isSprinting ? 'Run' : 'Walk');
      } else {
        this.avatarRig.setAnimState('Idle');
      }
    }
  }

  private tick = () => {
    if (this.disposed) return;

    const delta = Math.min(0.05, this.clock.getDelta());
    const elapsed = this.clock.elapsedTime;

    this.updatePlayerMovement(delta);

    if (this.presetTransitioning) {
      this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, _desiredCamPos.x, 5.5, delta);
      this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, _desiredCamPos.y, 5.5, delta);
      this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, _desiredCamPos.z, 5.5, delta);
      this.controls.target.x = THREE.MathUtils.damp(this.controls.target.x, _desiredTarget.x, 6.5, delta);
      this.controls.target.y = THREE.MathUtils.damp(this.controls.target.y, _desiredTarget.y, 6.5, delta);
      this.controls.target.z = THREE.MathUtils.damp(this.controls.target.z, _desiredTarget.z, 6.5, delta);
      if (this.camera.position.distanceToSquared(_desiredCamPos) < 0.02) {
        this.presetTransitioning = false;
      }
    }

    this.controls.update();

    this.terrain.update(delta, elapsed, this.riverTurbulence);
    this.cityAndHouse.update(elapsed, this.solarIrradiance);
    this.avatarRig.update(delta, elapsed);
    this.combat.update(delta);

    if (this.postProc && this.qualityMode === 'high') {
      this.postProc.render();
    } else {
      this.renderer.render(this.scene, this.camera);
    }

    this.hudThrottle += delta;
    if (this.hudThrottle > 0.25) {
      this.hudThrottle = 0;
      this.emitHud();
    }

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    window.clearTimeout(this.frameId);

    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);

    const dom = this.renderer.domElement;
    dom.removeEventListener('pointerdown', this.handlePointerDown);
    dom.removeEventListener('pointerup', this.handlePointerUp);
    dom.removeEventListener('webglcontextlost', this.handleContextLost);
    dom.removeEventListener('webglcontextrestored', this.handleContextRestored);

    this.controls.dispose();
    this.terrain.dispose();
    this.cityAndHouse.dispose();
    this.avatarRig.dispose();
    this.combat.dispose();
    this.textures.dispose();
    this.postProc?.dispose();
    this.envRT?.dispose();
    this.hdrTexture?.dispose();
    this.pmremGenerator.dispose();
    disposeAssetLoaders();
    this.renderer.dispose();
    if (dom.parentNode === this.container) {
      this.container.removeChild(dom);
    }
  }
}
