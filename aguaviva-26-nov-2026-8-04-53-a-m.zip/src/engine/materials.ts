import * as THREE from 'three';
import type { WorldTextures } from './pbrTextures';
import type { WallMaterialType, WeaponFinishType } from '../types/aguaviva';

/**
 * Creates a TERA-grade skin material with custom Subsurface Scattering (SSS)
 * injected via MeshPhysicalMaterial.onBeforeCompile so skin exhibits warm
 * dermal light wrap and back-scattering rather than looking like matte plastic.
 */
export function createSubsurfaceSkinMaterial(
  skinHex: string,
  sssIntensity = 0.68
): THREE.MeshPhysicalMaterial {
  const mat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(skinHex),
    roughness: 0.44,
    metalness: 0.0,
    clearcoat: 0.14,
    clearcoatRoughness: 0.48,
    sheen: 0.35,
    sheenRoughness: 0.65,
    sheenColor: new THREE.Color('#ff8a7a'),
  });

  mat.userData.sssIntensity = { value: sssIntensity };

  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uSssIntensity = mat.userData.sssIntensity;
    shader.uniforms.uSssColor = { value: new THREE.Color('#ff4d36') };

    shader.fragmentShader =
      `
      uniform float uSssIntensity;
      uniform vec3 uSssColor;
      ` + shader.fragmentShader;

    // Inject dermal wrap-scattering & view-dependent rim translucency right before tone mapping
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <opaque_fragment>',
      `
      #include <opaque_fragment>
      vec3 sssViewDir = normalize(vViewPosition);
      float sssFresnel = pow(1.0 - clamp(dot(normal, sssViewDir), 0.0, 1.0), 2.3);
      float sssCore = clamp(0.45 + 0.55 * normal.y, 0.0, 1.0);
      gl_FragColor.rgb += uSssColor * (sssFresnel * 0.28 + sssCore * 0.08) * uSssIntensity;
      `
    );
  };

  mat.customProgramCacheKey = () => 'aguaviva-sss-skin-v1';
  return mat;
}

export function createAnisotropicMetalMaterial(
  colorHex: string,
  textures: WorldTextures,
  roughness = 0.24,
  metalness = 0.92
): THREE.MeshPhysicalMaterial {
  return new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(colorHex),
    map: textures.titanium.map,
    normalMap: textures.titanium.normalMap,
    normalScale: new THREE.Vector2(0.35, 0.35),
    roughnessMap: textures.titanium.roughnessMap,
    roughness,
    metalness,
    anisotropy: 0.85,
    anisotropyRotation: 0.25,
    clearcoat: 0.2,
    clearcoatRoughness: 0.25,
  });
}

export function createArchitecturalGlassMaterial(
  isSoftwareGl: boolean,
  tintHex = '#c8ecff'
): THREE.MeshPhysicalMaterial {
  return new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(tintHex),
    metalness: 0.05,
    roughness: 0.06,
    transmission: isSoftwareGl ? 0 : 0.88,
    transparent: true,
    opacity: isSoftwareGl ? 0.38 : 1.0,
    ior: 1.52,
    thickness: 0.65,
    clearcoat: 1.0,
    clearcoatRoughness: 0.05,
    envMapIntensity: 1.35,
    depthWrite: false,
  });
}

export function createWallPBRMaterial(
  type: WallMaterialType,
  textures: WorldTextures
): THREE.MeshStandardMaterial {
  switch (type) {
    case 'brick':
      return new THREE.MeshStandardMaterial({
        map: textures.brick.map,
        normalMap: textures.brick.normalMap,
        normalScale: new THREE.Vector2(1.15, 1.15),
        roughnessMap: textures.brick.roughnessMap,
        roughness: 0.92,
        metalness: 0.02,
      });
    case 'cedar':
      return new THREE.MeshStandardMaterial({
        map: textures.cedar.map,
        normalMap: textures.cedar.normalMap,
        normalScale: new THREE.Vector2(0.85, 0.85),
        roughnessMap: textures.cedar.roughnessMap,
        roughness: 0.78,
        metalness: 0.04,
      });
    case 'titanium':
      return new THREE.MeshPhysicalMaterial({
        color: new THREE.Color('#cbd5e1'),
        map: textures.titanium.map,
        normalMap: textures.titanium.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        roughnessMap: textures.titanium.roughnessMap,
        roughness: 0.28,
        metalness: 0.9,
        anisotropy: 0.75,
      });
    case 'concrete':
    default:
      return new THREE.MeshStandardMaterial({
        color: new THREE.Color('#f1f5f9'),
        map: textures.concrete.map,
        normalMap: textures.concrete.normalMap,
        normalScale: new THREE.Vector2(0.9, 0.9),
        roughnessMap: textures.concrete.roughnessMap,
        roughness: 0.88,
        metalness: 0.05,
      });
  }
}

export function getWeaponFinishColors(finish: WeaponFinishType) {
  switch (finish) {
    case 'cobalt_alloy':
      return { primary: '#1e3a5f', secondary: '#0f172a', accent: '#38bdf8' };
    case 'anodized_carbon':
      return { primary: '#1e293b', secondary: '#090d16', accent: '#f59e0b' };
    case 'brushed_titanium':
    default:
      return { primary: '#94a3b8', secondary: '#1e293b', accent: '#22d3ee' };
  }
}
