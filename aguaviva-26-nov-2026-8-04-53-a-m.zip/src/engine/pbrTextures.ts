import * as THREE from 'three';

export interface PBRTextureSet {
  map: THREE.CanvasTexture;
  normalMap: THREE.DataTexture;
  roughnessMap: THREE.CanvasTexture;
  aoMap?: THREE.CanvasTexture;
}

export interface WorldTextures {
  asphalt: PBRTextureSet;
  concrete: PBRTextureSet;
  brick: PBRTextureSet;
  cedar: PBRTextureSet;
  titanium: PBRTextureSet;
  grass: PBRTextureSet;
  dirt: PBRTextureSet;
  rock: PBRTextureSet;
  wetBank: PBRTextureSet;
  bark: PBRTextureSet;
  solarCell: PBRTextureSet;
  waterNormals: THREE.DataTexture;
  muzzleFlash: THREE.CanvasTexture;
  smokePuff: THREE.CanvasTexture;
  bulletDecal: THREE.CanvasTexture;
  dispose: () => void;
}

function seededNoise(x: number, y: number, seed: number): number {
  const n = Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453123;
  return n - Math.floor(n);
}

function smoothNoise(x: number, y: number, seed: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const u = fx * fx * (3 - 2 * fx);
  const v = fy * fy * (3 - 2 * fy);
  const a = seededNoise(ix, iy, seed);
  const b = seededNoise(ix + 1, iy, seed);
  const c = seededNoise(ix, iy + 1, seed);
  const d = seededNoise(ix + 1, iy + 1, seed);
  return a * (1 - u) * (1 - v) + b * u * (1 - v) + c * (1 - u) * v + d * u * v;
}

function fbm2D(x: number, y: number, seed: number, octaves = 4): number {
  let val = 0;
  let amp = 0.5;
  let freq = 1;
  for (let i = 0; i < octaves; i++) {
    val += amp * smoothNoise(x * freq, y * freq, seed + i * 19);
    freq *= 2.02;
    amp *= 0.5;
  }
  return val;
}

function heightToNormalDataTexture(
  heightField: Float32Array,
  size: number,
  strength: number
): THREE.DataTexture {
  const data = new Uint8Array(size * size * 4);
  const idx = (x: number, y: number) => ((y + size) % size) * size + ((x + size) % size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      // Sobel filter for crisp tangent-space normal relief
      const tl = heightField[idx(x - 1, y - 1)];
      const t = heightField[idx(x, y - 1)];
      const tr = heightField[idx(x + 1, y - 1)];
      const l = heightField[idx(x - 1, y)];
      const r = heightField[idx(x + 1, y)];
      const bl = heightField[idx(x - 1, y + 1)];
      const b = heightField[idx(x, y + 1)];
      const br = heightField[idx(x + 1, y + 1)];

      const dX = tr + 2 * r + br - (tl + 2 * l + bl);
      const dY = bl + 2 * b + br - (tl + 2 * t + tr);

      let nx = -dX * strength;
      let ny = -dY * strength;
      let nz = 1.0;
      const len = Math.hypot(nx, ny, nz) || 1;
      nx /= len;
      ny /= len;
      nz /= len;

      const out = (y * size + x) * 4;
      data[out] = Math.round((nx * 0.5 + 0.5) * 255);
      data[out + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      data[out + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      data[out + 3] = 255;
    }
  }

  const tex = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

function makeCanvasPair(size: number, maxAniso: number) {
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const colorCtx = colorCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const roughCtx = roughCanvas.getContext('2d')!;

  const finalize = (
    heightField: Float32Array,
    normalStrength: number,
    repeatX = 1,
    repeatY = 1
  ): PBRTextureSet => {
    const map = new THREE.CanvasTexture(colorCanvas);
    map.colorSpace = THREE.SRGBColorSpace;
    map.wrapS = THREE.RepeatWrapping;
    map.wrapT = THREE.RepeatWrapping;
    map.repeat.set(repeatX, repeatY);
    map.anisotropy = maxAniso;

    const roughnessMap = new THREE.CanvasTexture(roughCanvas);
    roughnessMap.wrapS = THREE.RepeatWrapping;
    roughnessMap.wrapT = THREE.RepeatWrapping;
    roughnessMap.repeat.set(repeatX, repeatY);
    roughnessMap.anisotropy = maxAniso;

    const normalMap = heightToNormalDataTexture(heightField, size, normalStrength);
    normalMap.repeat.set(repeatX, repeatY);
    normalMap.anisotropy = maxAniso;

    return { map, normalMap, roughnessMap };
  };

  return { colorCanvas, colorCtx, roughCanvas, roughCtx, finalize };
}

function buildAsphaltSet(maxAniso: number): PBRTextureSet {
  const size = 256;
  const { colorCtx, roughCtx, finalize } = makeCanvasPair(size, maxAniso);
  const cImg = colorCtx.createImageData(size, size);
  const rImg = roughCtx.createImageData(size, size);
  const height = new Float32Array(size * size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const grain = seededNoise(x, y, 11) * 0.45 + fbm2D(x * 0.08, y * 0.08, 3, 3) * 0.55;
      // Subtle road crack ridge
      const crackWave = Math.abs(fbm2D(x * 0.035, y * 0.035, 71, 3) - 0.5);
      const isCrack = crackWave < 0.018 ? 1.0 - crackWave / 0.018 : 0;
      const puddle = fbm2D(x * 0.02, y * 0.02, 99, 3);

      const h = grain * 0.6 - isCrack * 0.75;
      height[i] = h;

      const base = 42 + grain * 26 - isCrack * 24;
      const p = i * 4;
      cImg.data[p] = Math.max(12, Math.min(255, base));
      cImg.data[p + 1] = Math.max(12, Math.min(255, base + 2));
      cImg.data[p + 2] = Math.max(15, Math.min(255, base + 5));
      cImg.data[p + 3] = 255;

      // Roughness: asphalt aggregate is rough (~215), damp micro-patches smoother (~115)
      const rough = puddle > 0.64 ? 120 + grain * 30 : 195 + grain * 45 - isCrack * 20;
      rImg.data[p] = rough;
      rImg.data[p + 1] = rough;
      rImg.data[p + 2] = rough;
      rImg.data[p + 3] = 255;
    }
  }
  colorCtx.putImageData(cImg, 0, 0);
  roughCtx.putImageData(rImg, 0, 0);

  // Crisp subtle dashed center road marking
  colorCtx.fillStyle = 'rgba(226, 232, 240, 0.78)';
  colorCtx.fillRect(size * 0.485, 14, size * 0.03, size * 0.34);
  colorCtx.fillRect(size * 0.485, size * 0.54, size * 0.03, size * 0.34);

  return finalize(height, 2.8, 1, 6);
}

function buildConcreteSet(maxAniso: number): PBRTextureSet {
  const size = 256;
  const { colorCtx, roughCtx, finalize } = makeCanvasPair(size, maxAniso);
  const cImg = colorCtx.createImageData(size, size);
  const rImg = roughCtx.createImageData(size, size);
  const height = new Float32Array(size * size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const n = fbm2D(x * 0.05, y * 0.05, 22, 4);
      const micro = seededNoise(x, y, 44) * 0.2;
      const seamY = y % 64 < 2 ? 1 : 0;
      const seamX = x % 128 < 2 ? 1 : 0;
      const seam = Math.max(seamY, seamX);

      height[i] = n * 0.5 + micro * 0.25 - seam * 0.6;
      const base = 176 + n * 34 - seam * 38;
      const p = i * 4;
      cImg.data[p] = base;
      cImg.data[p + 1] = base - 2;
      cImg.data[p + 2] = base - 6;
      cImg.data[p + 3] = 255;

      const rough = 185 + n * 48 + seam * 20;
      rImg.data[p] = rough;
      rImg.data[p + 1] = rough;
      rImg.data[p + 2] = rough;
      rImg.data[p + 3] = 255;
    }
  }
  colorCtx.putImageData(cImg, 0, 0);
  roughCtx.putImageData(rImg, 0, 0);
  return finalize(height, 2.2, 2, 2);
}

function buildBrickSet(maxAniso: number): PBRTextureSet {
  const size = 256;
  const { colorCtx, roughCtx, finalize } = makeCanvasPair(size, maxAniso);
  const cImg = colorCtx.createImageData(size, size);
  const rImg = roughCtx.createImageData(size, size);
  const height = new Float32Array(size * size);

  const brickH = 32;
  const brickW = 64;
  for (let y = 0; y < size; y++) {
    const row = Math.floor(y / brickH);
    const localY = y % brickH;
    const offset = (row % 2) * (brickW / 2);

    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const bx = (x + offset) % size;
      const col = Math.floor(bx / brickW);
      const localX = bx % brickW;

      const isMortar = localY < 4 || localX < 4;
      const brickTint = seededNoise(col, row, 88) * 32;
      const grain = fbm2D(x * 0.14, y * 0.14, 15, 3);

      height[i] = isMortar ? 0.12 + grain * 0.15 : 0.72 + grain * 0.28;
      const p = i * 4;
      if (isMortar) {
        const m = 188 + grain * 25;
        cImg.data[p] = m;
        cImg.data[p + 1] = m - 6;
        cImg.data[p + 2] = m - 12;
        rImg.data[p] = 235;
        rImg.data[p + 1] = 235;
        rImg.data[p + 2] = 235;
      } else {
        cImg.data[p] = Math.min(255, 148 + brickTint + grain * 26);
        cImg.data[p + 1] = Math.min(255, 72 + brickTint * 0.45 + grain * 18);
        cImg.data[p + 2] = Math.min(255, 54 + brickTint * 0.3 + grain * 14);
        const rough = 190 + grain * 45;
        rImg.data[p] = rough;
        rImg.data[p + 1] = rough;
        rImg.data[p + 2] = rough;
      }
      cImg.data[p + 3] = 255;
      rImg.data[p + 3] = 255;
    }
  }
  colorCtx.putImageData(cImg, 0, 0);
  roughCtx.putImageData(rImg, 0, 0);
  return finalize(height, 3.4, 3, 2);
}

function buildCedarSet(maxAniso: number): PBRTextureSet {
  const size = 256;
  const { colorCtx, roughCtx, finalize } = makeCanvasPair(size, maxAniso);
  const cImg = colorCtx.createImageData(size, size);
  const rImg = roughCtx.createImageData(size, size);
  const height = new Float32Array(size * size);

  for (let y = 0; y < size; y++) {
    const plank = Math.floor(y / 32);
    const seam = y % 32 < 2 ? 1 : 0;
    const plankShift = seededNoise(plank, 3, 19) * 18;
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const ring = Math.sin(
        (y * 0.25 + fbm2D(x * 0.02, y * 0.09, 55, 3) * 12) + plank * 3
      );
      const fiber = 0.5 + 0.5 * ring;
      height[i] = fiber * 0.45 - seam * 0.7;

      const p = i * 4;
      cImg.data[p] = Math.max(20, 148 + fiber * 42 - plankShift - seam * 55);
      cImg.data[p + 1] = Math.max(15, 92 + fiber * 28 - plankShift * 0.6 - seam * 45);
      cImg.data[p + 2] = Math.max(10, 56 + fiber * 18 - plankShift * 0.4 - seam * 30);
      cImg.data[p + 3] = 255;

      const rough = 135 + (1 - fiber) * 55 + seam * 40;
      rImg.data[p] = rough;
      rImg.data[p + 1] = rough;
      rImg.data[p + 2] = rough;
      rImg.data[p + 3] = 255;
    }
  }
  colorCtx.putImageData(cImg, 0, 0);
  roughCtx.putImageData(rImg, 0, 0);
  return finalize(height, 2.5, 2, 2);
}

function buildBrushedMetalSet(maxAniso: number): PBRTextureSet {
  const size = 256;
  const { colorCtx, roughCtx, finalize } = makeCanvasPair(size, maxAniso);
  const cImg = colorCtx.createImageData(size, size);
  const rImg = roughCtx.createImageData(size, size);
  const height = new Float32Array(size * size);

  for (let y = 0; y < size; y++) {
    const streak = seededNoise(0, y, 121) * 0.6 + smoothNoise(0, y * 0.35, 7) * 0.4;
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const fine = seededNoise(x * 0.08, y, 211) * 0.25;
      const val = streak * 0.75 + fine;
      height[i] = val * 0.25;

      const p = i * 4;
      const c = 185 + val * 45;
      cImg.data[p] = c;
      cImg.data[p + 1] = c + 3;
      cImg.data[p + 2] = c + 8;
      cImg.data[p + 3] = 255;

      const rough = 52 + val * 58;
      rImg.data[p] = rough;
      rImg.data[p + 1] = rough;
      rImg.data[p + 2] = rough;
      rImg.data[p + 3] = 255;
    }
  }
  colorCtx.putImageData(cImg, 0, 0);
  roughCtx.putImageData(rImg, 0, 0);
  return finalize(height, 1.2, 1, 1);
}

function buildTerrainLayer(
  maxAniso: number,
  seed: number,
  baseRGB: [number, number, number],
  varRGB: [number, number, number],
  normalStr: number,
  roughBase: number
): PBRTextureSet {
  const size = 256;
  const { colorCtx, roughCtx, finalize } = makeCanvasPair(size, maxAniso);
  const cImg = colorCtx.createImageData(size, size);
  const rImg = roughCtx.createImageData(size, size);
  const height = new Float32Array(size * size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const macro = fbm2D(x * 0.04, y * 0.04, seed, 4);
      const micro = seededNoise(x, y, seed + 5) * 0.35;
      const h = macro * 0.7 + micro * 0.3;
      height[i] = h;

      const p = i * 4;
      cImg.data[p] = Math.max(0, Math.min(255, baseRGB[0] + (h - 0.5) * varRGB[0]));
      cImg.data[p + 1] = Math.max(0, Math.min(255, baseRGB[1] + (h - 0.5) * varRGB[1]));
      cImg.data[p + 2] = Math.max(0, Math.min(255, baseRGB[2] + (h - 0.5) * varRGB[2]));
      cImg.data[p + 3] = 255;

      const r = Math.max(20, Math.min(255, roughBase + (0.5 - h) * 60));
      rImg.data[p] = r;
      rImg.data[p + 1] = r;
      rImg.data[p + 2] = r;
      rImg.data[p + 3] = 255;
    }
  }
  colorCtx.putImageData(cImg, 0, 0);
  roughCtx.putImageData(rImg, 0, 0);
  return finalize(height, normalStr, 14, 14);
}

function buildBarkSet(maxAniso: number): PBRTextureSet {
  const size = 256;
  const { colorCtx, roughCtx, finalize } = makeCanvasPair(size, maxAniso);
  const cImg = colorCtx.createImageData(size, size);
  const rImg = roughCtx.createImageData(size, size);
  const height = new Float32Array(size * size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      // Vertical furrowed pine bark ridges
      const warp = fbm2D(x * 0.05, y * 0.018, 606, 3) * 14;
      const ridge = Math.sin((x + warp) * 0.42) * 0.5 + 0.5;
      const crack = ridge < 0.24 ? (0.24 - ridge) / 0.24 : 0;
      const grain = seededNoise(x, y, 707) * 0.22 + fbm2D(x * 0.12, y * 0.04, 808, 3) * 0.55;

      const h = ridge * 0.65 + grain * 0.35 - crack * 0.5;
      height[i] = h;

      const p = i * 4;
      cImg.data[p] = Math.max(18, Math.min(255, 86 + ridge * 38 - crack * 44 + grain * 18));
      cImg.data[p + 1] = Math.max(14, Math.min(255, 58 + ridge * 26 - crack * 32 + grain * 12));
      cImg.data[p + 2] = Math.max(10, Math.min(255, 42 + ridge * 18 - crack * 22 + grain * 8));
      cImg.data[p + 3] = 255;

      const rough = Math.min(255, 205 + crack * 38 - ridge * 18);
      rImg.data[p] = rough;
      rImg.data[p + 1] = rough;
      rImg.data[p + 2] = rough;
      rImg.data[p + 3] = 255;
    }
  }
  colorCtx.putImageData(cImg, 0, 0);
  roughCtx.putImageData(rImg, 0, 0);
  return finalize(height, 4.0, 2, 3);
}

function buildWaterNormalsTexture(maxAniso: number): THREE.DataTexture {
  const size = 256;
  const height = new Float32Array(size * size);
  const twoPi = Math.PI * 2;
  for (let y = 0; y < size; y++) {
    const v = y / size;
    for (let x = 0; x < size; x++) {
      const u = x / size;
      // Tileable periodic multi-directional ripples
      const w1 = Math.sin(twoPi * (u * 3 + v * 2));
      const w2 = Math.cos(twoPi * (u * 5 - v * 4) + 0.8);
      const w3 = Math.sin(twoPi * (u * 8 + v * 7) + 1.9) * 0.5;
      const w4 = Math.cos(twoPi * (u * 13 - v * 11) + 0.4) * 0.28;
      height[y * size + x] = (w1 + w2 + w3 + w4) * 0.25 + 0.5;
    }
  }
  const tex = heightToNormalDataTexture(height, size, 2.2);
  tex.anisotropy = maxAniso;
  return tex;
}

function buildSolarCellSet(maxAniso: number): PBRTextureSet {
  const size = 256;
  const { colorCtx, roughCtx, finalize } = makeCanvasPair(size, maxAniso);
  const height = new Float32Array(size * size);

  colorCtx.fillStyle = '#0c1c38';
  colorCtx.fillRect(0, 0, size, size);
  roughCtx.fillStyle = '#222222';
  roughCtx.fillRect(0, 0, size, size);

  colorCtx.strokeStyle = '#60a5fa';
  colorCtx.lineWidth = 2;
  for (let i = 0; i <= 4; i++) {
    const pos = (i * size) / 4;
    colorCtx.beginPath();
    colorCtx.moveTo(pos, 0);
    colorCtx.lineTo(pos, size);
    colorCtx.moveTo(0, pos);
    colorCtx.lineTo(size, pos);
    colorCtx.stroke();
  }

  // Fine silver busbars
  colorCtx.strokeStyle = 'rgba(203, 213, 225, 0.35)';
  colorCtx.lineWidth = 1;
  for (let i = 0; i < 16; i++) {
    const y = (i * size) / 16;
    colorCtx.beginPath();
    colorCtx.moveTo(0, y);
    colorCtx.lineTo(size, y);
    colorCtx.stroke();
  }

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const grid = x % 64 < 3 || y % 64 < 3 ? 0.8 : 0.2;
      height[y * size + x] = grid;
    }
  }

  return finalize(height, 1.4, 2, 1);
}

function buildMuzzleFlashTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  ctx.clearRect(0, 0, size, size);

  // Outer warm plasma halo
  const grad = ctx.createRadialGradient(cx, cy, 4, cx, cy, size * 0.48);
  grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
  grad.addColorStop(0.22, 'rgba(255, 225, 130, 0.95)');
  grad.addColorStop(0.5, 'rgba(255, 130, 30, 0.55)');
  grad.addColorStop(1, 'rgba(255, 60, 0, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  // Star spikes
  ctx.save();
  ctx.translate(cx, cy);
  for (let i = 0; i < 8; i++) {
    ctx.rotate(Math.PI / 4);
    const spikeGrad = ctx.createLinearGradient(0, 0, size * 0.48, 0);
    spikeGrad.addColorStop(0, 'rgba(255, 250, 220, 0.95)');
    spikeGrad.addColorStop(1, 'rgba(255, 140, 20, 0)');
    ctx.fillStyle = spikeGrad;
    ctx.beginPath();
    ctx.moveTo(0, -10);
    ctx.lineTo(size * 0.46, 0);
    ctx.lineTo(0, 10);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildSmokeTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const grad = ctx.createRadialGradient(cx, cx, 4, cx, cx, cx);
  grad.addColorStop(0, 'rgba(226, 232, 240, 0.72)');
  grad.addColorStop(0.45, 'rgba(148, 163, 184, 0.35)');
  grad.addColorStop(1, 'rgba(100, 116, 139, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function buildBulletDecalTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  // Outer scorch ring
  const scorch = ctx.createRadialGradient(cx, cy, 8, cx, cy, 56);
  scorch.addColorStop(0, 'rgba(10, 10, 12, 0.96)');
  scorch.addColorStop(0.28, 'rgba(28, 25, 23, 0.85)');
  scorch.addColorStop(0.58, 'rgba(55, 48, 42, 0.42)');
  scorch.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = scorch;
  ctx.fillRect(0, 0, size, size);

  // Radial fracture cracks
  ctx.strokeStyle = 'rgba(15, 15, 18, 0.85)';
  ctx.lineWidth = 2;
  for (let i = 0; i < 9; i++) {
    const angle = (i / 9) * Math.PI * 2 + seededNoise(i, 2, 9) * 0.4;
    const len = 26 + seededNoise(i, 7, 3) * 24;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(
      cx + Math.cos(angle) * len * 0.55 + Math.sin(angle) * 4,
      cy + Math.sin(angle) * len * 0.55
    );
    ctx.lineTo(cx + Math.cos(angle) * len, cy + Math.sin(angle) * len);
    ctx.stroke();
  }

  // Deep dark core cavity
  ctx.fillStyle = '#050507';
  ctx.beginPath();
  ctx.arc(cx, cy, 11, 0, Math.PI * 2);
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createWorldTextures(renderer: THREE.WebGLRenderer): WorldTextures {
  const maxAniso = Math.min(8, renderer.capabilities.getMaxAnisotropy() || 1);

  const asphalt = buildAsphaltSet(maxAniso);
  const concrete = buildConcreteSet(maxAniso);
  const brick = buildBrickSet(maxAniso);
  const cedar = buildCedarSet(maxAniso);
  const titanium = buildBrushedMetalSet(maxAniso);
  const grass = buildTerrainLayer(maxAniso, 101, [64, 102, 54], [48, 56, 36], 2.4, 210);
  const dirt = buildTerrainLayer(maxAniso, 202, [118, 92, 66], [46, 38, 30], 2.9, 225);
  const rock = buildTerrainLayer(maxAniso, 303, [94, 99, 106], [64, 64, 68], 4.2, 185);
  const wetBank = buildTerrainLayer(maxAniso, 404, [62, 68, 65], [34, 34, 34], 2.6, 85);
  const bark = buildBarkSet(maxAniso);
  const solarCell = buildSolarCellSet(maxAniso);
  const waterNormals = buildWaterNormalsTexture(maxAniso);
  const muzzleFlash = buildMuzzleFlashTexture();
  const smokePuff = buildSmokeTexture();
  const bulletDecal = buildBulletDecalTexture();

  const disposeSet = (s: PBRTextureSet) => {
    s.map.dispose();
    s.normalMap.dispose();
    s.roughnessMap.dispose();
    s.aoMap?.dispose();
  };

  return {
    asphalt,
    concrete,
    brick,
    cedar,
    titanium,
    grass,
    dirt,
    rock,
    wetBank,
    bark,
    solarCell,
    waterNormals,
    muzzleFlash,
    smokePuff,
    bulletDecal,
    dispose: () => {
      [
        asphalt,
        concrete,
        brick,
        cedar,
        titanium,
        grass,
        dirt,
        rock,
        wetBank,
        bark,
        solarCell,
      ].forEach(disposeSet);
      waterNormals.dispose();
      muzzleFlash.dispose();
      smokePuff.dispose();
      bulletDecal.dispose();
    },
  };
}
