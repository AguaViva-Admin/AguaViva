import 'dotenv/config';
import express from 'express';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, Type } from '@google/genai';
import type {
  BlockchainState,
  DilithiumBlock,
  DilithiumTransaction,
  HouseParams,
  AvatarParams,
  TwinTelemetry,
} from './src/types/aguaviva.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

// ---------------------------------------------------------------------------
// Post-Quantum CRYSTALS-Dilithium-3 (ML-DSA-65) Ledger & Banking Engine
// Zero EVM / Solana / Bitcoin dependencies — Lattice-commitment SHAKE256 + SHA3-256
// ---------------------------------------------------------------------------

function shakeHex(input: string, byteLength: number): string {
  return crypto
    .createHash('shake256', { outputLength: byteLength })
    .update(input)
    .digest('hex');
}

function sha3Hex(input: string): string {
  return crypto.createHash('sha3-256').update(input).digest('hex');
}

// Deterministic node keypair seed representing ML-DSA-65 (NIST Level 3)
const MASTER_LATTICE_SEED = sha3Hex('AGUAVIVA_POST_QUANTUM_GENESIS_ML_DSA_65');
const CITIZEN_PUBKEY_HEX = shakeHex(`${MASTER_LATTICE_SEED}:pk`, 48); // 1952B full ML-DSA-65 pk represented by fingerprint
const CITIZEN_ADDRESS = `agv1q${shakeHex(CITIZEN_PUBKEY_HEX, 18)}`;

function signDilithium3(payload: string): string {
  // Produces deterministic 64-byte fingerprint of a 3,293-byte ML-DSA-65 lattice signature
  const commitment = shakeHex(`${MASTER_LATTICE_SEED}:sk:${payload}`, 48);
  return `mldsa65_${commitment}`;
}

function computeMerkleRoot(txs: DilithiumTransaction[]): string {
  if (txs.length === 0) return sha3Hex('EMPTY_BLOCK');
  return sha3Hex(txs.map((t) => `${t.txId}:${t.dilithiumSignature}`).join('|'));
}

const initialBlueprintHash = sha3Hex(
  JSON.stringify({
    width: 12,
    depth: 10,
    height: 5.5,
    floors: 2,
    wallMaterial: 'concrete',
    roofStyle: 'flat_solar',
  })
);

const initialAvatarHash = sha3Hex(
  JSON.stringify({
    armorStyle: 'crysis_nanosuit',
    weaponFinish: 'brushed_titanium',
    faceShape: 'heroic',
    hairStyle: 'styled_spiky_mlbb',
  })
);

const genesisTx: DilithiumTransaction = {
  txId: `pqtx_${sha3Hex('genesis_mint').slice(0, 20)}`,
  type: 'MINT_DEED',
  from: 'agv1q_protocol_treasury',
  to: CITIZEN_ADDRESS,
  amount: 24500,
  assetHash: initialBlueprintHash,
  dilithiumSignature: signDilithium3(`genesis:${CITIZEN_ADDRESS}:24500`),
  publicKeyFingerprint: CITIZEN_PUBKEY_HEX.slice(0, 32),
  timestamp: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
  summary: 'Emisión génesis de cuenta ciudadana y escritura de parcela #042',
};

const genesisBlock: DilithiumBlock = {
  height: 1,
  blockHash: sha3Hex(`block:1:${genesisTx.txId}`),
  prevHash: '0'.repeat(64),
  merkleRoot: computeMerkleRoot([genesisTx]),
  validatorNode: 'val-andes-01.aguaviva.pq',
  algorithm: 'CRYSTALS-Dilithium-3 (ML-DSA-65)',
  timestamp: genesisTx.timestamp,
  transactions: [genesisTx],
};

const ledgerState: BlockchainState = {
  networkName: 'AguaViva Mainnet-PQ',
  consensus: 'PoS Hídrico + BFT Postcuántico',
  quantumSecurityLevel: 'NIST Nivel 3 · Dilithium-3 (ML-DSA-65, sin EVM/Solana)',
  blockHeight: 1,
  citizenAddress: CITIZEN_ADDRESS,
  balanceAGV: 24500,
  stakedHydroAGV: 4200,
  publicKeyHex: CITIZEN_PUBKEY_HEX,
  deeds: [
    {
      deedId: 'DEED-CASA-042',
      assetKind: 'RESIDENCE_TWIN',
      title: 'Eco-Residencia Parcela #042',
      blueprintHash: initialBlueprintHash,
      dilithiumProof: signDilithium3(initialBlueprintHash),
      updatedAt: genesisTx.timestamp,
    },
    {
      deedId: 'DEED-AVATAR-042',
      assetKind: 'AVATAR_BIO',
      title: 'Bio-Avatar Realista Crysis/MLBB',
      blueprintHash: initialAvatarHash,
      dilithiumProof: signDilithium3(initialAvatarHash),
      updatedAt: genesisTx.timestamp,
    },
  ],
  blocks: [genesisBlock],
};

function appendBlock(tx: DilithiumTransaction): DilithiumBlock {
  const prev = ledgerState.blocks[0];
  const nextHeight = prev.height + 1;
  const merkleRoot = computeMerkleRoot([tx]);
  const blockHash = sha3Hex(`block:${nextHeight}:${prev.blockHash}:${merkleRoot}`);
  const validators = [
    'val-andes-01.aguaviva.pq',
    'val-nordic-04.aguaviva.pq',
    'val-kyoto-09.aguaviva.pq',
    'val-patagonia-02.aguaviva.pq',
  ];
  const block: DilithiumBlock = {
    height: nextHeight,
    blockHash,
    prevHash: prev.blockHash,
    merkleRoot,
    validatorNode: validators[nextHeight % validators.length],
    algorithm: 'CRYSTALS-Dilithium-3 (ML-DSA-65)',
    timestamp: tx.timestamp,
    transactions: [tx],
  };
  ledgerState.blockHeight = nextHeight;
  ledgerState.blocks = [block, ...ledgerState.blocks].slice(0, 12);
  return block;
}

// ---------------------------------------------------------------------------
// Express App & Routes
// ---------------------------------------------------------------------------

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // Digital Twin global real-time telemetry
  app.get('/api/twin/telemetry', (_req, res) => {
    const t = Date.now() / 1000;
    const wave = (amp: number, freq: number, phase = 0) =>
      Math.sin(t * freq + phase) * amp;

    const telemetry: TwinTelemetry = {
      timestamp: new Date().toISOString(),
      globalCitizensOnline: Math.round(184320 + wave(420, 0.25)),
      totalCleanWaterM3: Math.round(4928150 + wave(1200, 0.1)),
      renewableGridPct: Number((96.4 + wave(0.6, 0.15)).toFixed(1)),
      carbonOffsetTons: Number((12840.5 + wave(18, 0.08)).toFixed(1)),
      riverTurbulence: Number((0.48 + wave(0.12, 0.4)).toFixed(2)),
      solarIrradiance: Number((845 + wave(35, 0.12)).toFixed(0)),
      districts: [
        {
          id: 'dist-valley',
          name: 'Valle Central Hidro-Solar',
          waterPurityPct: Number((99.2 + wave(0.2, 0.3)).toFixed(1)),
          solarOutputMW: Number((142.8 + wave(3.4, 0.2)).toFixed(1)),
          riverFlowM3s: Number((68.4 + wave(2.1, 0.35)).toFixed(1)),
          airQualityAQI: Math.round(14 + wave(2, 0.2)),
          activeNodes: 412,
        },
        {
          id: 'dist-fjord',
          name: 'Corredor Nórdico Bio-Urbano',
          waterPurityPct: Number((99.6 + wave(0.15, 0.25, 1)).toFixed(1)),
          solarOutputMW: Number((98.2 + wave(2.2, 0.18, 1.4)).toFixed(1)),
          riverFlowM3s: Number((94.0 + wave(3.0, 0.28, 0.8)).toFixed(1)),
          airQualityAQI: Math.round(11 + wave(1.5, 0.15, 1)),
          activeNodes: 318,
        },
        {
          id: 'dist-pacific',
          name: 'Distrito Costero Paramétrico',
          waterPurityPct: Number((98.7 + wave(0.25, 0.32, 2.2)).toFixed(1)),
          solarOutputMW: Number((188.5 + wave(4.1, 0.22, 2.1)).toFixed(1)),
          riverFlowM3s: Number((52.3 + wave(1.8, 0.3, 1.7)).toFixed(1)),
          airQualityAQI: Math.round(18 + wave(2.5, 0.22, 2)),
          activeNodes: 529,
        },
      ],
    };

    res.json(telemetry);
  });

  // Post-quantum Dilithium-3 Blockchain State
  app.get('/api/blockchain/state', (_req, res) => {
    res.json(ledgerState);
  });

  // Submit & sign a post-quantum Dilithium-3 transaction
  app.post('/api/blockchain/tx', (req, res) => {
    const { type, to, amount, summary, houseParams, avatarParams } = req.body as {
      type: DilithiumTransaction['type'];
      to?: string;
      amount?: number;
      summary?: string;
      houseParams?: HouseParams;
      avatarParams?: AvatarParams;
    };

    const validTypes = ['MINT_DEED', 'TRANSFER', 'ECO_REWARD', 'AVATAR_FORGE'];
    if (!validTypes.includes(type)) {
      res.status(400).json({ error: 'Tipo de transacción postcuántica no válido.' });
      return;
    }

    const txAmount = typeof amount === 'number' && Number.isFinite(amount) ? Math.max(0, Math.round(amount * 100) / 100) : 0;

    if (type === 'TRANSFER') {
      if (txAmount <= 0) {
        res.status(400).json({ error: 'El monto de transferencia debe ser mayor a cero.' });
        return;
      }
      if (txAmount > ledgerState.balanceAGV) {
        res.status(400).json({ error: 'Saldo insuficiente en bóveda Dilithium-3.' });
        return;
      }
      ledgerState.balanceAGV = Number((ledgerState.balanceAGV - txAmount).toFixed(2));
    } else if (type === 'ECO_REWARD') {
      ledgerState.balanceAGV = Number((ledgerState.balanceAGV + txAmount).toFixed(2));
      ledgerState.stakedHydroAGV = Number((ledgerState.stakedHydroAGV + Math.round(txAmount * 0.2)).toFixed(2));
    } else if (type === 'MINT_DEED' || type === 'AVATAR_FORGE') {
      const fee = 25;
      if (ledgerState.balanceAGV < fee) {
        res.status(400).json({ error: 'Se requieren 25 AGV de tarifa de red para sellar la escritura postcuántica.' });
        return;
      }
      ledgerState.balanceAGV = Number((ledgerState.balanceAGV - fee).toFixed(2));
    }

    const now = new Date().toISOString();
    const assetPayload = houseParams
      ? JSON.stringify(houseParams)
      : avatarParams
      ? JSON.stringify(avatarParams)
      : `${type}:${now}`;
    const assetHash = sha3Hex(assetPayload);
    const sigPayload = `${type}:${CITIZEN_ADDRESS}:${to ?? CITIZEN_ADDRESS}:${txAmount}:${assetHash}:${now}`;
    const dilithiumSignature = signDilithium3(sigPayload);

    const tx: DilithiumTransaction = {
      txId: `pqtx_${sha3Hex(sigPayload).slice(0, 20)}`,
      type,
      from: type === 'ECO_REWARD' ? 'agv1q_hydro_oracle' : CITIZEN_ADDRESS,
      to: to && to.trim().length > 4 ? to.trim() : CITIZEN_ADDRESS,
      amount: type === 'MINT_DEED' || type === 'AVATAR_FORGE' ? 25 : txAmount,
      assetHash,
      dilithiumSignature,
      publicKeyFingerprint: CITIZEN_PUBKEY_HEX.slice(0, 32),
      timestamp: now,
      summary:
        summary?.trim() ||
        (type === 'MINT_DEED'
          ? 'Actualización paramétrica de Eco-Residencia sellada en Dilithium-3'
          : type === 'AVATAR_FORGE'
          ? 'Identidad biométrica de Bio-Avatar registrada en cadena'
          : type === 'ECO_REWARD'
          ? 'Recompensa por inyección solar e hidroeléctrica urbana'
          : 'Transferencia P2P postcuántica AguaViva'),
    };

    if (type === 'MINT_DEED' && houseParams) {
      const existing = ledgerState.deeds.find((d) => d.assetKind === 'RESIDENCE_TWIN');
      if (existing) {
        existing.blueprintHash = assetHash;
        existing.dilithiumProof = dilithiumSignature;
        existing.updatedAt = now;
      }
    }
    if (type === 'AVATAR_FORGE' && avatarParams) {
      const existing = ledgerState.deeds.find((d) => d.assetKind === 'AVATAR_BIO');
      if (existing) {
        existing.blueprintHash = assetHash;
        existing.dilithiumProof = dilithiumSignature;
        existing.updatedAt = now;
      }
    }

    appendBlock(tx);
    res.json({ tx, state: ledgerState });
  });

  // Server-Side Generative AI Architect & Avatar Designer via @google/genai
  app.post('/api/ai/design', async (req, res) => {
    const { prompt } = req.body as { prompt?: string };
    if (!prompt || typeof prompt !== 'string' || prompt.trim().length < 3) {
      res.status(400).json({ error: 'Describe el estilo arquitectónico o de avatar que deseas generar.' });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      res.status(503).json({
        error:
          'Falta configurar GEMINI_API_KEY en el panel Settings > Secrets de AI Studio para activar el diseñador generativo.',
      });
      return;
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Eres el arquitecto paramétrico jefe de AguaViva, una plataforma global de gemelos digitales 3D sostenibles.
Genera una configuración coherente de casa paramétrica y bio-avatar basada en esta solicitud del ciudadano:
"${prompt.trim()}"

Reglas estrictas de rangos:
- house.width: 8 a 18
- house.depth: 7 a 15
- house.height: 3.5 a 8.5
- house.floors: 1 o 2
- house.wallMaterial: "concrete", "brick", "cedar", o "titanium"
- house.roofStyle: "flat_solar", "gabled", o "parametric_vault"
- house.accentColor: hex #RRGGBB
- house.glassRatio: 0.25 a 0.85
- house.solarPanels: entero 0 a 12
- house.hydroTurbine: boolean
- avatar.skinTone: hex realista de piel (#f2c6a0, #d89b72, #8d5524, #c68642, #e0ac69, etc.)
- avatar.hairColor: hex #RRGGBB
- avatar.eyeColor: hex realista de iris (#2563eb, #10b981, #78350f, #8b5cf6, #06b6d4, #64748b)
- avatar.armorColor: hex #RRGGBB
- avatar.energyColor: hex #RRGGBB
- avatar.armorStyle: "crysis_nanosuit", "mu_valkyrie", "freefire_tactical", o "mlbb_hero"
- avatar.weaponFinish: "anodized_carbon", "brushed_titanium", o "cobalt_alloy"
- avatar.faceShape: "heroic", "elven_mu", "tactical_square", o "youthful_mlbb"
- avatar.eyeStyle: "almond", "mystic_mu", "intense_crysis", o "expressive_mlbb"
- avatar.mouthStyle: "balanced", "full_defined", "sharp_tactical", o "natural_smile"
- avatar.hairStyle: "tactical_short", "heroic_long_mu", "styled_spiky_mlbb", "urban_waves", o "crysis_helmet"
- avatar.expression: "serene", "smile", "determined", "surprised", o "wink"
- avatar.gazeDirection: "center", "left", "right", "up", o "down"
- avatar.heightScale: 0.92 a 1.12
- avatar.sssIntensity: 0.4 a 0.95`,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              conceptTitle: { type: Type.STRING },
              architecturalNotes: { type: Type.STRING },
              house: {
                type: Type.OBJECT,
                properties: {
                  width: { type: Type.NUMBER },
                  depth: { type: Type.NUMBER },
                  height: { type: Type.NUMBER },
                  floors: { type: Type.INTEGER },
                  wallMaterial: { type: Type.STRING },
                  roofStyle: { type: Type.STRING },
                  accentColor: { type: Type.STRING },
                  glassRatio: { type: Type.NUMBER },
                  solarPanels: { type: Type.INTEGER },
                  hydroTurbine: { type: Type.BOOLEAN },
                },
                required: [
                  'width',
                  'depth',
                  'height',
                  'floors',
                  'wallMaterial',
                  'roofStyle',
                  'accentColor',
                  'glassRatio',
                  'solarPanels',
                  'hydroTurbine',
                ],
              },
              avatar: {
                type: Type.OBJECT,
                properties: {
                  skinTone: { type: Type.STRING },
                  hairColor: { type: Type.STRING },
                  eyeColor: { type: Type.STRING },
                  armorColor: { type: Type.STRING },
                  energyColor: { type: Type.STRING },
                  armorStyle: { type: Type.STRING },
                  weaponFinish: { type: Type.STRING },
                  faceShape: { type: Type.STRING },
                  eyeStyle: { type: Type.STRING },
                  mouthStyle: { type: Type.STRING },
                  hairStyle: { type: Type.STRING },
                  expression: { type: Type.STRING },
                  gazeDirection: { type: Type.STRING },
                  heightScale: { type: Type.NUMBER },
                  sssIntensity: { type: Type.NUMBER },
                },
                required: [
                  'skinTone',
                  'hairColor',
                  'eyeColor',
                  'armorColor',
                  'energyColor',
                  'armorStyle',
                  'weaponFinish',
                  'faceShape',
                  'eyeStyle',
                  'mouthStyle',
                  'hairStyle',
                  'expression',
                  'gazeDirection',
                  'heightScale',
                  'sssIntensity',
                ],
              },
            },
            required: ['conceptTitle', 'architecturalNotes', 'house', 'avatar'],
          },
        },
      });

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        res.status(502).json({ error: 'El modelo no devolvió parámetros de diseño.' });
        return;
      }

      const parsed = JSON.parse(rawText);
      res.json(parsed);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Error consultando el sintetizador Gemini.';
      res.status(502).json({ error: message });
    }
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AguaViva server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
